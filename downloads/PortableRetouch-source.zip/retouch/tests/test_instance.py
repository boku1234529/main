import os
from pathlib import Path
import subprocess
import sys
import time

from PySide6.QtCore import QStandardPaths
from PySide6.QtTest import QTest

from retouch.instance import Instance


def test_second_process_forwards_unicode_paths(qapp, tmp_path):
    old_org, old_name = qapp.organizationName(), qapp.applicationName()
    org, name = 'PortableRetouchTests', tmp_path.name
    qapp.setOrganizationName(org)
    qapp.setApplicationName(name)
    received = []
    instance = Instance(qapp, received.append)
    try:
        assert instance.start([])
        code = '''
import sys
from PySide6.QtWidgets import QApplication
from retouch.instance import Instance
app=QApplication([])
app.setOrganizationName(sys.argv[1]);app.setApplicationName(sys.argv[2])
instance=Instance(app, lambda _: None)
assert not instance.start([sys.argv[3]])
'''
        path = str(tmp_path / '画像 with spaces.png')
        proc = subprocess.Popen([sys.executable, '-c', code, org, name, path], env=os.environ.copy(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            deadline = time.monotonic()+12
            while proc.poll() is None and time.monotonic()<deadline:
                qapp.processEvents()
                QTest.qWait(10)
            assert proc.poll() is not None, 'secondary process timed out'
            stdout, stderr = proc.communicate(timeout=1)
            assert proc.returncode == 0, (stdout, stderr)
            qapp.processEvents()
            assert received == [[path]]
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.communicate()
    finally:
        instance.server.close()
        instance.lock.unlock()
        qapp.setOrganizationName(old_org)
        qapp.setApplicationName(old_name)


class Socket:
    def __init__(self, data):
        self.data = data
        self.aborted = False
        self.response = None
    def readAll(self):
        return self.data
    def abort(self):
        self.aborted = True
    def write(self, data):
        self.response = data
    def disconnectFromServer(self):
        pass


def test_ipc_rejects_invalid_or_oversized_input(qapp):
    from retouch.instance import LIMIT
    for payload in [b'not JSON\n', b'{"command":"execute"}\n', b'[1]\n', b'["a\\u0000b"]\n', b'"filename"\n', b'x'*(LIMIT+1)]:
        instance = Instance.__new__(Instance)
        socket = Socket(payload)
        instance.clients = {socket: bytearray()}
        instance.callback = lambda _: (_ for _ in ()).throw(AssertionError('Rejected input reached callback'))
        instance.read(socket)
        assert socket.aborted
        assert socket.response is None
