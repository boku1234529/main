from pathlib import Path
from unittest.mock import patch

import pytest
from PIL import Image, ImageCms, PngImagePlugin

from retouch.core import Document, load_image, paint, fill, mosaic, selection_mask


@pytest.fixture
def image_path(tmp_path):
    path = tmp_path / "画像.png"
    Image.new("RGBA", (40, 30), (50, 100, 150, 128)).save(path)
    return path


@pytest.fixture
def doc(image_path):
    d = Document(image_path)
    yield d
    d.close()


def test_ten_undo_redo_and_disk_cleanup(doc):
    original = doc.image.tobytes()
    history_dir = doc.states[0].parent
    for i in range(10):
        doc.commit(paint(doc.image, [(i, 1)], "red", 1))
    final = doc.image.tobytes()
    assert len(doc.states) == 11
    for _ in range(10):
        assert doc.move(-1)
    assert doc.image.tobytes() == original
    assert not doc.dirty
    assert not doc.move(-1)
    for _ in range(10):
        assert doc.move(1)
    assert doc.image.tobytes() == final
    assert doc.dirty
    assert not doc.move(1)
    doc.close()
    assert not history_dir.exists()


def test_history_branch_and_eviction(doc):
    for i in range(20):
        doc.commit(paint(doc.image, [(i, 2)], "black", 1))
    assert len(doc.states) == 11
    assert len(list(doc.states[0].parent.glob("*.png"))) == 11
    assert doc.move(-1)
    doc.commit(paint(doc.image, [(30, 2)], "red", 1))
    assert not doc.move(1)
    assert len(list(doc.states[0].parent.glob("*.png"))) == 11


@pytest.mark.parametrize("kind", ["rect", "ellipse", "free"])
def test_selection_clips_all_operations(kind):
    image = Image.new("RGBA", (40, 40), (25, 50, 75, 90))
    points = [(10, 10), (20, 10), (20, 20)] if kind == "free" else [(10, 10), (20, 20)]
    mask = selection_mask(image.size, kind, points)
    painted = paint(image, [(0, 15), (39, 15)], "red", 30, mask)
    filled = fill(image, "black", mask)
    mixed = mosaic(painted, 7, mask)
    for y in range(40):
        for x in range(40):
            if mask.getpixel((x, y)) == 0:
                for result in (painted, filled, mixed):
                    assert result.getpixel((x, y)) == image.getpixel((x, y))
    assert filled.getpixel((15, 15)) == (0, 0, 0, 255)


@pytest.mark.parametrize("kind", ["rect", "ellipse"])
def test_shift_shapes(kind):
    mask = selection_mask((100, 100), kind, [(70, 60), (10, 40)], True)
    assert mask.getbbox() == (50, 40, 71, 61)


def test_mosaic_grid_alpha_and_one_pixel():
    im = Image.new("RGBA", (7, 5))
    for y in range(5):
        for x in range(7):
            im.putpixel((x, y), (x*30, y*40, 100, (x+y)*20))
    mask = Image.new("L", im.size, 255)
    assert mosaic(im, 1, mask).tobytes() == im.tobytes()
    out = mosaic(im, 3, mask)
    assert out.getchannel("A").tobytes() == im.getchannel("A").tobytes()
    assert out.getpixel((0, 0))[:3] == out.getpixel((2, 2))[:3]
    assert out.getpixel((0, 0))[:3] != out.getpixel((3, 0))[:3]


@pytest.mark.parametrize("width", [1, 2, 15, 30])
def test_line_width_is_source_pixels(width):
    im = Image.new("RGBA", (100, 100))
    out = paint(im, [(20, 50), (80, 50)], "black", width)
    assert sum(out.getpixel((50, y))[3] > 0 for y in range(100)) == width


def test_png_metadata_removed_and_transparency(tmp_path):
    src = tmp_path / "source.png"
    info = PngImagePlugin.PngInfo()
    info.add_text("Author", "PRIVATE")
    info.add_itxt("XML:com.adobe.xmp", "GPS PRIVATE")
    exif = Image.Exif()
    exif[315] = "PRIVATE"
    Image.new("RGBA", (10, 10), (10, 20, 30, 50)).save(src, pnginfo=info, exif=exif)
    doc = Document(src)
    try:
        target = tmp_path / "out.png"
        doc.save(target)
        with Image.open(target) as im:
            assert not im.getexif()
            assert not im.info
            assert im.getpixel((0, 0)) == (10, 20, 30, 50)
        assert b"PRIVATE" not in target.read_bytes()
    finally:
        doc.close()


def test_jpeg_exif_orientation_and_white_background(tmp_path):
    src = tmp_path / "rotated.jpg"
    exif = Image.Exif()
    exif[274] = 6
    exif[315] = "PRIVATE"
    Image.new("RGB", (30, 10), "red").save(src, exif=exif)
    doc = Document(src)
    try:
        assert doc.image.size == (10, 30)
        doc.image = Image.new("RGBA", (10, 30), (0, 0, 0, 0))
        doc.save()
        with Image.open(src) as im:
            assert im.size == (10, 30)
            assert not im.getexif()
            assert im.getpixel((0, 0)) == (255, 255, 255)
        assert b"PRIVATE" not in src.read_bytes()
    finally:
        doc.close()


def test_icc_normalized_not_copied(tmp_path):
    src = tmp_path / "profile.png"
    icc = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
    Image.new("RGBA", (10, 10), (40, 50, 60, 80)).save(src, icc_profile=icc)
    im = load_image(src)
    assert not im.info
    assert im.getpixel((0, 0)) == (40, 50, 60, 80)


def test_atomic_save_failure_keeps_original_and_dirty(doc, image_path):
    original = image_path.read_bytes()
    doc.commit(paint(doc.image, [(1, 1)], "red", 2))
    with patch("retouch.core.os.replace", side_effect=PermissionError("locked")):
        with pytest.raises(PermissionError):
            doc.save()
    assert image_path.read_bytes() == original
    assert doc.dirty
    assert not list(image_path.parent.glob(".retouch-*"))


def test_snapshot_failure_keeps_redo(doc):
    doc.commit(paint(doc.image, [(1, 1)], "red", 1))
    doc.move(-1)
    with patch.object(doc, "_snapshot", side_effect=OSError("full disk")):
        with pytest.raises(OSError):
            doc.commit(paint(doc.image, [(2, 2)], "red", 1))
    assert doc.move(1)


def test_saved_revision_becomes_clean_on_undo(doc):
    doc.commit(paint(doc.image, [(1, 1)], "red", 1))
    doc.save()
    doc.commit(paint(doc.image, [(2, 2)], "black", 1))
    assert doc.dirty
    doc.move(-1)
    assert not doc.dirty


def test_tabs_independent(doc, image_path):
    other = Document(image_path)
    try:
        doc.commit(paint(doc.image, [(1, 1)], "red", 1))
        assert other.index == 0
        assert not other.dirty
    finally:
        other.close()


def test_limits_invalid_and_animated(tmp_path):
    bad = tmp_path / "broken.png"
    bad.write_text("not an image")
    with pytest.raises(Exception):
        load_image(bad)
    bad = tmp_path / "animation.png"
    Image.new("RGBA", (2, 2), "red").save(bad, save_all=True, append_images=[Image.new("RGBA", (2, 2), "blue")])
    with pytest.raises(ValueError, match="アニメーション"):
        load_image(bad)
    source = tmp_path / "large.png"
    Image.new("RGB", (10, 10)).save(source)
    with patch("retouch.core.MAX_PIXELS", 99):
        with pytest.raises(ValueError, match="画素"):
            load_image(source)


def test_noop_does_not_spend_history(doc):
    assert not doc.commit(mosaic(doc.image, 1, Image.new("L", doc.image.size, 255)))
    assert not doc.dirty
