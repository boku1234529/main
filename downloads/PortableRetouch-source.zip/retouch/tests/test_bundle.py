from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path, PurePosixPath
import hashlib
import io
import zipfile

import pytest

spec = spec_from_file_location('bundle_windows', Path(__file__).parents[1] / 'scripts' / 'bundle_windows.py')
bundle = module_from_spec(spec)
spec.loader.exec_module(bundle)


@pytest.mark.parametrize('name', ['Qt6Core.dll', 'Qt6Gui.dll', 'Qt6Widgets.dll', 'Qt6Network.dll', 'Qt6Test.dll', 'QtCore.pyd', 'QtWidgets.pyd', 'pyside6.abi3.dll', 'msvcp140.dll', 'vcruntime140.dll', 'plugins/platforms/qwindows.dll', 'plugins/platforms/qoffscreen.dll'])
def test_required_qt_payload_retained(name):
    assert bundle.keep_qt(PurePosixPath('PySide6') / name)


@pytest.mark.parametrize('name', ['Qt6Qml.dll', 'QtQml.pyd', 'qml/QtQuick/test.qml', 'plugins/multimedia/test.dll'])
def test_unused_components_excluded(name):
    assert not bundle.keep_qt(PurePosixPath('PySide6') / name)


@pytest.mark.parametrize('name', ['../escape', '/absolute', 'C:/absolute', 'dir\\escape'])
def test_archive_path_traversal_rejected(name):
    with pytest.raises(ValueError):
        bundle.safe_name(name)


def test_cached_artifact_checksum_rejected(tmp_path):
    (tmp_path / 'wheel.whl').write_bytes(b'corrupt')
    with pytest.raises(ValueError, match='checksum'):
        bundle.fetch(tmp_path, 'wheel.whl', 'https://files.pythonhosted.org/expected', '0'*64)


def test_unpack_preserves_runtime_but_removes_package_manager(tmp_path):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as z:
        z.writestr('tools/Lib/os.py', 'stdlib')
        z.writestr('tools/Lib/site-packages/pip/stub.exe', 'unused')
        z.writestr('tools/Scripts/pip.exe', 'unused')
        z.writestr('packaging.xml', 'not part of runtime')
    bundle.unpack(buffer.getvalue(), tmp_path, python=True)
    assert (tmp_path / 'Lib/os.py').read_text() == 'stdlib'
    assert not (tmp_path / 'Scripts/pip.exe').exists()
    assert not (tmp_path / 'Lib/site-packages/pip/stub.exe').exists()
    assert not (tmp_path / 'packaging.xml').exists()
