from unittest.mock import patch

import pytest
from PIL import Image
from PySide6.QtCore import Qt, QPoint
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox

from retouch.app import Window
from retouch.core import paint


@pytest.fixture
def window(qapp, tmp_path):
    win = Window()
    for i in range(2):
        path = tmp_path / f"画像{i}.png"
        Image.new("RGBA", (100, 100), (100, 150, 200, 128)).save(path)
        win.open_paths([str(path)])
    win.show()
    qapp.processEvents()
    yield win
    for i in range(win.tabs.count()):
        win.tabs.widget(i).document.close()
    win.deleteLater()
    qapp.processEvents()


def dirty_all(win):
    for i in range(win.tabs.count()):
        canvas = win.tabs.widget(i)
        canvas.document.commit(paint(canvas.document.image, [(1, 1)], "black", 3))
    win.update_titles()


def test_duplicate_paths_and_setting_carryover(window):
    window.width_spin.setValue(30)
    window.color_combo.setCurrentText("赤")
    window.mosaic_spin.setValue(25)
    window.open_paths([str(window.tabs.widget(0).document.path)])
    assert window.tabs.count() == 2
    assert window.tabs.currentIndex() == 0
    assert (window.width_spin.value(), window.color(), window.mosaic_spin.value()) == (30, "#ff0000", 25)


def test_single_save_no_cancels_and_yes_saves(window):
    dirty_all(window)
    doc = window.current().document
    before = doc.path.read_bytes()
    with patch.object(window, "confirm_overwrite", return_value=QMessageBox.StandardButton.No) as confirm:
        assert window.save_current() == "skip"
        confirm.assert_called_once()
    assert doc.path.read_bytes() == before
    assert doc.dirty
    with patch.object(window, "confirm_overwrite", return_value=QMessageBox.StandardButton.Yes):
        assert window.save_current() == "saved"
    assert not doc.dirty
    assert doc.path.read_bytes() != before


def test_batch_no_skips_next_saves(window):
    dirty_all(window)
    with patch.object(window, "confirm_overwrite", side_effect=[QMessageBox.StandardButton.No, QMessageBox.StandardButton.Yes]) as confirm, patch.object(QMessageBox, "information"):
        window.save_all(False)
        assert confirm.call_count == 2
    assert window.tabs.widget(0).document.dirty
    assert not window.tabs.widget(1).document.dirty


def test_batch_cancel_and_unchecked(window):
    dirty_all(window)
    with patch.object(window, "confirm_overwrite", return_value=QMessageBox.StandardButton.Cancel) as confirm, patch.object(QMessageBox, "information"):
        window.save_all(False)
        assert confirm.call_count == 1
    assert all(window.tabs.widget(i).document.dirty for i in range(2))
    with patch.object(window, "confirm_overwrite", side_effect=AssertionError("Must not confirm")), patch.object(QMessageBox, "information"):
        window.save_all(True)
    assert all(not window.tabs.widget(i).document.dirty for i in range(2))


def test_unmodified_batch_does_not_recompress(window):
    before = [window.tabs.widget(i).document.path.read_bytes() for i in range(2)]
    with patch.object(window, "confirm_overwrite", side_effect=AssertionError("No edits")), patch.object(QMessageBox, "information"):
        window.save_all(False)
    assert before == [window.tabs.widget(i).document.path.read_bytes() for i in range(2)]


def test_save_as_collision_with_another_tab(window):
    target = window.tabs.widget(0).document.path
    original = target.read_bytes()
    with patch("retouch.app.QFileDialog.getSaveFileName", return_value=(str(target), "PNG (*.png)")), patch.object(window, "error"):
        assert window.save_current(True) == "failed"
    assert target.read_bytes() == original


def test_ctrl_z_ctrl_y_and_canvas_draw(window, qapp):
    canvas = window.current()
    window.actual_size()
    original = canvas.document.image.tobytes()
    start = canvas.mapFromScene(20, 20)
    end = canvas.mapFromScene(70, 70)
    QTest.mousePress(canvas.viewport(), Qt.MouseButton.LeftButton, pos=start)
    QTest.mouseMove(canvas.viewport(), end)
    QTest.mouseRelease(canvas.viewport(), Qt.MouseButton.LeftButton, pos=end)
    assert canvas.document.image.tobytes() != original
    final = canvas.document.image.tobytes()
    QTest.keyClick(canvas, Qt.Key.Key_Z, Qt.KeyboardModifier.ControlModifier)
    qapp.processEvents()
    assert canvas.document.image.tobytes() == original
    QTest.keyClick(canvas, Qt.Key.Key_Y, Qt.KeyboardModifier.ControlModifier)
    qapp.processEvents()
    assert canvas.document.image.tobytes() == final


def test_selection_mosaic_escape_and_preview(window):
    canvas = window.current()
    window.actual_size()
    window.tool.setCurrentIndex(window.tool.findData("rect"))
    start, end = canvas.mapFromScene(10, 10), canvas.mapFromScene(60, 30)
    QTest.mousePress(canvas.viewport(), Qt.MouseButton.LeftButton, Qt.KeyboardModifier.ShiftModifier, start)
    QTest.mouseMove(canvas.viewport(), end)
    QTest.mouseRelease(canvas.viewport(), Qt.MouseButton.LeftButton, Qt.KeyboardModifier.ShiftModifier, end)
    assert canvas.mask.getbbox() == (10, 10, 31, 31)
    window.tool.setCurrentIndex(window.tool.findData("line"))
    before = canvas.document.image.tobytes()
    QTest.mousePress(canvas.viewport(), Qt.MouseButton.LeftButton, pos=start)
    QTest.mouseMove(canvas.viewport(), end)
    assert canvas.document.image.tobytes() == before  # Preview must not commit.
    QTest.mouseRelease(canvas.viewport(), Qt.MouseButton.LeftButton, pos=end)
    assert canvas.document.image.tobytes() != before
    assert canvas.document.image.getpixel((40, 22)) == (100, 150, 200, 128)
    QTest.keyClick(canvas, Qt.Key.Key_Escape)
    assert canvas.mask is None


def test_close_cancel_preserves_tab(window):
    dirty_all(window)
    with patch.object(window, "can_close", return_value=False):
        window.close_tab(0)
    assert window.tabs.count() == 2


def test_save_failure_preserves_edits(window):
    dirty_all(window)
    doc = window.current().document
    with patch.object(window, "confirm_overwrite", return_value=QMessageBox.StandardButton.Yes), patch.object(doc, "save", side_effect=OSError("disk full")), patch.object(window, "error"):
        assert window.save_current() == "failed"
    assert doc.dirty


def test_save_as_cancel_and_existing_target_confirmation(window, tmp_path):
    dirty_all(window)
    doc = window.current().document
    original = doc.path
    with patch("retouch.app.QFileDialog.getSaveFileName", return_value=("", "")):
        assert window.save_current(True) == "cancel"
    assert doc.path == original and doc.dirty
    target = tmp_path / 'existing.jpg'
    Image.new('RGB', (3, 3), 'red').save(target)
    old_bytes = target.read_bytes()
    with patch("retouch.app.QFileDialog.getSaveFileName", return_value=(str(target), "JPEG (*.jpg *.jpeg)")), patch.object(window, "confirm_overwrite", return_value=QMessageBox.StandardButton.No):
        assert window.save_current(True) == "skip"
    assert target.read_bytes() == old_bytes
    assert doc.path == original and doc.dirty


def test_save_as_format_extension_and_metadata(window, tmp_path):
    target = tmp_path / 'newfile'
    with patch("retouch.app.QFileDialog.getSaveFileName", return_value=(str(target), "JPEG (*.jpg *.jpeg)")), patch.object(window, "confirm_overwrite", side_effect=AssertionError('New file does not overwrite')):
        assert window.save_current(True) == "saved"
    assert window.current().document.path == target.with_suffix('.jpg')
    with Image.open(target.with_suffix('.jpg')) as im:
        assert im.format == 'JPEG'
        assert not im.getexif()


def test_mosaic_button_preserves_selection_and_size_change_does_not_edit(window):
    from PySide6.QtWidgets import QPushButton
    from retouch.core import selection_mask
    canvas = window.current()
    canvas.mask = selection_mask(canvas.document.image.size, 'rect', [(10, 10), (70, 70)])
    window.edit(lambda: paint(canvas.document.image, [(10, 10), (70, 70)], 'black', 10, canvas.mask))
    before = canvas.document.image.tobytes()
    window.mosaic_spin.setValue(20)
    assert canvas.document.image.tobytes() == before
    button = next(b for b in window.findChildren(QPushButton) if b.text() == 'モザイクを適用')
    button.click()
    assert canvas.mask is not None
    assert canvas.document.image.tobytes() != before


def test_close_save_then_no_keeps_open_and_discard_closes(window):
    dirty_all(window)
    canvas = window.current()
    def press_save():
        for button in QApplication.activeModalWidget().buttons():
            if button.text() == '保存':
                button.click()
    from PySide6.QtCore import QTimer
    QTimer.singleShot(0, press_save)
    with patch.object(window, 'confirm_overwrite', return_value=QMessageBox.StandardButton.No):
        assert not window.can_close(canvas)
    assert canvas.document.dirty
    def discard():
        for button in QApplication.activeModalWidget().buttons():
            if button.text() == '保存せず閉じる':
                button.click()
    QTimer.singleShot(0, discard)
    window.close_tab(window.tabs.currentIndex())
    assert window.tabs.count() == 1


def test_drop_multiple_files_on_image_view(window, tmp_path):
    from PySide6.QtCore import QMimeData, QUrl, QPointF
    from PySide6.QtGui import QDragEnterEvent, QDropEvent
    paths = [tmp_path / 'drop1.png', tmp_path / 'drop2.jpg']
    for path in paths:
        Image.new('RGB', (10, 10), 'red').save(path)
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(path)) for path in paths])
    viewport = window.current().viewport()
    enter = QDragEnterEvent(QPointF(20, 20), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    QApplication.sendEvent(viewport, enter)
    assert enter.isAccepted()
    drop = QDropEvent(QPointF(20, 20), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    QApplication.sendEvent(viewport, drop)
    assert drop.isAccepted()
    assert window.tabs.count() == 4
    assert window.tabs.widget(2).document.path == paths[0]
    assert window.tabs.widget(3).document.path == paths[1]
