from unittest.mock import MagicMock, patch
import sys

from retouch import shell


def test_registry_only_current_user_and_quoted_command():
    registry = MagicMock()
    registry.HKEY_CURRENT_USER = 'HKCU'
    registry.REG_SZ = 1
    registry.CreateKey.return_value.__enter__.return_value = 'key'
    with patch.dict(sys.modules, winreg=registry), patch.object(sys, 'platform', 'win32'), patch.object(sys, 'frozen', True, create=True), patch.object(sys, 'executable', 'C:/Program Files/Retouch/PortableRetouch.exe'), patch.object(shell.ctypes, 'windll', create=True):
        shell.configure(True)
    assert registry.CreateKey.call_count == 6
    assert all(call.args[0] == 'HKCU' for call in registry.CreateKey.call_args_list)
    commands = [c.args[-1] for c in registry.SetValueEx.call_args_list if str(c.args[-1]).endswith('"%1"')]
    assert len(commands) == 3
    assert all(command.startswith('"') and 'PortableRetouch.exe" "%1"' in command for command in commands)


def test_registry_unregistration_exact_keys_and_idempotent():
    registry = MagicMock()
    registry.HKEY_CURRENT_USER = 'HKCU'
    registry.DeleteKey.side_effect = FileNotFoundError
    with patch.dict(sys.modules, winreg=registry), patch.object(sys, 'platform', 'win32'), patch.object(shell.ctypes, 'windll', create=True):
        shell.configure(False)
    assert registry.DeleteKey.call_count == 6
    assert all(shell.VERB in c.args[1] for c in registry.DeleteKey.call_args_list)
