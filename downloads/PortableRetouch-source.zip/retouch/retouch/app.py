"""Qt desktop UI. All image coordinates are source pixels, independent of zoom."""
from __future__ import annotations

from pathlib import Path
import sys

from PIL.ImageQt import ImageQt
from PySide6.QtCore import Qt, QPointF, QRectF, Signal
from PySide6.QtGui import QAction, QKeySequence, QPen, QColor, QPainterPath
from PySide6.QtWidgets import (
    QMainWindow, QFileDialog,
    QMessageBox, QTabWidget, QToolBar, QComboBox, QLabel, QSpinBox, QSlider,
    QPushButton, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem,
)
from PySide6.QtGui import QPixmap

from .core import Document, canonical, selection_mask, paint, fill, mosaic, COLORS


class Canvas(QGraphicsView):
    changed = Signal()

    def __init__(self, document, window):
        super().__init__()
        self.document = document
        self.window = window
        self.scene_ = QGraphicsScene(self)
        self.setScene(self.scene_)
        self.pixmap = QGraphicsPixmapItem()
        self.scene_.addItem(self.pixmap)
        self.preview = self.scene_.addPath(QPainterPath(), QPen(QColor("#00bfff"), 1, Qt.PenStyle.DashLine))
        self.selection_item = self.scene_.addPath(QPainterPath(), self.selection_pen())
        self.mask = None
        self.selection = QPainterPath()
        self.points = []
        self.drawing = False
        self.panning = False
        self.previous = None
        self.setBackgroundBrush(QColor("#555555"))
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.refresh()

    def refresh(self):
        self.pixmap.setPixmap(QPixmap.fromImage(ImageQt(self.document.image)))
        self.scene_.setSceneRect(QRectF(0, 0, *self.document.image.size))
        self.selection_item.setPath(self.selection)
        self.cancel_gesture()
        self.changed.emit()

    @staticmethod
    def selection_pen():
        pen = QPen(QColor("#00bfff"), 1, Qt.PenStyle.DashLine)
        pen.setCosmetic(True)
        return pen

    def cancel_gesture(self):
        self.drawing = False
        self.points = []
        self.preview.setPath(QPainterPath())
        self.preview.setPen(self.selection_pen())
        self.preview.setBrush(Qt.BrushStyle.NoBrush)
        self.selection_item.setPath(self.selection)

    def deselect(self):
        self.cancel_gesture()
        self.mask = None
        self.selection = QPainterPath()
        self.selection_item.setPath(self.selection)

    def point(self, event):
        pos = self.mapToScene(event.position().toPoint())
        w, h = self.document.image.size
        return (max(0, min(w-1, int(pos.x()))), max(0, min(h-1, int(pos.y()))))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.MiddleButton or (event.button() == Qt.MouseButton.LeftButton and self.window.tool.currentData() == "pan"):
            self.panning = True
            self.previous = event.position()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            return
        if event.button() != Qt.MouseButton.LeftButton:
            return
        scene_point = self.mapToScene(event.position().toPoint())
        if not self.scene_.sceneRect().contains(scene_point):
            return
        self.setFocus()
        self.drawing = True
        self.points = [self.point(event)]
        self.update_preview(event.modifiers())

    def mouseMoveEvent(self, event):
        if self.panning:
            delta = event.position() - self.previous
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value()-round(delta.x()))
            self.verticalScrollBar().setValue(self.verticalScrollBar().value()-round(delta.y()))
            self.previous = event.position()
        elif self.drawing:
            point = self.point(event)
            if self.window.tool.currentData() in {"pen", "free"}:
                if point != self.points[-1]:
                    self.points.append(point)
            else:
                self.points = [self.points[0], point]
            self.update_preview(event.modifiers())

    def shape_path(self, modifiers):
        path = QPainterPath()
        kind = self.window.tool.currentData()
        if not self.points:
            return path
        start, end = self.points[0], self.points[-1]
        if kind in {"rect", "ellipse"}:
            x, y = end
            if modifiers & Qt.KeyboardModifier.ShiftModifier:
                side = min(abs(x-start[0]), abs(y-start[1]))
                x = start[0] + (side if x >= start[0] else -side)
                y = start[1] + (side if y >= start[1] else -side)
            # Inclusive source pixels, matching Pillow's rectangle/ellipse masks.
            rect = QRectF(min(start[0], x), min(start[1], y), abs(x-start[0])+1, abs(y-start[1])+1)
            if kind == "rect":
                path.addRect(rect)
            else:
                path.addEllipse(rect)
        else:
            path.moveTo(QPointF(*start))
            for p in self.points[1:]:
                path.lineTo(QPointF(*p))
            if kind == "free":
                path.closeSubpath()
        return path

    def update_preview(self, modifiers):
        path = self.shape_path(modifiers)
        if self.window.tool.currentData() in {"pen", "line"}:
            if self.mask is not None:
                # Clip the live stroke to the same selection as the committed edit.
                stroke_path = QPainterPath()
                from PySide6.QtGui import QPainterPathStroker
                stroker = QPainterPathStroker()
                stroker.setWidth(self.window.width_spin.value())
                stroker.setCapStyle(Qt.PenCapStyle.RoundCap)
                stroke_path = stroker.createStroke(path).intersected(self.selection)
                self.preview.setPath(stroke_path)
                self.preview.setPen(QPen(Qt.PenStyle.NoPen))
                self.preview.setBrush(QColor(self.window.color()))
            else:
                self.preview.setPath(path)
                self.preview.setBrush(Qt.BrushStyle.NoBrush)
                pen = QPen(QColor(self.window.color()), self.window.width_spin.value())
                pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                self.preview.setPen(pen)
        else:
            self.preview.setPen(self.selection_pen())
            self.preview.setBrush(Qt.BrushStyle.NoBrush)
            self.preview.setPath(path)

    def mouseReleaseEvent(self, event):
        if self.panning:
            self.panning = False
            self.unsetCursor()
            return
        if event.button() != Qt.MouseButton.LeftButton or not self.drawing:
            return
        point = self.point(event)
        kind = self.window.tool.currentData()
        if kind in {"pen", "free"}:
            if point != self.points[-1]:
                self.points.append(point)
        else:
            self.points = [self.points[0], point]
        self.drawing = False
        if kind in {"rect", "ellipse", "free"}:
            mask = selection_mask(self.document.image.size, kind, self.points,
                                  bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier))
            if mask.getbbox() is not None:
                self.mask = mask
                self.selection = self.shape_path(event.modifiers())
        elif kind in {"pen", "line"}:
            self.window.edit(lambda: paint(self.document.image, self.points, self.window.color(), self.window.width_spin.value(), self.mask))
        self.cancel_gesture()

    def zoom(self, factor):
        scale = self.transform().m11()
        desired = max(.02, min(32, scale*factor))
        self.scale(desired/scale, desired/scale)
        self.window.statusBar().showMessage(f"ズーム {desired:.0%} ｜ 中ボタンドラッグで移動 / Esc で選択解除")

    def wheelEvent(self, event):
        self.zoom(1.2 if event.angleDelta().y() > 0 else 1/1.2)
        event.accept()

    def dragEnterEvent(self, event):
        self.window.dragEnterEvent(event)

    def dragMoveEvent(self, event):
        self.window.dragEnterEvent(event)

    def dropEvent(self, event):
        self.window.dropEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.deselect()
        else:
            super().keyPressEvent(event)


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Portable Retouch")
        self.resize(1200, 850)
        self.setAcceptDrops(True)
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(lambda _: self.update_titles())
        self.setCentralWidget(self.tabs)
        self.build_tools()
        self.statusBar().showMessage("JPG / PNG をドロップ、または Ctrl+O で開く")

    def action(self, menu, text, callback, shortcut=None):
        action = QAction(text, self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        action.triggered.connect(callback)
        menu.addAction(action)
        return action

    def build_tools(self):
        file = self.menuBar().addMenu("ファイル")
        self.action(file, "開く…", self.choose_open, "Ctrl+O")
        self.action(file, "上書き保存", self.save_current, "Ctrl+S")
        self.action(file, "名前を付けて保存…", lambda: self.save_current(True), "Ctrl+Shift+S")
        self.action(file, "すべてのタブを保存（個別確認）", lambda: self.save_all(False))
        self.action(file, "一括で上書き保存（確認なし）", lambda: self.save_all(True))
        file.addSeparator()
        self.action(file, "閉じる", lambda: self.close_tab(self.tabs.currentIndex()), "Ctrl+W")
        edit = self.menuBar().addMenu("編集")
        self.undo_action = self.action(edit, "元に戻す", lambda: self.history(-1), "Ctrl+Z")
        self.redo_action = self.action(edit, "やり直す", lambda: self.history(1), "Ctrl+Y")
        self.action(edit, "選択解除", lambda: self.current() and self.current().deselect(), "Esc")
        view = self.menuBar().addMenu("表示")
        self.action(view, "拡大", lambda: self.current() and self.current().zoom(1.2), "Ctrl++")
        self.action(view, "縮小", lambda: self.current() and self.current().zoom(1/1.2), "Ctrl+-")
        self.action(view, "原寸", self.actual_size, "Ctrl+0")
        self.action(view, "全体を表示", self.fit)
        settings = self.menuBar().addMenu("設定")
        self.action(settings, "右クリックメニューに登録", lambda: self.shell(True))
        self.action(settings, "右クリックメニューの登録を解除", lambda: self.shell(False))
        tools = QToolBar("描画", self)
        tools.setMovable(False)
        self.addToolBar(tools)
        self.tool = QComboBox()
        for label, data in [("ペン", "pen"), ("直線", "line"), ("長方形選択", "rect"), ("楕円選択", "ellipse"), ("自由選択", "free"), ("表示移動", "pan")]:
            self.tool.addItem(label, data)
        self.tool.currentIndexChanged.connect(self.cancel_gestures)
        tools.addWidget(self.tool)
        self.color_combo = QComboBox()
        self.color_combo.addItems(list(COLORS))
        tools.addWidget(self.color_combo)
        self.width_spin = self.size_control(tools, "線幅", 3)
        self.addToolBarBreak()
        effects = QToolBar("加工", self)
        effects.setMovable(False)
        self.addToolBar(effects)
        self.mosaic_spin = self.size_control(effects, "モザイク", 12)
        button = QPushButton("モザイクを適用")
        button.clicked.connect(lambda: self.edit(lambda: mosaic(self.current().document.image, self.mosaic_spin.value(), self.current().mask)))
        effects.addWidget(button)
        button = QPushButton("選択範囲を塗りつぶす")
        button.clicked.connect(lambda: self.edit(lambda: fill(self.current().document.image, self.color(), self.current().mask)))
        effects.addWidget(button)
        self.update_titles()

    def size_control(self, toolbar, label, default):
        toolbar.addWidget(QLabel(f"  {label} "))
        spin = QSpinBox()
        spin.setRange(1, 30)
        spin.setSuffix(" px")
        spin.setValue(default)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(1, 30)
        slider.setValue(default)
        slider.setFixedWidth(140)
        spin.valueChanged.connect(slider.setValue)
        slider.valueChanged.connect(spin.setValue)
        toolbar.addWidget(spin)
        toolbar.addWidget(slider)
        return spin

    def color(self):
        return COLORS[self.color_combo.currentText()]

    def current(self):
        return self.tabs.currentWidget()

    def cancel_gestures(self):
        for i in range(self.tabs.count()):
            self.tabs.widget(i).cancel_gesture()

    def error(self, title, error):
        box = QMessageBox(QMessageBox.Icon.Warning, title, str(error), QMessageBox.StandardButton.Ok, self)
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.exec()

    def choose_open(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "画像を開く", "", "画像 (*.jpg *.jpeg *.png)")
        self.open_paths(paths)

    def open_paths(self, paths):
        for path in paths:
            try:
                existing = next((i for i in range(self.tabs.count()) if canonical(self.tabs.widget(i).document.path) == canonical(path)), None)
                if existing is not None:
                    self.tabs.setCurrentIndex(existing)
                    continue
                doc = Document(path)
                canvas = Canvas(doc, self)
                canvas.changed.connect(self.update_titles)
                self.tabs.addTab(canvas, doc.path.name)
                self.tabs.setCurrentWidget(canvas)
                self.fit()
            except Exception as exc:
                self.error("画像を開けません", f"{Path(path).name}\n{exc}")
        self.update_titles()
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def fit(self):
        if self.current():
            self.current().fitInView(self.current().sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)

    def actual_size(self):
        if self.current():
            self.current().resetTransform()

    def edit(self, operation):
        if not self.current():
            return
        try:
            self.current().document.commit(operation())
            self.current().refresh()
        except Exception as exc:
            self.error("編集できません", exc)

    def history(self, delta):
        if self.current():
            try:
                self.current().cancel_gesture()
                self.current().document.move(delta)
                self.current().refresh()
            except Exception as exc:
                self.error("履歴を読み込めません", exc)

    def update_titles(self):
        for i in range(self.tabs.count()):
            doc = self.tabs.widget(i).document
            self.tabs.setTabText(i, ("● " if doc.dirty else "") + doc.path.name.replace("&", "&&"))
            self.tabs.setTabToolTip(i, str(doc.path))
        if hasattr(self, "undo_action"):
            doc = self.current().document if self.current() else None
            self.undo_action.setEnabled(bool(doc and doc.index > 0))
            self.redo_action.setEnabled(bool(doc and doc.index < len(doc.states)-1))

    def confirm_overwrite(self, target, batch=False):
        box = QMessageBox(self)
        box.setWindowTitle("上書き保存")
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.setText(f"上書き保存しますか？\n{target}")
        buttons = QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        if batch:
            buttons |= QMessageBox.StandardButton.Cancel
        box.setStandardButtons(buttons)
        box.setDefaultButton(QMessageBox.StandardButton.No)
        return box.exec()

    def save_canvas(self, canvas, save_as=False, unchecked=False, batch=False):
        doc = canvas.document
        target = doc.path
        if save_as:
            name, selected = QFileDialog.getSaveFileName(self, "名前を付けて保存", str(target), "PNG (*.png);;JPEG (*.jpg *.jpeg)", options=QFileDialog.Option.DontConfirmOverwrite)
            if not name:
                return "cancel"
            target = Path(name)
            if not target.suffix:
                target = target.with_suffix(".png" if selected.startswith("PNG") else ".jpg")
            for i in range(self.tabs.count()):
                other = self.tabs.widget(i)
                if other is not canvas and canonical(other.document.path) == canonical(target):
                    self.error("保存できません", "別のタブで開いているファイルです。別の名前で保存してください。")
                    return "failed"
        # Ordinary Save always confirms, including a deleted original file.
        if not unchecked and (not save_as or target.exists()):
            result = self.confirm_overwrite(target, batch)
            if result == QMessageBox.StandardButton.Cancel:
                return "cancel"
            if result != QMessageBox.StandardButton.Yes:
                return "skip"
        try:
            doc.save(target)
            self.update_titles()
            return "saved"
        except Exception as exc:
            self.error("保存に失敗しました（編集内容は保持されています）", f"{target}\n{exc}")
            return "failed"

    def save_current(self, save_as=False):
        if self.current():
            return self.save_canvas(self.current(), save_as)

    def save_all(self, unchecked):
        counts = {"saved": 0, "skip": 0, "failed": 0, "unrun": 0}
        for i in range(self.tabs.count()):
            canvas = self.tabs.widget(i)
            if not canvas.document.dirty:
                counts["skip"] += 1
                continue
            self.tabs.setCurrentIndex(i)
            result = self.save_canvas(canvas, unchecked=unchecked, batch=True)
            if result == "cancel":
                counts["unrun"] = self.tabs.count()-i
                break
            counts[result] += 1
        QMessageBox.information(self, "一括保存結果", f"保存: {counts['saved']}\nスキップ（未変更を含む）: {counts['skip']}\n失敗: {counts['failed']}\n中断により未処理: {counts['unrun']}")

    def can_close(self, canvas):
        if not canvas.document.dirty:
            return True
        box = QMessageBox(self)
        box.setWindowTitle("未保存の編集")
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.setText(f"{canvas.document.path.name}\n変更を保存しますか？")
        save = box.addButton("保存", QMessageBox.ButtonRole.AcceptRole)
        discard = box.addButton("保存せず閉じる", QMessageBox.ButtonRole.DestructiveRole)
        cancel = box.addButton("キャンセル", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(cancel)
        box.exec()
        if box.clickedButton() == discard:
            return True
        if box.clickedButton() == save:
            return self.save_canvas(canvas) == "saved"
        return False

    def close_tab(self, index):
        if index < 0:
            return
        canvas = self.tabs.widget(index)
        if self.can_close(canvas):
            self.tabs.removeTab(index)
            canvas.document.close()
            canvas.deleteLater()
            self.update_titles()

    def closeEvent(self, event):
        # Decide for every tab first; cancellation must preserve all open tabs.
        canvases = [self.tabs.widget(i) for i in range(self.tabs.count())]
        for canvas in canvases:
            self.tabs.setCurrentWidget(canvas)
            if not self.can_close(canvas):
                event.ignore()
                return
        for canvas in canvases:
            canvas.document.close()
        event.accept()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() and any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        self.open_paths([url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()])
        event.acceptProposedAction()

    def shell(self, register):
        from .shell import configure
        try:
            configure(register)
            QMessageBox.information(self, "右クリックメニュー", "登録しました。「その他のオプションを確認」内に表示されます。移動した場合は再登録してください。" if register else "登録を解除しました。")
        except Exception as exc:
            self.error("右クリックメニュー設定", exc)
