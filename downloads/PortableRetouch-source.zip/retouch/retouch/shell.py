"""Per-user Explorer verbs. No administrator rights or command shell needed."""
from pathlib import Path
import ctypes
import sys

VERB = "PortableRetouch.Edit"
EXTENSIONS = (".jpg", ".jpeg", ".png")


def configure(register):
    if sys.platform != "win32":
        raise RuntimeError("右クリックメニューの登録は Windows 11 で利用できます。")
    if register and not getattr(sys, "frozen", False):
        raise RuntimeError("右クリック登録は配布版の PortableRetouch.exe から行ってください。")
    import winreg
    executable = str(Path(sys.executable).resolve())
    for extension in EXTENSIONS:
        base = rf"Software\Classes\SystemFileAssociations\{extension}\shell\{VERB}"
        if register:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base) as key:
                winreg.SetValueEx(key, "", 0, winreg.REG_SZ, "Portable Retouch で編集")
                winreg.SetValueEx(key, "Icon", 0, winreg.REG_SZ, f'"{executable}",0')
                winreg.SetValueEx(key, "MultiSelectModel", 0, winreg.REG_SZ, "Document")
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\command") as key:
                winreg.SetValueEx(key, "", 0, winreg.REG_SZ, f'"{executable}" "%1"')
        else:
            # Delete only the exact keys owned by this application, never a tree.
            for name in (base + r"\command", base):
                try:
                    winreg.DeleteKey(winreg.HKEY_CURRENT_USER, name)
                except FileNotFoundError:
                    pass
    ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
