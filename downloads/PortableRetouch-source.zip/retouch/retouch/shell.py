"""Per-user Explorer verbs. No administrator rights or command shell needed."""
from pathlib import Path
import ctypes
import sys

VERB = "PortableRetouch.Edit"
EXTENSIONS = (".jpg", ".jpeg", ".png")


def launch_command():
    executable = Path(sys.executable).resolve()
    def quoted(path):
        value = str(path)
        if '"' in value or any(ord(character) < 32 for character in value):
            raise RuntimeError("Invalid application path")
        return '"' + value + '"'
    if getattr(sys, "frozen", False):
        return quoted(executable) + ' "%1"'
    root = Path(__file__).resolve().parents[1]
    if executable.parent == root / "_runtime" and (root / "launcher.py").is_file():
        return quoted(executable.with_name("pythonw.exe")) + ' -E -s ' + quoted(root / "launcher.py") + ' "%1"'
    raise RuntimeError("右クリック登録は Windows ポータブル版から行ってください。")


def configure(register):
    if sys.platform != "win32":
        raise RuntimeError("右クリックメニューの登録は Windows 11 で利用できます。")
    command = launch_command() if register else None
    import winreg
    executable = str(Path(sys.executable).resolve())
    for extension in EXTENSIONS:
        base = rf"Software\Classes\SystemFileAssociations\{extension}\shell\{VERB}"
        if register:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base) as key:
                winreg.SetValueEx(key, "", 0, winreg.REG_SZ, "Portable Retouch で編集")
                winreg.SetValueEx(key, "Icon", 0, winreg.REG_SZ, f'"{executable}",0')
                winreg.SetValueEx(key, "MultiSelectModel", 0, winreg.REG_SZ, "Document")
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\command") as key:
                winreg.SetValueEx(key, "", 0, winreg.REG_SZ, command)
        else:
            # Delete only the exact keys owned by this application, never a tree.
            for name in (base + r"\command", base):
                try:
                    winreg.DeleteKey(winreg.HKEY_CURRENT_USER, name)
                except FileNotFoundError:
                    pass
    ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
