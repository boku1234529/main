"""A packaged-executable smoke check using synthetic data only."""
from pathlib import Path
import tempfile

from PIL import Image
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest

from .app import Window
from .core import selection_mask, mosaic


def require(condition):
    if not condition:
        raise RuntimeError("Packaged application smoke check failed")


def run(app):
    window = Window()
    # A runtime error must fail the check instead of leaving a modal dialog open.
    def fail(title, error):
        raise RuntimeError(f'{title}: {error}')
    window.error = fail
    try:
        with tempfile.TemporaryDirectory(prefix='retouch-smoke-') as folder:
            folder = Path(folder)
            first, second = folder / '画像.png', folder / 'second.jpg'
            Image.new('RGBA', (80, 80), (10, 20, 30, 80)).save(first)
            Image.new('RGB', (80, 80), 'white').save(second)
            window.show()
            window.open_paths([str(first), str(second), str(first)])
            app.processEvents()
            require(window.tabs.count() == 2)
            canvas = window.current()
            require(canvas.document.path == first)
            window.actual_size()
            original = canvas.document.image.tobytes()
            p1, p2 = canvas.mapFromScene(10, 10), canvas.mapFromScene(60, 60)
            QTest.mousePress(canvas.viewport(), Qt.MouseButton.LeftButton, pos=p1)
            QTest.mouseMove(canvas.viewport(), p2)
            QTest.mouseRelease(canvas.viewport(), Qt.MouseButton.LeftButton, pos=p2)
            require(canvas.document.image.tobytes() != original)
            edited = canvas.document.image.tobytes()
            window.history(-1)
            require(canvas.document.image.tobytes() == original)
            window.history(1)
            require(canvas.document.image.tobytes() == edited)
            canvas.mask = selection_mask((80, 80), 'ellipse', [(5, 5), (70, 70)])
            window.edit(lambda: mosaic(canvas.document.image, 12, canvas.mask))
            expected = canvas.document.image.tobytes()
            require(window.save_canvas(canvas, unchecked=True) == 'saved')
            with Image.open(first) as image:
                require(image.convert('RGBA').tobytes() == expected)
                require(not image.info and not image.getexif())
            canvas.document.save(folder / 'output.jpg')
            with Image.open(folder / 'output.jpg') as image:
                require(image.format == 'JPEG')
                require(not image.getexif())
    finally:
        for i in range(window.tabs.count()):
            window.tabs.widget(i).document.close()
        window.deleteLater()
        app.processEvents()
    return 0
