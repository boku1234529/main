"""Image operations, bounded disk-backed history, and atomic metadata-free saving."""
from __future__ import annotations

import io
import math
import os
from pathlib import Path
import tempfile
import warnings

from PIL import Image, ImageCms, ImageDraw, ImageOps

MAX_PIXELS = 25_000_000
MAX_FILE_BYTES = 256 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = MAX_PIXELS
COLORS = {"黒": "#000000", "白": "#ffffff", "赤": "#ff0000"}


def canonical(path):
    return os.path.normcase(str(Path(path).resolve()))


def load_image(path):
    path = Path(path)
    if path.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
        raise ValueError("対応形式は JPG / PNG です。")
    if path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError("ファイルは 256 MiB 以下にしてください。")
    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        with Image.open(path) as src:
            if src.format not in {"JPEG", "PNG"}:
                raise ValueError("画像の内容が JPG / PNG ではありません。")
            if src.width * src.height > MAX_PIXELS:
                raise ValueError("画像は 2,500 万画素以下にしてください。")
            if getattr(src, "n_frames", 1) != 1:
                raise ValueError("アニメーション画像には対応していません。")
            image = ImageOps.exif_transpose(src)
            profile = src.info.get("icc_profile")
            if profile:
                # Normalize colors before discarding potentially identifying metadata.
                alpha = image.convert("RGBA").getchannel("A")
                mode = "CMYK" if image.mode == "CMYK" else "RGB"
                image = ImageCms.profileToProfile(
                    image.convert(mode), ImageCms.ImageCmsProfile(io.BytesIO(profile)),
                    ImageCms.createProfile("sRGB"), outputMode="RGB")
                image.putalpha(alpha)
            else:
                image = image.convert("RGBA")
            image = image.copy()
            image.info.clear()
            return image


def selection_mask(size, kind, points, square=False):
    mask = Image.new("L", size)
    if len(points) < 2:
        return mask
    draw = ImageDraw.Draw(mask)
    if kind == "free":
        if len(points) >= 3:
            draw.polygon(points, fill=255)
    else:
        (x1, y1), (x2, y2) = points[0], points[-1]
        if square:
            side = min(abs(x2 - x1), abs(y2 - y1))
            x2 = x1 + math.copysign(side, x2 - x1)
            y2 = y1 + math.copysign(side, y2 - y1)
        box = (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
        if kind == "ellipse":
            draw.ellipse(box, fill=255)
        elif kind == "rect":
            draw.rectangle(box, fill=255)
        else:
            raise ValueError("Unknown selection")
    return mask


def paint(image, points, color, width, mask=None):
    if not 1 <= width <= 30 or not points:
        raise ValueError("線幅は 1～30 px です。")
    stroke = Image.new("L", image.size)
    draw = ImageDraw.Draw(stroke)
    if len(points) > 1:
        draw.line(points, fill=255, width=width, joint="curve")
    # Round stroke caps, including a single click.
    offset = (width - 1) // 2
    for x, y in points:
        if width == 1:
            draw.point((x, y), fill=255)
        else:
            draw.ellipse((x-offset, y-offset, x-offset+width-1, y-offset+width-1), fill=255)
    if mask is not None:
        from PIL import ImageChops
        stroke = ImageChops.multiply(stroke, mask)
    result = image.copy()
    result.paste(Image.new("RGBA", image.size, color), (0, 0), stroke)
    return result


def fill(image, color, mask):
    if mask is None:
        raise ValueError("先に範囲を選択してください。")
    result = image.copy()
    result.paste(Image.new("RGBA", image.size, color), (0, 0), mask)
    return result


def mosaic(image, block, mask):
    if mask is None:
        raise ValueError("先に範囲を選択してください。")
    if not 1 <= block <= 30:
        raise ValueError("モザイクサイズは 1～30 px です。")
    # reduce() averages actual N×N cells, including partial edge cells.
    small = image.reduce(block)
    tiles = small.resize((small.width * block, small.height * block), Image.Resampling.NEAREST)
    tiles = tiles.crop((0, 0, *image.size))
    tiles.putalpha(image.getchannel("A"))
    return Image.composite(tiles, image, mask)


class Document:
    """At most ten undo states; PNG history lives in a private temporary directory."""
    def __init__(self, path):
        self.path = Path(path).resolve()
        self.image = load_image(path)
        self._temp = tempfile.TemporaryDirectory(prefix="portable-retouch-", ignore_cleanup_errors=True)
        self._counter = 0
        self.states = [self._snapshot(self.image)]
        self.index = 0
        self.saved_state = self.states[0]

    def _snapshot(self, image):
        self._counter += 1
        path = Path(self._temp.name) / f"{self._counter}.png"
        try:
            image.save(path, format="PNG")
        except Exception:
            path.unlink(missing_ok=True)
            raise
        return path

    @property
    def dirty(self):
        return self.states[self.index] != self.saved_state

    def commit(self, image):
        if image.size != self.image.size or image.mode != "RGBA":
            raise ValueError("Invalid edit dimensions or color mode")
        if image.tobytes() == self.image.tobytes():
            return False
        state = self._snapshot(image)  # A failed disk write must not destroy redo.
        obsolete = self.states[self.index+1:]
        self.states = self.states[:self.index+1] + [state]
        if len(self.states) > 11:
            obsolete.append(self.states.pop(0))
        self.index = len(self.states)-1
        self.image = image
        for path in obsolete:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass  # A locked obsolete file can be removed at document close.
        return True

    def move(self, delta):
        target = self.index + delta
        if not 0 <= target < len(self.states):
            return False
        with Image.open(self.states[target]) as im:
            image = im.convert("RGBA")
        self.image = image
        self.index = target
        return True

    def save(self, path=None):
        target = Path(path or self.path).resolve()
        suffix = target.suffix.lower()
        if suffix not in {".png", ".jpg", ".jpeg"}:
            raise ValueError("拡張子は .png / .jpg / .jpeg を指定してください。")
        # Construct new pixels: no EXIF, XMP, text, thumbnails, or source ICC.
        clean = Image.frombytes("RGBA", self.image.size, self.image.tobytes())
        if suffix != ".png":
            background = Image.new("RGB", clean.size, "white")
            background.paste(clean, mask=clean.getchannel("A"))
            clean = background
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".retouch-", suffix=".tmp", delete=False) as f:
                temporary = Path(f.name)
                if suffix == ".png":
                    clean.save(f, format="PNG")
                else:
                    clean.save(f, format="JPEG", quality=95, subsampling=0)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporary, target)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        self.path = target
        self.saved_state = self.states[self.index]

    def close(self):
        self._temp.cleanup()
