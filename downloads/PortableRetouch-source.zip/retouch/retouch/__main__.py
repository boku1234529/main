import sys
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QMessageBox
from .app import Window
from .instance import Instance


def main():
    app = QApplication(sys.argv[:1])  # Image filenames must not become Qt options.
    app.setOrganizationName("PortableRetouch")
    app.setApplicationName("PortableRetouch")
    if sys.argv[1:] == ["--self-test"]:
        from .smoke import run
        try:
            return run(app)
        except Exception:
            if sys.stderr is not None:
                import traceback
                traceback.print_exc()
            return 1
    window = Window()
    instance = Instance(app, window.open_paths)
    try:
        primary = instance.start(sys.argv[1:])
    except Exception as exc:
        QMessageBox.critical(None, "起動できません", str(exc))
        return 1
    if not primary:
        return 0
    window.show()
    if sys.argv[1:]:
        QTimer.singleShot(0, lambda: window.open_paths(sys.argv[1:]))
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
