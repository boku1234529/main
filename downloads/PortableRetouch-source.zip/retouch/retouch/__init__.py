"""Portable Retouch: local-only image redaction."""
