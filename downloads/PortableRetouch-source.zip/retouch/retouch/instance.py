"""Single instance, per-user IPC. Only bounded JSON path arrays are accepted."""
import hashlib
import json
from pathlib import Path

from PySide6.QtCore import QLockFile, QStandardPaths, QTimer, QIODevice
from PySide6.QtNetwork import QLocalServer, QLocalSocket

LIMIT = 1024 * 1024


class Instance:
    def __init__(self, parent, callback):
        directory = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation))
        directory.mkdir(parents=True, exist_ok=True)
        self.name = "PortableRetouch-" + hashlib.sha256(str(directory).encode()).hexdigest()[:24]
        self.lock = QLockFile(str(directory / "instance.lock"))
        self.lock.setStaleLockTime(0)  # Never steal a live editor's lock based on age.
        self.server = QLocalServer(parent)
        self.server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
        self.server.newConnection.connect(self.accept)
        self.callback = callback
        self.clients = {}

    def start(self, paths):
        payload = json.dumps(paths, ensure_ascii=True).encode() + b"\n"
        if len(payload) > LIMIT:
            raise RuntimeError("一度に開くファイルが多すぎます。")
        if self.lock.tryLock(0):
            QLocalServer.removeServer(self.name)  # We own the per-user lock.
            if not self.server.listen(self.name):
                raise RuntimeError("起動用のローカル通信を開始できません。" + self.server.errorString())
            return True
        socket = QLocalSocket()
        # Allow the first process time to finish creating its named pipe.
        for _ in range(20):
            socket.abort()
            socket.connectToServer(self.name, QIODevice.OpenModeFlag.ReadWrite)
            if socket.waitForConnected(250):
                break
            # Connect can fail immediately before the first listener exists.
            from PySide6.QtCore import QThread
            QThread.msleep(100)
        else:
            raise RuntimeError("起動済みのアプリと通信できません。起動済みウインドウを確認してください。")
        socket.write(payload)
        if socket.bytesToWrite() and not socket.waitForBytesWritten(3000):
            raise RuntimeError("ファイル一覧を送信できませんでした。")
        if not socket.bytesAvailable() and not socket.waitForReadyRead(3000):
            raise RuntimeError("起動済みアプリから応答がありません。")
        if bytes(socket.readAll()) != b"OK":
            raise RuntimeError("ファイル一覧が受信されませんでした。")
        socket.disconnectFromServer()
        return False

    def accept(self):
        while self.server.hasPendingConnections():
            socket = self.server.nextPendingConnection()
            if len(self.clients) >= 16:
                socket.abort()
                socket.deleteLater()
                continue
            self.clients[socket] = bytearray()
            timer = QTimer(socket)
            timer.setSingleShot(True)
            timer.timeout.connect(socket.abort)
            timer.start(5000)
            socket.setReadBufferSize(LIMIT+1)
            socket.readyRead.connect(lambda s=socket: self.read(s))
            socket.disconnected.connect(lambda s=socket: self.cleanup(s))
            self.read(socket)

    def cleanup(self, socket):
        self.clients.pop(socket, None)
        socket.deleteLater()

    def read(self, socket):
        buffer = self.clients.get(socket)
        if buffer is None:
            return
        buffer.extend(bytes(socket.readAll()))
        if len(buffer) > LIMIT:
            socket.abort()
            return
        if b"\n" not in buffer:
            return
        try:
            paths = json.loads(bytes(buffer))
            if not isinstance(paths, list) or len(paths) > 1000:
                raise ValueError("Invalid paths")
            if any(not isinstance(p, str) or not p or len(p) > 32767 or "\x00" in p for p in paths):
                raise ValueError("Invalid path")
        except (ValueError, UnicodeError):
            socket.abort()
            return
        self.clients.pop(socket, None)
        socket.write(b"OK")
        socket.disconnectFromServer()
        # Defer dialogs/file decoding until the receiver has acknowledged the IPC.
        QTimer.singleShot(0, lambda: self.callback(paths))
