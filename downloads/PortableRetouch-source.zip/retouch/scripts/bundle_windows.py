"""Assemble a Windows x64 BAT edition from verified official binary packages.

Runs on Linux or Windows. No native compilation or target-side installation.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile
from urllib.request import urlopen
from urllib.parse import urlsplit
import zipfile

ROOT = Path(__file__).resolve().parents[1]
QT_MODULES = {'QtCore', 'QtGui', 'QtWidgets', 'QtNetwork', 'QtTest', 'QtOpenGL'}
MAX_ARCHIVE_BYTES = 200 * 1024 * 1024
MAX_EXTRACTED_BYTES = 1024 * 1024 * 1024


def digest(data, algorithm='sha256'):
    return hashlib.new(algorithm, data).hexdigest()


def fetch(cache, filename, url, expected, algorithm='sha256'):
    if '/' in filename or '\\' in filename or filename in {'.', '..'}:
        raise ValueError('Invalid artifact filename')
    address = urlsplit(url)
    if (address.scheme != 'https' or address.hostname not in {'api.nuget.org', 'files.pythonhosted.org'}
            or address.username or address.password or address.port not in {None, 443}):
        raise ValueError('Only official HTTPS artifact hosts are allowed')
    target = cache / filename
    if target.exists():
        data = target.read_bytes()
    else:
        # Official HTTPS hosts checked above; TLS verification remains enabled.
        with urlopen(url, timeout=60) as response:  # nosec B310
            data = response.read(MAX_ARCHIVE_BYTES+1)
    if len(data) > MAX_ARCHIVE_BYTES or digest(data, algorithm) != expected:
        raise ValueError(f'Artifact checksum failed: {filename}')
    if not target.exists():
        target.write_bytes(data)
    return data


def safe_name(name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name:
        raise ValueError(f'Unsafe archive member: {name}')
    return path


def keep_qt(path):
    parts = path.parts
    if not parts or parts[0] != 'PySide6':
        return True
    if len(parts) == 2:
        name = path.name
        if name.endswith('.exe'):
            return False  # Qt development tools need additional unused modules.
        if name.endswith('.pyd'):
            return name[:-4] in QT_MODULES
        if name.startswith('Qt6') and name.endswith('.dll'):
            return 'Qt' + name[3:-4] in QT_MODULES
        if name == 'pyside6qml.abi3.dll':
            return False
    if len(parts) > 2:
        if parts[1] == 'plugins':
            return len(parts) > 3 and parts[2] in {'platforms', 'styles'}
        if parts[1] in {'qml', 'include', 'typesystems', 'metatypes', 'glue', 'doc', 'examples'}:
            return False
    return True


def unpack(data, destination, python=False):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        if sum(info.file_size for info in archive.infolist()) > MAX_EXTRACTED_BYTES:
            raise ValueError('Expanded package exceeds size limit')
        for info in archive.infolist():
            path = safe_name(info.filename)
            if info.is_dir():
                continue
            if python:
                if not path.parts or path.parts[0] != 'tools':
                    continue
                path = PurePosixPath(*path.parts[1:])
                # Package managers and their multi-architecture launch stubs are
                # unnecessary in the offline application runtime.
                if path.parts[0] == 'Scripts':
                    continue
                if len(path.parts) >= 3 and path.parts[:2] == ('Lib', 'site-packages'):
                    continue
            else:
                if path.parts[0].endswith('.data'):
                    if len(path.parts) < 3 or path.parts[1] not in {'purelib', 'platlib'}:
                        continue
                    path = PurePosixPath(*path.parts[2:])
                if not keep_qt(path):
                    continue
            target = destination.joinpath(*path.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as src, target.open('wb') as dst:
                shutil.copyfileobj(src, dst)


def bundle(cache, output):
    lock = json.loads((ROOT / 'windows-runtime.lock.json').read_text())
    cache.mkdir(parents=True, exist_ok=True)
    output.mkdir(parents=True, exist_ok=True)
    expected = base64.b64decode(lock['python_sha512'], validate=True).hex()
    python = fetch(cache, f"python.{lock['python_version']}.nupkg", lock['python_url'], expected, 'sha512')
    wheels = [(wheel, fetch(cache, wheel['filename'], wheel['url'], wheel['sha256'])) for wheel in lock['wheels']]
    with tempfile.TemporaryDirectory(prefix='retouch-package-', dir=output) as temporary:
        app = Path(temporary) / 'PortableRetouch'
        runtime = app / '_runtime'
        unpack(python, runtime, python=True)
        site = runtime / 'Lib' / 'site-packages'
        for wheel, data in wheels:
            if len(data) != wheel['size']:
                raise ValueError(f"Wheel size mismatch: {wheel['filename']}")
            unpack(data, site)
        shutil.copytree(ROOT / 'retouch', app / 'retouch', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        for name in ['launcher.py', 'Start-Retouch.bat', 'Check-Retouch.bat', 'START-HERE.txt', 'README.md', 'THIRD_PARTY_NOTICES.md', 'VALIDATION.md', 'windows-runtime.lock.json']:
            shutil.copy2(ROOT / name, app / name)
        shutil.copytree(ROOT / 'licenses', app / 'licenses')
        for name in ['python.exe', 'pythonw.exe', 'python313.dll', 'Lib/os.py']:
            if not (runtime / name).is_file():
                raise ValueError(f'Missing Python runtime file: {name}')
        for name in ['QtCore.pyd', 'QtGui.pyd', 'QtWidgets.pyd', 'QtNetwork.pyd', 'QtTest.pyd', 'Qt6Core.dll', 'Qt6Gui.dll', 'Qt6Widgets.dll', 'Qt6Network.dll', 'Qt6Test.dll', 'pyside6.abi3.dll', 'plugins/platforms/qwindows.dll', 'plugins/platforms/qoffscreen.dll']:
            if not (site / 'PySide6' / name).is_file():
                raise ValueError(f'Missing Qt runtime file: {name}')
        # Every shipped native image must be an AMD64 PE, not a Linux binary.
        for path in runtime.rglob('*'):
            if path.suffix.lower() not in {'.exe', '.dll', '.pyd'}:
                continue
            data = path.read_bytes()
            offset = int.from_bytes(data[60:64], 'little')
            if data[:2] != b'MZ' or data[offset:offset+4] != b'PE\0\0' or data[offset+4:offset+6] != b'd\x86':
                raise ValueError(f'Not a Windows x64 native binary: {path.name}')
        archive_path = output / 'PortableRetouch-windows-x64.zip'
        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(app.rglob('*')):
                if path.is_file():
                    archive.write(path, path.relative_to(app.parent))
        with zipfile.ZipFile(archive_path) as archive:
            bad = archive.testzip()
            if bad:
                raise ValueError(f'Corrupt ZIP member: {bad}')
        checksum = digest(archive_path.read_bytes())
        archive_path.with_suffix('.zip.sha256').write_text(f'{checksum}  {archive_path.name}\n', encoding='ascii')
        # Retain the exact folder for optional native/Wine verification.
        extracted = output / 'PortableRetouch-BAT'
        if extracted.exists():
            raise FileExistsError(f'Remove the previous generated test folder first: {extracted}')
        shutil.move(str(app), extracted)
        print(f'{archive_path} ({archive_path.stat().st_size:,} bytes)')
        return archive_path


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cache', type=Path, default=ROOT / 'build' / 'windows-cache')
    parser.add_argument('--output', type=Path, default=ROOT / 'dist')
    args = parser.parse_args()
    bundle(args.cache.resolve(), args.output.resolve())
