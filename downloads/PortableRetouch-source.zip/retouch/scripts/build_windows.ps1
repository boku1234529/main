$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Set-Location (Split-Path $PSScriptRoot -Parent)
if ($PSVersionTable.PSEdition -eq 'Core' -and -not $IsWindows) {
    throw 'Build on Windows.'
}
# Run with PowerShell 7 on Windows, or Windows PowerShell 5.1.
function Check-Exit([string]$Step) {
    if ($LASTEXITCODE -ne 0) { throw "$Step failed (exit $LASTEXITCODE)" }
}
if (-not (Test-Path '.venv/Scripts/python.exe')) {
    py -3.12 -m venv .venv
    Check-Exit 'venv'
}
$Python = Join-Path $PWD '.venv/Scripts/python.exe'
& $Python -m pip install --upgrade pip==26.2.2
Check-Exit 'pip security update'
& $Python -m pip install -r requirements-dev.txt
Check-Exit 'dependencies'
$env:QT_QPA_PLATFORM = 'offscreen'
& $Python -m pytest -q
Check-Exit 'tests'
& $Python -m pip_audit -r requirements.txt --no-deps --disable-pip --progress-spinner off
Check-Exit 'dependency audit'
& $Python -m pip_audit --local --progress-spinner off
Check-Exit 'build environment audit'
& $Python -m bandit -r retouch -q
Check-Exit 'static security scan'
& $Python -m PyInstaller --noconfirm --clean --windowed --onedir --name PortableRetouch --exclude-module PySide6.QtWebEngineCore --exclude-module PySide6.QtWebEngineWidgets --exclude-module PySide6.QtPdf --exclude-module PySide6.QtQml --exclude-module PySide6.QtQuick launcher.py
Check-Exit 'PyInstaller'
$Smoke = Start-Process -FilePath (Join-Path $PWD 'dist/PortableRetouch/PortableRetouch.exe') -ArgumentList '--self-test' -PassThru
if (-not $Smoke.WaitForExit(60000)) {
    $Smoke.Kill()
    throw 'Packaged executable smoke test timed out.'
}
if ($Smoke.ExitCode -ne 0) { throw "Packaged executable smoke test failed: $($Smoke.ExitCode)" }
& $Python scripts/package.py
Check-Exit 'portable ZIP'
Write-Host 'Ready: dist/PortableRetouch-windows-x64.zip'
