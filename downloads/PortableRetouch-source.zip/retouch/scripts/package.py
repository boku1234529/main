"""Package an already built onedir application with documentation and notices."""
import hashlib
from importlib import metadata
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent.parent
app = root / 'dist' / 'PortableRetouch'
if not (app / 'PortableRetouch.exe').is_file():
    raise SystemExit('Build the Windows executable first.')
for name in ['README.md', 'THIRD_PARTY_NOTICES.md']:
    shutil.copy2(root / name, app / name)
licenses = app / 'licenses'
licenses.mkdir(exist_ok=True)
for name in ['Pillow', 'PySide6-Essentials', 'shiboken6']:
    dist = metadata.distribution(name)
    for file in dist.files or []:
        if 'license' in str(file).lower() and dist.locate_file(file).is_file():
            target = licenses / name / str(file).replace('..', '_')
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dist.locate_file(file), target)
for file in (root / 'licenses').glob('*'):
    shutil.copy2(file, licenses / file.name)
output = root / 'dist' / 'PortableRetouch-windows-x64.zip'
with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(app.rglob('*')):
        if path.is_file():
            archive.write(path, path.relative_to(app.parent))
checksum = hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix('.zip.sha256').write_text(f'{checksum}  {output.name}\n', encoding='ascii')
print(output)
