# Third-party software

This application uses the following unmodified libraries:

- Pillow 13.0.0 — HPND and bundled-library notices. https://github.com/python-pillow/Pillow/tree/13.0.0
- PySide6 Essentials and Shiboken6 6.12.0 — LGPL-3.0-only (alternative GPL licensing is also offered by upstream). https://code.qt.io/cgit/pyside/pyside-setup.git/tree/?h=6.12.0
- Qt libraries bundled with PySide6 — use the applicable LGPL-3.0 terms and any accompanying third-party notices. https://code.qt.io/cgit/qt/qtbase.git/tree/?h=6.12.0
- Python runtime packaged by PyInstaller — PSF License. https://docs.python.org/3/license.html
- PyInstaller bootloader — GPL-2.0-or-later with the PyInstaller bootloader exception permitting distribution of generated applications. https://pyinstaller.org/en/stable/license.html

The portable onedir layout retains dynamically linked Qt libraries. Users may replace or debug these libraries in accordance with their licenses; the application does not impose a restriction on reverse engineering for debugging modifications to LGPL components. This application does not modify these libraries. Corresponding upstream source is available from the links above. License texts and available package notices are included under licenses/ and in bundled package metadata. The PySide6 package includes modules not used by this application; the build excludes WebEngine, PDF, QML, and Quick imports.

The licenses/ LGPL/GPL texts are obtained from the official qt/qtbase v6.8.0 LICENSES directory; the license texts themselves are not release-specific.

## BAT portable edition

The BAT edition bundles the official Python Software Foundation Windows x64 Python 3.13.17 NuGet runtime. Its PSF license is retained at _runtime/LICENSE.txt. Windows wheels are verified against official PyPI SHA-256 values, and the Python package is verified against its official NuGet catalog SHA-512. See windows-runtime.lock.json. Only the Qt modules and plugins used by this application are retained; library binaries are not modified. Windows-provided system APIs, including ICU and Windows Color System, remain OS dependencies. Wine-only test helper libraries are not included.
