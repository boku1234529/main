@echo off
setlocal
if not exist "%~dp0_runtime\pythonw.exe" goto missing
start "" "%~dp0_runtime\pythonw.exe" -E -s "%~dp0launcher.py"
if errorlevel 1 goto failed
exit /b 0
:missing
echo Extract the entire Windows portable ZIP first.
echo Keep Start-Retouch.bat, launcher.py, retouch and _runtime together.
pause
exit /b 1
:failed
echo Could not start Portable Retouch. Run Check-Retouch.bat for diagnostics.
pause
exit /b 1
