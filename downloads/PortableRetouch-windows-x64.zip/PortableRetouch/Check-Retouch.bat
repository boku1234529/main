@echo off
setlocal
if not exist "%~dp0_runtime\python.exe" goto missing
set "QT_QPA_PLATFORM=offscreen"
"%~dp0_runtime\python.exe" -E -s "%~dp0launcher.py" --self-test
if errorlevel 1 goto failed
echo PASS: bundled runtime, drawing, undo/redo and PNG/JPG saving.
pause
exit /b 0
:missing
echo Missing runtime. Extract the entire Windows portable ZIP first.
pause
exit /b 1
:failed
echo FAIL: please send the error message shown above.
pause
exit /b 1
