import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from tools import bootstrap


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.marker = Path(self.temp.name) / '日本語 path with spaces.ready'
        self.env = patch.dict(os.environ, {'ANIMA_PYTHON_MARKER': str(self.marker)})
        self.env.start()

    def tearDown(self):
        self.env.stop(); self.temp.cleanup()

    def test_supported_interpreter_runs_real_probe_and_writes_marker(self):
        result = subprocess.run([sys.executable, str(Path(bootstrap.__file__)), '--probe-only'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('[OK] Python', result.stdout)
        self.assertEqual(self.marker.read_bytes(), b'ready')

    def test_supported_candidate_passes_app_args_and_exit_status(self):
        with patch('tools.bootstrap.subprocess.run', return_value=subprocess.CompletedProcess([], 7)) as run:
            self.assertEqual(bootstrap.main(['--diagnose']), 7)
            command = run.call_args.args[0]
            self.assertEqual(command[0], sys.executable)
            self.assertEqual(command[-1], '--diagnose')
            self.assertTrue(command[1].endswith(os.path.join('tools', 'launcher.py')))
        self.assertTrue(self.marker.exists())  # App failure must not try another Python.

    def test_unsupported_version_has_no_success_marker(self):
        for version in [(3, 9), (3, 13), (3, 14)]:
            with self.subTest(version=version), patch.object(bootstrap.sys, 'version_info', version), patch('tools.bootstrap.subprocess.run') as run:
                self.assertEqual(bootstrap.main(['--probe-only']), 42)
                self.assertFalse(self.marker.exists()); run.assert_not_called()

    def test_32bit_interpreter_rejected_without_marker(self):
        with patch('tools.bootstrap.struct.calcsize', return_value=4), patch('tools.bootstrap.subprocess.run') as run:
            self.assertEqual(bootstrap.main(['--probe-only']), 42)
            self.assertFalse(self.marker.exists()); run.assert_not_called()

    def test_nonexistent_executable_rejected_without_marker(self):
        with patch.object(bootstrap.sys, 'executable', str(self.marker.parent / 'missing.exe')):
            self.assertEqual(bootstrap.main(['--probe-only']), 42)
            self.assertFalse(self.marker.exists())

    def test_existing_marker_not_overwritten_and_no_app_started(self):
        self.marker.write_bytes(b'preserve existing file')
        with patch('tools.bootstrap.subprocess.run') as run:
            self.assertEqual(bootstrap.main(), 43)
            run.assert_not_called()
        self.assertEqual(self.marker.read_bytes(), b'preserve existing file')

    def test_launch_failure_keeps_accepted_marker_for_correct_error(self):
        with patch('tools.bootstrap.subprocess.run', side_effect=OSError('simulated failure')):
            self.assertEqual(bootstrap.main(), 1)
        self.assertTrue(self.marker.exists())

    def test_paths_with_spaces_and_unicode_not_passed_through_cmd(self):
        executable = self.marker.parent / '日本語 Python folder' / 'python.exe'
        executable.parent.mkdir(); executable.touch()
        with patch.object(bootstrap.sys, 'executable', str(executable)), patch('tools.bootstrap.subprocess.run', return_value=subprocess.CompletedProcess([], 0)) as run:
            self.assertEqual(bootstrap.main(['--diagnose']), 0)
            self.assertEqual(run.call_args.args[0][0], str(executable))
            self.assertNotIn('shell', run.call_args.kwargs)


if __name__ == '__main__': unittest.main()
