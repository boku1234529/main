import unittest
from backend import tag_rules as rules


class TagRuleTests(unittest.TestCase):
    def test_spec_normalization_preserves_meaningful_plurals(self):
        values = ['dark-blue dress', 'navy_blue_dress', 'green green school uniforms', 'white high socks', ':d', '^_^', '2girls']
        self.assertEqual([rules.normalize(t) for t in values], ['dark blue dress', 'navy blue dress', 'green school uniform', 'white high socks', ':d', '^_^', '2girls'])

    def test_category_word_boundaries_and_lighting(self):
        cases = {'green school uniform':'CLOTHING', 'navy blue and white striped pantyhose':'LEGWEAR',
                 'uwabaki':'FOOTWEAR','purple backpack':'ACCESSORY','neck ribbon':'ACCESSORY',
                 'pink eyes':'EYES','bob hair':'HAIR','looking at viewer':'GAZE',
                 'warm lighting':'LIGHTING','evening':'LIGHTING','rough lineart':'STYLE',
                 'classroom':'BACKGROUND','side view':'COMPOSITION','holding note':'ACTION',
                 'open mouth':'EXPRESSION','hands on hips':'POSE','2girls':'COUNT', 'unrecognized':'UNKNOWN'}
        for tag, expected in cases.items():
            with self.subTest(tag=tag): self.assertEqual(rules.category(tag), expected)

    def test_specific_tags_remove_all_generic_variants(self):
        tags = ['socks','white socks','high socks','white high socks','pantyhose','striped pantyhose',
                'navy blue and white striped pantyhose','ribbon','red ribbon','neck ribbon','red neck ribbon',
                'bob cut','bob hair','2girls','multiple girls']
        kept, deleted, warnings = rules.organize(tags)
        self.assertEqual(kept, ['white high socks','navy blue and white striped pantyhose','red neck ribbon','bob hair','2girls'])
        self.assertEqual(len(deleted), 10); self.assertTrue(any('bob hair' in w for w in warnings))

    def test_merge_only_known_compatible_combinations(self):
        self.assertEqual(rules.organize(['red ribbon','neck ribbon','white socks','high socks'])[0], ['red neck ribbon','white high socks'])
        self.assertEqual(rules.organize(['purple ribbon','neck ribbon'])[0], ['purple ribbon','neck ribbon'])

    def test_quality_and_faces_are_candidates_not_caption_attributes(self):
        result=rules.classify([':d', ':)', ':3', '^_^', 'best quality', 'green dress'], 'a')
        self.assertEqual(result['a_tags'], ['green dress']); self.assertEqual(len(result['deleted_tags']),5)
        self.assertNotIn(':d', rules.build_multichar_caption('a','A','B',[':d'],[],[])[0])

    def test_single_person_categories_and_shared_scene(self):
        tags=['pink hair','blue eyes','green dress','white socks','uwabaki','backpack','smile','holding pen',
              'standing','looking at viewer','simple background','warm lighting','full body','anime style','1girl','solo']
        for mode in ('a','b'):
            result=rules.classify(tags,mode)
            self.assertEqual(len(result[mode+'_tags']),10)
            self.assertEqual(len(result['common_tags']),6)
            self.assertEqual(result['unclassified_tags'],[])

    def test_two_person_attributes_are_never_shared_or_guessed(self):
        result=rules.classify(['pink hair','purple hair','smile','holding pen','standing','unknown object','full body','2girls','multiple girls'],'both')
        self.assertEqual(result['a_tags'],[]); self.assertEqual(result['b_tags'],[])
        self.assertEqual(result['common_tags'],['full body','2girls'])
        self.assertIn('pink hair',result['unclassified_tags']);self.assertIn('smile',result['unclassified_tags'])
        self.assertTrue(any('未分類' in w for w in result['warnings']))

    def test_unassigned_two_person_clothes_never_merge_across_people(self):
        result=rules.classify(['red ribbon','neck ribbon','white socks','white high socks'],'both')
        self.assertEqual(result['unclassified_tags'],['red ribbon','neck ribbon','white socks','white high socks'])
        self.assertEqual(result['deleted_tags'],[])

    def test_trigger_and_outfit_excluded_from_attribute_buckets(self):
        result=rules.classify(['yasumin','oldname','outfit ya01','smile'],'a','yasumin','B','outfit ya01',aliases=['oldname'])
        self.assertEqual(result['identity_tags'],['yasumin','oldname','outfit ya01']);self.assertEqual(result['a_tags'],['smile'])

    def test_conflicts_conservative_clothing_threshold(self):
        warnings=rules.conflicts(['pink hair','purple hair','pink eyes','red eyes','holding pen','holding pencil'],'A')
        self.assertEqual(len(warnings),3)
        self.assertEqual(rules.conflicts(['dress','skirt'],'A'),[])
        self.assertTrue(rules.conflicts(['green dress','green school uniform','pleated dress','pleated skirt'],'A'))

    def test_minimal_both_defaults_and_standard_explicit(self):
        args=('both','yasumin','stndrgn',['pink hair','green dress','smile'],['purple hair','navy blue dress'],['full body','simple background'])
        caption,_=rules.build_multichar_caption(*args,outfit_a='outfit ya01',outfit_b='outfit st01')
        self.assertEqual(caption,'yasumin and stndrgn, 2girls. yasumin wears outfit ya01. stndrgn wears outfit st01. Composition: full body.')
        detailed,_=rules.build_multichar_caption(*args,outfit_a='outfit ya01',outfit_b='outfit st01',caption_mode='standard')
        self.assertIn('a green dress',detailed);self.assertIn('a navy blue dress',detailed)
        self.assertNotIn('pink hair',detailed);self.assertNotIn('smiling',detailed);self.assertNotIn('Scene:',detailed)

    def test_yasumin_spec_example_detailed(self):
        tags=['pink hair','pink eyes','updo','green school uniform','green jacket','red ribbon','neck ribbon',
              'white socks','high socks','sneakers','smile','open mouth','full body','simple background']
        result=rules.classify(tags,'a','yasumin','stndrgn')
        caption,_=rules.build_multichar_caption('a','yasumin','stndrgn',result['a_tags'],[],result['common_tags'],outfit_a='outfit ya01')
        self.assertEqual(caption,'yasumin, 1girl, solo. yasumin wears outfit ya01, a green school uniform, a green jacket, a red neck ribbon, white high socks, and sneakers. yasumin is smiling with an open mouth. Composition: full body. Scene: simple background.')
        self.assertNotIn('pink',caption);self.assertNotIn('updo',caption)

    def test_stndrgn_spec_example(self):
        tags=['purple hair','purple eyes','bob hair','navy blue dress','pantyhose','striped pantyhose',
              'navy blue and white striped pantyhose','uwabaki','purple backpack','full body']
        result=rules.classify(tags,'b','yasumin','stndrgn')
        caption,_=rules.build_multichar_caption('b','yasumin','stndrgn',[],result['b_tags'],result['common_tags'],outfit_b='outfit st01')
        self.assertIn('stndrgn wears outfit st01, a navy blue dress, navy blue and white striped pantyhose, uwabaki, and a purple backpack.',caption)
        self.assertNotIn('purple eyes',caption);self.assertEqual(caption.count('pantyhose'),1)

    def test_individual_generation_switches(self):
        args=('a','A','B',['pink hair','pink eyes','smile','holding pen','looking at viewer','green dress'],[],['full body','simple background','warm lighting','anime style'])
        default,_=rules.build_multichar_caption(*args)
        self.assertNotIn('pink hair',default);self.assertNotIn('looking',default);self.assertNotIn('Style:',default)
        enabled,_=rules.build_multichar_caption(*args,include_identity=True,include_gaze=True,include_style=True)
        self.assertIn('pink hair',enabled);self.assertIn('looking at viewer',enabled);self.assertIn('Style:',enabled)
        disabled,_=rules.build_multichar_caption(*args,include_action=False,include_expression=False,include_clothing=False,
                                                include_scene=False,include_lighting=False,include_composition=False)
        self.assertEqual(disabled,'A, 1girl, solo.')

    def test_inactive_character_never_contributes_scene(self):
        caption,_=rules.build_multichar_caption('a','A','B',[],['green dress','classroom'],[])
        self.assertEqual(caption,'A, 1girl, solo.')

    def test_shared_ambiguous_person_tags_suppressed_in_both(self):
        caption,warnings=rules.build_multichar_caption('both','A','B',[],[],['smile','looking at viewer','pink hair','full body'],caption_mode='detailed',include_gaze=True,include_identity=True)
        self.assertEqual(caption,'A and B, 2girls. Composition: full body.')
        self.assertTrue(any('共通内' in w for w in warnings))

    def test_cleanup_and_warning_switches(self):
        self.assertEqual(rules.organize(['socks','white socks'],False)[0],['socks','white socks'])
        caption,warnings=rules.build_multichar_caption('a','A','B',['pink eyes','red eyes'],[],[],show_warnings=False)
        self.assertEqual(warnings,[])

    def test_shared_pose_requires_explicit_confirmation_and_detailed(self):
        args=('both','A','B',[],[],['standing','full body'])
        default,_=rules.build_multichar_caption(*args,caption_mode='detailed')
        self.assertNotIn('standing',default)
        confirmed,_=rules.build_multichar_caption(*args,caption_mode='detailed',include_shared_pose=True)
        self.assertIn('Shared pose: standing.',confirmed)
        minimal,_=rules.build_multichar_caption(*args,include_shared_pose=True)
        self.assertNotIn('Shared pose:',minimal)

    def test_count_uses_boys_when_only_boys_evidence(self):
        caption,_=rules.build_multichar_caption('b','A','B',[],[],['1boy','solo'])
        self.assertEqual(caption,'B, 1boy, solo.')

if __name__=='__main__':unittest.main()
