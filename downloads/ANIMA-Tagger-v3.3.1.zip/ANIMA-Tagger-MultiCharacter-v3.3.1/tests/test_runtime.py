import os
from pathlib import Path
import socket
import tempfile
import unittest
from unittest.mock import patch
from backend.runtime_support import supported_python, bind_app_socket, dependency_key
from tools.launcher import runtime_location, prepare_runtime, python_path

ROOT = Path(__file__).resolve().parent.parent


class RuntimeTests(unittest.TestCase):
    def test_only_installed_64bit_python_310_to_312(self):
        for version in [(3, 10), (3, 11), (3, 12)]: self.assertTrue(supported_python(version, 64))
        for version in [(3, 9), (3, 13), (2, 7), (4, 0)]: self.assertFalse(supported_python(version, 64))
        self.assertFalse(supported_python((3, 12), 32))

    def test_busy_port_fallback_and_held_binding(self):
        with socket.socket() as occupied:
            occupied.bind(('127.0.0.1', 0)); occupied.listen()
            port = occupied.getsockname()[1]
            with bind_app_socket(port, max_tries=1) as selected:
                self.assertNotEqual(selected.getsockname()[1], port)
                with socket.socket() as contender:
                    with self.assertRaises(OSError): contender.bind(selected.getsockname())

    def test_invalid_port_is_rejected(self):
        for port in [0, -1, 65536]:
            with self.assertRaises(ValueError): bind_app_socket(port)

    def test_dependency_hash_not_source_location_or_version_name(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for name in ['requirements-core.txt', 'requirements.txt']:
                (root / name).write_bytes((ROOT / name).read_bytes())
            expected = dependency_key(ROOT, 'cpu', (3, 12))
            self.assertEqual(expected, dependency_key(root, 'cpu', (3, 12)))
            (root / 'requirements.txt').write_text('changed')
            self.assertNotEqual(expected, dependency_key(root, 'cpu', (3, 12)))
            self.assertNotEqual(expected, dependency_key(ROOT, 'cu128', (3, 12)))
            self.assertNotEqual(expected, dependency_key(ROOT, 'cpu', (3, 11)))

    def test_shared_path_and_override(self):
        with patch.dict(os.environ, {'ANIMA_RUNTIME_DIR': '/tmp/anima-runtime-test'}):
            stable, venv = runtime_location('editor')
            self.assertEqual(stable, Path('/tmp/anima-runtime-test'))
            self.assertEqual(venv.parent, stable / 'runtimes')

    def test_valid_marker_does_not_reinstall(self):
        import json
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {'ANIMA_RUNTIME_DIR': temp}):
            stable, venv = runtime_location('editor'); python = python_path(venv)
            python.parent.mkdir(parents=True); python.touch()
            (venv / '.anima-deps-ready.json').write_text(json.dumps({'key': dependency_key(ROOT, 'editor'), 'profile': 'editor'}))
            with patch('tools.launcher.check_runtime') as check, patch('tools.launcher.run') as run:
                self.assertEqual(prepare_runtime('editor'), (python, stable))
                check.assert_called_once(); run.assert_not_called()

    def test_incomplete_env_never_deleted(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {'ANIMA_RUNTIME_DIR': temp}):
            _, venv = runtime_location('editor'); venv.mkdir(parents=True)
            sentinel = venv / 'user-file'; sentinel.write_text('keep')
            with self.assertRaisesRegex(RuntimeError, 'Incomplete runtime'): prepare_runtime('editor')
            self.assertEqual(sentinel.read_text(), 'keep')
            self.assertFalse(venv.with_name(venv.name + '.setup-lock').exists())

    def test_bat_uses_shared_bootstrap_and_no_inline_python(self):
        for filename in ['start.bat', 'diagnose.bat']:
            source = (ROOT / filename).read_text()
            self.assertIn('tools\\run_windows.bat', source)
            self.assertIn('DisableDelayedExpansion', source)
            self.assertNotIn(' -c ', source)
        source = (ROOT / 'tools' / 'run_windows.bat').read_text()
        self.assertNotIn('for /f', source.lower())
        self.assertNotIn(' -c ', source)
        self.assertNotIn('rmdir', source.lower())
        self.assertIn('ANIMA_PYTHON', source)
        for version in ['3.12', '3.11', '3.10']:
            self.assertIn('py -' + version + ' tools\\bootstrap.py', source)
        self.assertIn('if exist "%ANIMA_PYTHON_MARKER%" goto :finished', source)


if __name__ == '__main__': unittest.main()
