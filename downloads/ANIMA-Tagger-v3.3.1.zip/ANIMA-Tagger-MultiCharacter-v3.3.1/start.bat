@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
call tools\run_windows.bat %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if not "%ANIMA_EXIT%"=="0" pause
exit /b %ANIMA_EXIT%
