"""Run with each candidate interpreter, avoiding Python code embedded in CMD.

A ready marker is created only by an actual supported Python, before starting
launcher.py. The batch caller uses it to distinguish app failure from a missing
runtime, even when the Windows py launcher returns inconsistent exit codes.
"""
import os
import struct
import subprocess
import sys


def validate_interpreter():
    version = sys.version_info[:2]
    bits = struct.calcsize('P') * 8
    executable = sys.executable
    if not ((3, 10) <= version <= (3, 12)) or bits != 64:
        return False, 'Detected Python {}.{} ({}-bit); need 64-bit Python 3.10-3.12.'.format(version[0], version[1], bits)
    if not executable or not os.path.isfile(executable):
        return False, 'The reported Python executable does not exist.'
    return True, '[OK] Python {}.{} ({}-bit): {}'.format(version[0], version[1], bits, executable)


def main(args=None):
    args = sys.argv[1:] if args is None else list(args)
    valid, message = validate_interpreter()
    print(message, flush=True)
    if not valid:
        return 42
    marker = os.environ.get('ANIMA_PYTHON_MARKER')
    if marker:
        try:
            # Never overwrite a pre-existing file. Unicode paths remain inside Python.
            with open(marker, 'xb') as ready:
                ready.write(b'ready')
        except OSError as exc:
            print('[ERROR] Could not create Python detection marker: {}'.format(exc), file=sys.stderr)
            return 43
    if args == ['--probe-only']:
        return 0
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    launcher = os.path.join(root, 'tools', 'launcher.py')
    try:
        result = subprocess.run([sys.executable, launcher] + args, cwd=root)
        return result.returncode
    except KeyboardInterrupt:
        return 0
    except OSError as exc:
        print('[ERROR] Could not start launcher.py: {}'.format(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
