@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."

:choose_marker
set "ANIMA_PYTHON_MARKER=%TEMP%\anima-python-%RANDOM%-%RANDOM%.ready"
if exist "%ANIMA_PYTHON_MARKER%" goto :choose_marker

if defined ANIMA_PYTHON goto :explicit_python

echo [CHECK] py -3.12
py -3.12 tools\bootstrap.py %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if exist "%ANIMA_PYTHON_MARKER%" goto :finished

echo [CHECK] py -3.11
py -3.11 tools\bootstrap.py %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if exist "%ANIMA_PYTHON_MARKER%" goto :finished

echo [CHECK] py -3.10
py -3.10 tools\bootstrap.py %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if exist "%ANIMA_PYTHON_MARKER%" goto :finished

echo [CHECK] python on PATH
python tools\bootstrap.py %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if exist "%ANIMA_PYTHON_MARKER%" goto :finished

echo [CHECK] python3 on PATH
python3 tools\bootstrap.py %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if exist "%ANIMA_PYTHON_MARKER%" goto :finished

echo.
echo [ERROR] No compatible Python could run tools\bootstrap.py.
echo [INFO] Required: installed 64-bit Python 3.10, 3.11 or 3.12.
echo [INFO] This message alone does not prove Python is uninstalled.
echo [INFO] The detection errors are shown above.
echo [INFO] Check: py --list-paths, python --version, where python
echo [INFO] You can set ANIMA_PYTHON to the full path of python.exe.
exit /b 1

:explicit_python
echo [CHECK] Using ANIMA_PYTHON
"%ANIMA_PYTHON%" tools\bootstrap.py %*
set "ANIMA_EXIT=%ERRORLEVEL%"
if exist "%ANIMA_PYTHON_MARKER%" goto :finished
echo [ERROR] ANIMA_PYTHON could not run a supported 64-bit Python.
echo [INFO] Check the path and the detection error shown above.
exit /b 1

:finished
del /q "%ANIMA_PYTHON_MARKER%" >nul 2>&1
exit /b %ANIMA_EXIT%
