"""Shared Windows runtime. Source releases with identical requirements reuse one venv."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from backend.runtime_support import dependency_key, supported_python, TORCH_PACKAGES


def runtime_location(profile):
    override = os.environ.get('ANIMA_RUNTIME_DIR')
    stable = Path(override) if override else Path(os.environ.get('LOCALAPPDATA', Path.home() / '.local' / 'share')) / 'ANIMA-Tagger'
    return stable, stable / 'runtimes' / dependency_key(ROOT, profile)


def python_path(venv):
    return venv / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def run(args, **kwargs):
    subprocess.run([str(a) for a in args], check=True, **kwargs)


def check_runtime(python, profile):
    modules = 'fastapi,uvicorn,PIL' if profile == 'editor' else 'fastapi,uvicorn,PIL,torch,torchvision,transformers,onnxruntime,pandas,numpy,huggingface_hub,qwen_vl_utils'
    run([python, '-c', f'import {modules}'])


def prepare_runtime(profile):
    stable, venv = runtime_location(profile)
    stable.mkdir(parents=True, exist_ok=True)
    venv.parent.mkdir(parents=True, exist_ok=True)
    lock = venv.with_name(venv.name + '.setup-lock')
    deadline = time.monotonic() + 600
    while True:
        try:
            lock.mkdir()
            break
        except FileExistsError:
            if time.monotonic() > deadline:
                raise RuntimeError(f'Setup lock still exists: {lock}. Close other setup windows. After an interrupted setup, inspect this lock manually; no environment is deleted automatically.')
            time.sleep(1)
    try:
        python = python_path(venv)
        if venv.exists() and not python.exists():
            raise RuntimeError(f'Incomplete runtime: {venv}. It was preserved. Set ANIMA_RUNTIME_DIR to a new location or inspect/repair it manually.')
        if not python.exists():
            run([sys.executable, '-m', 'venv', venv])
        marker = venv / '.anima-deps-ready.json'
        expected = {'key': dependency_key(ROOT, profile), 'profile': profile}
        if marker.exists():
            try:
                if json.loads(marker.read_text()) == expected:
                    check_runtime(python, profile)
                    return python, stable
            except (ValueError, subprocess.CalledProcessError):
                pass
        run([python, '-m', 'pip', 'install', '--upgrade', 'pip', 'setuptools', 'wheel'])
        run([python, '-m', 'pip', 'install', '-r', ROOT / 'requirements-core.txt'])
        if profile != 'editor':
            index = 'https://download.pytorch.org/whl/' + profile
            run([python, '-m', 'pip', 'install', *TORCH_PACKAGES, '--index-url', index])
            run([python, '-m', 'pip', 'install', '-r', ROOT / 'requirements.txt'])
        run([python, '-m', 'pip', 'check'])
        check_runtime(python, profile)
        marker.write_text(json.dumps(expected), encoding='utf-8')
        return python, stable
    finally:
        lock.rmdir()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--diagnose', action='store_true')
    parser.add_argument('--download-models', action='store_true')
    args = parser.parse_args()
    if not supported_python():
        raise RuntimeError('64-bit Python 3.10, 3.11 or 3.12 is required')
    profile = 'editor' if os.environ.get('ANIMA_EDITOR_ONLY') == '1' else os.environ.get('ANIMA_TORCH_PROFILE', 'cu128')
    if profile not in ('editor', 'cu128', 'cpu'):
        raise RuntimeError('ANIMA_TORCH_PROFILE must be cu128 or cpu')
    stable, venv = runtime_location(profile)
    os.environ.setdefault('HF_HOME', str(stable / 'models'))
    if args.diagnose:
        print('Python:', sys.executable, sys.version.split()[0])
        print('Profile:', profile, 'Runtime:', venv)
        print('Model cache:', os.environ['HF_HOME'])
        python = python_path(venv)
        if not python.exists():
            raise RuntimeError('Runtime not created. Run start.bat with the same profile first.')
        run([python, '-m', 'pip', 'check'])
        check_runtime(python, profile)
        if profile != 'editor':
            run([python, '-c', "import torch; print('torch:',torch.__version__,'CUDA:',torch.cuda.is_available(),'GPU:',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU')"])
        run([python, '-m', 'compileall', '-q', ROOT / 'backend', ROOT / 'tools'])
        return
    python, stable = prepare_runtime(profile)
    print('[OK] Shared runtime:', python, flush=True)
    os.environ.setdefault('APP_PORT', '8010')
    target = ROOT / 'backend' / ('download_models.py' if args.download_models else 'main.py')
    if args.download_models and profile == 'editor':
        raise RuntimeError('Model download requires a full runtime')
    run([python, target], cwd=ROOT)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as exc:
        print(f'[ERROR] {exc}', file=sys.stderr)
        sys.exit(1)
