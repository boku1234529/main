"""Deterministic, conservative classification for multi-character LoRA captions.
Never assigns an ambiguous person in a two-character image and never edits saved text.
"""
import re

CATEGORIES = 'IDENTITY HAIR EYES FACE CLOTHING ACCESSORY FOOTWEAR LEGWEAR POSE ACTION EXPRESSION GAZE OBJECT BACKGROUND LIGHTING COMPOSITION STYLE COUNT QUALITY UNKNOWN'.split()
PERSON = set('HAIR EYES FACE CLOTHING ACCESSORY FOOTWEAR LEGWEAR POSE ACTION EXPRESSION GAZE OBJECT'.split())
COMMON = set('BACKGROUND LIGHTING COMPOSITION STYLE COUNT'.split())
OUTFIT = set('CLOTHING ACCESSORY FOOTWEAR LEGWEAR'.split())
EMOTICONS = {':d', ':)', ':3', '^_^', '^ ^', ';)', ':p', 'xd'}
COLORS = set('black white red blue green yellow pink purple orange brown gray grey blonde blond gold silver aqua teal cyan magenta violet navy'.split())
DEFAULTS = dict(outfit_a='', outfit_b='', caption_mode='auto', include_fixed=False,
    include_identity=False, include_gaze=False, include_style=False, include_scene=True,
    include_composition=True, include_lighting=True, include_action=True,
    include_expression=True, include_clothing=True, include_shared_pose=False, auto_cleanup=True, show_warnings=True)


def normalize(tag):
    t = tag.strip().lower()
    if t in EMOTICONS: return t
    t = re.sub(r'[_-]+', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    singular = {'uniforms':'uniform', 'dresses':'dress', 'jackets':'jacket', 'skirts':'skirt',
                'shirts':'shirt', 'blouses':'blouse', 'coats':'coat', 'hoodies':'hoodie',
                'sweaters':'sweater', 'backpacks':'backpack', 'ribbons':'ribbon'}
    words = []
    for word in t.split():
        word = singular.get(word, word)
        if not words or words[-1] != word: words.append(word)
    return ' '.join(words)


def unique(tags):
    return list(dict.fromkeys(t for tag in tags if (t := normalize(tag))))


def category(tag, triggers=(), outfits=()):
    t = normalize(tag)
    if t in {normalize(x) for x in triggers if x} or t in {normalize(x) for x in outfits if x} or t.startswith('outfit '): return 'IDENTITY'
    if t in EMOTICONS or t in {'best quality','masterpiece','high quality','normal quality','low quality','worst quality','absurdres','highres','lowres','rating safe','rating general','rating sensitive','rating explicit'}: return 'QUALITY'
    if re.fullmatch(r'\d+\s*(girls?|boys?|people|persons?)', t) or t in {'solo','multiple girls','multiple boys'}: return 'COUNT'
    if t.startswith('looking ') or t in {'eye contact','gaze'}: return 'GAZE'
    if t.endswith(' hair') or t in {'bob cut','updo','ponytail','twintails','braid','braids','hair bun','bangs','ahoge'}: return 'HAIR'
    if t.endswith(' eyes') or t in {'heterochromia'}: return 'EYES'
    if t in {'smile','smiling','blush','blushing','open mouth','closed mouth','serious','angry','sad','crying','surprised','happy','laughing'}: return 'EXPRESSION'
    if t in {'standing','sitting','kneeling','lying','arms up','arm up','hands on hips','crossed arms','hand up','hands up','crouching','leaning','dynamic pose'}: return 'POSE'
    if t.startswith('holding ') or t in {'running','walking','jumping','waving','pointing','thumbs up','sleeping'}: return 'ACTION'
    if t in {'full body','upper body','cowboy shot','close up','portrait','from above','from below','side view','profile','front view','back view','symmetrical composition'}: return 'COMPOSITION'
    if any(w in t.split() for w in ('lighting','light','backlighting','backlight')) or t in {'evening','sunset','sunrise'}: return 'LIGHTING'
    if any(w in t for w in ('lineart','outline','shading','style','sketch','watercolor','painting','flat color','pastel colors','vivid colors','muted colors','contrast')): return 'STYLE'
    if 'background' in t or t in {'indoors','outdoors','classroom','street','room','sky','window','school','bedroom','office','park','city','forest','beach'}: return 'BACKGROUND'
    if any(w in t.split() for w in ('socks','pantyhose','thighhighs','stockings','tights')): return 'LEGWEAR'
    if any(w in t.split() for w in ('sneakers','uwabaki','boots','loafers','shoes','sandals','footwear')): return 'FOOTWEAR'
    if any(w in t.split() for w in ('ribbon','backpack','glasses','earrings','necklace','bow','tie','hat','cap','gloves','hairband','headband')): return 'ACCESSORY'
    if any(w in t.split() for w in ('dress','uniform','jacket','skirt','shirt','blouse','coat','hoodie','sweater','pants','shorts','jeans','kimono','swimsuit','underwear','bra','panties','clothes','clothing','collar','sleeves')): return 'CLOTHING'
    if t in {'pen','pencil','note','bag','book'}: return 'OBJECT'
    if t in {'freckles','mole','pointy ears','facial hair'}: return 'FACE'
    return 'UNKNOWN'


def specificity(generic, other):
    if generic == other: return False
    if generic == 'bob cut': return other == 'bob hair'
    if generic == 'multiple girls': return bool(re.fullmatch(r'[2-9]\d*\s*girls', other))
    if generic == 'multiple boys': return bool(re.fullmatch(r'[2-9]\d*\s*boys', other))
    if generic in {'pen','pencil','note','bag'}: return other == 'holding ' + generic
    if generic == 'holding': return other.startswith('holding ')
    if generic in {'clothes','clothing'}: return category(other) == 'CLOTHING' and other not in {'clothes','clothing'}
    if generic in {'footwear','shoes'}: return category(other) == 'FOOTWEAR' and other not in {'footwear','shoes'}
    # Word-level subset handles white socks/high socks and red ribbon/neck ribbon.
    if category(generic) in OUTFIT and category(other) == category(generic):
        return set(generic.split()) < set(other.split())
    return False


def organize(tags, cleanup=True):
    normalized, deleted, warnings = [], [], []
    for tag in tags:
        t = normalize(tag)
        if not t: continue
        if t in normalized:
            deleted.append(t + '（完全重複）'); continue
        normalized.append(t)
    if 'bob cut' in normalized and 'bob hair' in normalized:
        warnings.append('bob hair / bob cut が重複しています。bob hairへ統合します。')
    # Merge compatible exact combinations only; never infer colors across characters.
    for parts, merged in ((('red ribbon','neck ribbon'),'red neck ribbon'),
                          (('white socks','high socks'),'white high socks')):
        if cleanup and all(p in normalized for p in parts) and merged not in normalized:
            normalized.insert(min(normalized.index(p) for p in parts), merged)
    kept = []
    for t in normalized:
        reason = None
        if category(t) == 'QUALITY': reason = '顔文字・品質タグ'
        elif cleanup and any(specificity(t, other) for other in normalized): reason = 'より具体的なタグあり'
        if reason: deleted.append(t + '（' + reason + '）')
        else: kept.append(t)
    return kept, unique_deleted(deleted), warnings


def unique_deleted(values):
    return list(dict.fromkeys(values))


def conflicts(tags, label):
    tags = unique(tags); out = []
    for suffix, message in [('eyes','目の色が複数あります'), ('hair','同一人物に複数の髪色があります')]:
        colors = [t for t in tags if t.endswith(' '+suffix) and any(w in COLORS for w in t.split()[:-1])]
        if len(colors)>1: out.append(f'{label}: {message} → ' + ', '.join(colors))
    if any(t == 'pen' or t.endswith(' pen') for t in tags) and any(t == 'pencil' or t.endswith(' pencil') for t in tags):
        out.append(f'{label}: pen / pencil が混在しています')
    clothing = [t for t in tags if category(t)=='CLOTHING']
    if len(clothing)>=4 and any(t.endswith('dress') for t in clothing) and any(t.endswith('skirt') or t.endswith('uniform') for t in clothing):
        out.append(f'{label}: 衣装タグが重複している可能性があります → '+', '.join(clothing))
    return out


def classify(tags, mode='both', char_a='chara a', char_b='chara b', outfit_a='', outfit_b='', aliases=(), cleanup=True):
    kept, deleted, warnings = organize(tags, cleanup if mode != 'both' else False)
    if mode == 'both' and cleanup:
        shared = [t for t in kept if category(t) in COMMON]
        shared, removals, extra = organize(shared, True)
        kept = [t for t in kept if category(t) not in COMMON] + shared
        deleted += removals; warnings += extra
    result = dict(a_tags=[], b_tags=[], common_tags=[], unclassified_tags=[], deleted_tags=deleted,
                  identity_tags=[], warnings=warnings, categories={}, normalized_tags=unique(tags))
    triggers = [char_a,char_b,*aliases]; outfits=[outfit_a,outfit_b]
    for t in kept:
        kind=category(t,triggers,outfits); result['categories'][t]=kind
        if kind=='IDENTITY': result['identity_tags'].append(t)
        elif kind in COMMON: result['common_tags'].append(t)
        elif kind in PERSON and mode in ('a','b'): result[mode+'_tags'].append(t)
        else: result['unclassified_tags'].append(t)
    for key,label in [('a_tags',char_a),('b_tags',char_b),('unclassified_tags','未分類（人物帰属を確認）')]:
        result['warnings'] += conflicts(result[key],label)
    if mode=='both' and any(category(t) in PERSON for t in result['unclassified_tags']):
        result['warnings'].append('A+Bの人物属性は自動判定できません。未分類からA/Bへ手動で振り分けてください。')
    return result


def join(tags):
    if len(tags)<2: return ''.join(tags)
    return ', '.join(tags[:-1])+(', and ' if len(tags)>2 else ' and ')+tags[-1]


def action(tag):
    mapping={'smile':'smiling','blush':'blushing','open mouth':'with an open mouth',
        'closed mouth':'with a closed mouth','arm up':'with one arm raised','arms up':'with both arms raised',
        'hand up':'with one hand raised','hands up':'with both hands raised','thumbs up':'giving a thumbs up'}
    if tag in mapping: return mapping[tag]
    if tag.startswith('holding '):
        obj=tag[8:]; return 'holding '+('an ' if obj[:1] in 'aeiou' else 'a ')+obj
    return tag


def build_multichar_caption(mode, char_a, char_b, a_tags, b_tags, common_tags,
        include_style=False, include_scene=True, trigger_aliases=None, **options):
    cfg={**DEFAULTS, **options, 'include_style':include_style, 'include_scene':include_scene}
    char_a=char_a.strip() or 'chara a'; char_b=char_b.strip() or 'chara b'
    triggers=[char_a,char_b,*(trigger_aliases or [])]; outfits=[cfg['outfit_a'],cfg['outfit_b']]
    warnings=[]; global_tags=[]; persons=[]
    for tags,name,outfit in ((a_tags,char_a,cfg['outfit_a']),(b_tags,char_b,cfg['outfit_b'])):
        warnings+=conflicts(tags,name)
        kept,deleted,dup_warnings=organize(tags,cfg['auto_cleanup']);warnings+=dup_warnings
        if deleted: warnings.append(name+': 削除候補 → '+', '.join(deleted))
        if mode == 'both' or (mode == 'a' and name == char_a) or (mode == 'b' and name == char_b):
            global_tags += [t for t in kept if category(t,triggers,outfits) in COMMON]
        persons.append([t for t in kept if category(t,triggers,outfits) not in COMMON|{'IDENTITY'}])
    kept,deleted,dup_warnings=organize(common_tags,cfg['auto_cleanup']);warnings+=dup_warnings
    if deleted: warnings.append('共通: 削除候補 → '+', '.join(deleted))
    shared_pose=[t for t in kept if category(t)=='POSE'] if mode=='both' and cfg['include_shared_pose'] else []
    ambiguous=[t for t in kept if (category(t,triggers,outfits) in PERSON or category(t,triggers,outfits)=='UNKNOWN') and t not in shared_pose]
    if ambiguous:
        if mode in ('a','b'): persons[0 if mode=='a' else 1]+=ambiguous
        else: warnings.append('共通内の人物属性・不明タグはcaptionへ出力しません。A/Bへ振り分けてください → '+', '.join(ambiguous))
    global_tags=unique(global_tags+[t for t in kept if category(t,triggers,outfits) in COMMON])
    level=cfg['caption_mode']
    if level=='auto': level='minimal' if mode=='both' else 'detailed'
    active=[(char_a,persons[0],cfg['outfit_a'])] if mode=='a' else [(char_b,persons[1],cfg['outfit_b'])] if mode=='b' else [(char_a,persons[0],cfg['outfit_a']),(char_b,persons[1],cfg['outfit_b'])]
    counts=[t for t in global_tags if category(t)=='COUNT']
    male=any('boy' in t for t in counts) and not any('girl' in t for t in counts)
    count=('1boy' if male else '1girl') if mode in ('a','b') else ('2boys' if male else '2girls')
    warnings += ([f'人数タグが画像タイプと一致しません → {t}' for t in counts if t not in {count,'solo'} and not t.startswith('multiple ')])
    if mode=='both' and 'solo' in counts: warnings.append('A+B画像にsoloがあります。人数を確認してください。')
    lines=[f'{active[0][0]}, {count}, solo.'] if mode in ('a','b') else [f'{char_a} and {char_b}, {count}.']
    for name,tags,outfit in active:
        tags=unique(tags); wear=[]; attrs=[]; actions=[]
        for t in tags:
            kind=category(t,triggers,outfits)
            if kind in OUTFIT and cfg['include_clothing'] and level!='minimal': wear.append(t)
            elif kind in {'HAIR','EYES','FACE'} and (cfg['include_identity'] or t in unique(cfg.get('fixed_a',[]) if name==char_a else cfg.get('fixed_b',[]))) and level!='minimal': attrs.append(t)
            elif kind=='GAZE' and cfg['include_gaze'] and level=='detailed': actions.append(action(t))
            elif kind in {'POSE','ACTION'} and cfg['include_action'] and level=='detailed': actions.append(action(t))
            elif kind=='EXPRESSION' and cfg['include_expression'] and level=='detailed': actions.append(action(t))
            elif kind=='OBJECT' and level=='detailed': attrs.append(t)
            elif kind=='UNKNOWN': warnings.append(name+': 不明タグを保留 → '+t)
        # Outfit triggers remain exact configuration strings, not visual tags.
        if outfit.strip():
            singular = {'CLOTHING', 'ACCESSORY'}
            wear = [('an ' if t[:1] in 'aeiou' else 'a ') + t if category(t) in singular and not t.endswith(('glasses','earrings','pants','shorts','jeans','sleeves','gloves')) else t for t in wear]
            description = outfit.strip() + (', ' + join(wear) if wear else '')
            lines.append(f'{name} wears {description}.')
        elif wear: lines.append(f'{name} wears {join(wear)}.')
        if attrs: lines.append(f'{name} has {join(attrs)}.')
        if actions:
            base = [t for t in actions if not t.startswith('with ')]
            modifiers = [t for t in actions if t.startswith('with ')]
            phrase = ' '.join(filter(None, [join(base), join(modifiers)]))
            lines.append(f'{name} is {phrase}.')
    if shared_pose and cfg['include_action'] and level=='detailed':
        lines.append('Shared pose: '+join(shared_pose)+'.')
    for kind,label,enabled in [('COMPOSITION','Composition',cfg['include_composition']),
                               ('BACKGROUND','Scene',cfg['include_scene'] and level=='detailed'),
                               ('LIGHTING','Lighting',cfg['include_lighting'] and level=='detailed'),
                               ('STYLE','Style',cfg['include_style'])]:
        values=[t for t in global_tags if category(t)==kind]
        if enabled and values: lines.append(f'{label}: {join(values)}.')
    return ' '.join(lines), unique_deleted(warnings) if cfg['show_warnings'] else []
