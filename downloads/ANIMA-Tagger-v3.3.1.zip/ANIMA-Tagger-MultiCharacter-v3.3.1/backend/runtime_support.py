"""Small platform-independent launcher primitives, also exercised by tests."""
import hashlib
import socket
import struct
import sys
from pathlib import Path


TORCH_PACKAGES = ('torch==2.7.1', 'torchvision==0.22.1')

def supported_python(version=None, bits=None):
    version = sys.version_info[:2] if version is None else tuple(version[:2])
    bits = struct.calcsize('P') * 8 if bits is None else bits
    return (3, 10) <= version <= (3, 12) and bits == 64


def dependency_key(root, profile='cu128', version=None):
    version = sys.version_info[:2] if version is None else version
    digest = hashlib.sha256()
    digest.update(f'launcher-v1|{version[0]}.{version[1]}|{profile}|'.encode())
    if profile != 'editor':
        digest.update('|'.join(TORCH_PACKAGES).encode())
    for name in ('requirements-core.txt', 'requirements.txt'):
        digest.update(Path(root, name).read_bytes())
    return digest.hexdigest()[:20]


def bind_app_socket(port=8010, max_tries=50):
    if not 1 <= port <= 65535:
        raise ValueError('APP_PORT must be between 1 and 65535')
    for candidate in range(port, min(port + max_tries, 65536)):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if sys.platform == 'win32':
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            sock.bind(('127.0.0.1', candidate))
            sock.listen(128)
            return sock
        except OSError:
            sock.close()
    # Entire preferred range busy: request an ephemeral port from the OS.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(('127.0.0.1', 0))
        sock.listen(128)
        return sock
    except BaseException:
        sock.close()
        raise
