# ANIMA-Tagger MultiCharacter — Full Codex Review Task

## Goal
Perform a full codebase review and refactor of this Windows local web app. Do not patch one symptom at a time. Identify the state model, define the single source of truth for captions, remove conflicting save/regenerate paths, add regression tests, and return a stable release.

## Context
This app is used to tag LoRA training images for ANIMA, including two-character datasets. It has a browser UI, Python backend, sidecar metadata, per-image .txt captions, multi-select thumbnails, batch tag editing, phrase replacement, and Windows start.bat setup.

## Known historical bugs to reproduce and prevent
1. `Save` overwrote phrase-replaced captions with regenerated pre-replacement captions.
2. `Save Project` / settings-save could trigger `generate()` and revert manually edited or replaced captions.
3. Batch phrase replacement worked in .txt but later UI save could revert it.
4. Phrase replacement initially operated on regenerated captions rather than the actual displayed/saved caption.
5. `chara a` / `chara b` were generated identifiers, so normal tag deletion could not remove/replace them as expected.
6. Multi-select thumbnail behavior regressed during later changes.
7. Zero selected images made batch actions silently do nothing.
8. Sidecar, UI textarea, generated caption, and .txt could diverge.
9. start.bat previously had Python runtime detection failures and fixed-port conflicts.
10. Every extracted version currently creates a new local venv and redownloads/installs large dependencies; design a shared reusable runtime/venv strategy without breaking portability.

## Required architecture review
Define and document:
- What is the canonical caption state?
- What is generated data vs manually edited data?
- How are persistent phrase-replacement rules represented?
- When is regeneration allowed?
- Which actions must NEVER implicitly regenerate?
- How sidecar metadata, .txt caption, and UI are synchronized.

Recommended principle: one explicit source of truth for current caption text; generation should be an explicit operation, not a side effect of save/settings changes.

## Required behavior
### Caption lifecycle
- `Regenerate`: explicitly builds caption from tags/settings, then applies persistent replacement rules.
- `Save`: writes the current textarea caption exactly as shown; no regeneration.
- `Save and next`: same as Save, then navigate.
- `Settings save`: saves settings only; must not alter image captions.
- Reloading an image restores the saved caption exactly.

### Batch phrase replacement
- Support arbitrary substrings including spaces, e.g.:
  - `yasumin wears` -> `yasumin wears outfit ya01`
- Apply only to selected images; if UX chooses a current-image fallback when zero selected, make it explicit and visible.
- Persist updated caption to .txt and sidecar.
- Persist replacement rule only if this is an intended feature; separate one-shot replace from persistent rule if necessary.
- Reopening the image must show the replaced caption.
- Pressing Save after replacement must not revert it.
- Pressing Regenerate should have clearly defined behavior; if persistent rules are enabled, reapply them after generation.

### Batch tag editing
- Multi-select thumbnails must work reliably.
- Ctrl-click individual selection.
- Shift-click range selection.
- Optional selection mode for simple click-to-toggle.
- Visible selection count and selected styling.
- Batch add target: A / B / common.
- Batch delete removes requested tags from intended tag collections without unexpected trigger mutation.

### Character triggers
- Character A/B trigger names are configuration, not ordinary tags.
- Provide a clear explicit way to rename a trigger globally or across selected images.
- Avoid hidden coupling between trigger names and generated caption text.

### Persistence
- Atomic writes where reasonable.
- Sidecar schema should be versioned or backward-compatible.
- Manual caption edits must survive app restart.
- Existing datasets from v3.1 should remain readable.

### Windows launcher/runtime
Review start.bat thoroughly:
- Robust Python 3.10-3.12 detection.
- No false-positive py launcher detection.
- Automatic free port selection.
- No repeated heavy reinstall when app source version changes.
- Prefer shared runtime/venv in a stable location, with version/dependency marker or requirements hash.
- Do not delete user environments automatically.
- Provide diagnose.bat or equivalent.

## Testing requirements
Add automated tests, not only manual inspection.

At minimum cover:
1. Generate -> replace phrase -> save -> reload => replacement preserved.
2. Generate -> replace phrase -> save project/settings => replacement preserved.
3. Generate -> manual textarea edit -> save -> reload => manual text preserved exactly.
4. Persistent replacement rule -> regenerate => replacement applied once, not duplicated.
5. Multi-select selected subset -> batch replace => only selected captions change.
6. Multi-select selected subset -> batch add/delete tags => only selected images change.
7. Save and next => current caption saved exactly before navigation.
8. Trigger rename does not accidentally become a character attribute tag.
9. Existing v3.1 sidecar compatibility.
10. start.bat runtime detection logic and port fallback, as far as can be tested cross-platform; isolate logic where possible.

Use unit/integration tests for backend and state transformations. If browser automation is practical, add a small Playwright or equivalent smoke suite for critical UI flows.

## Review expectations
- Inspect the whole codebase before editing.
- Identify duplicated state and side effects.
- Prefer refactoring over adding another patch layer.
- Remove dead code and duplicated caption-generation/save logic.
- Keep the current UI appearance unless a UX change is needed for correctness.
- Preserve current useful features.
- Add comments only where behavior is non-obvious.
- Do not silently change caption semantics for existing projects.

## Deliverables
1. Updated source.
2. Tests and test command.
3. A concise REVIEW_REPORT.md containing:
   - root causes found
   - architecture changes
   - bugs fixed
   - remaining known limitations
   - test results
4. Updated README/start instructions.
5. Release ZIP suitable for Windows use.

## Acceptance test
The following exact scenario must pass:
- Open an image whose caption contains `yasumin wears green school uniform`.
- Select that image.
- Batch phrase replace `yasumin wears` with `yasumin wears outfit ya01`.
- Verify UI caption becomes `yasumin wears outfit ya01 green school uniform`.
- Verify its .txt contains the same.
- Click Save.
- Reload/navigate away and back.
- Verify UI and .txt still contain the replaced string.
- Click settings-save.
- Verify caption remains unchanged.
- If Regenerate is used and persistent replacements are enabled, verify the phrase remains replaced exactly once.

Do not mark the task complete until the automated tests and this acceptance scenario pass.
