# ANIMA-Tagger 自動タグ分類ルール仕様書

## 1. 目的

ANIMA-Taggerが画像から得た自動タグを、そのまま全部captionへ入れるのではなく、

- キャラA
- キャラB
- 共通
- 削除候補
- 警告候補

へ自動分類する。

最終目標は、複数キャラLoRAで起きやすい

- キャラ混線
- 衣装交換
- 髪色交換
- 顔の同一化
- 色の誤学習
- 重複タグによるノイズ

を減らすこと。

---

# 2. 基本原則

## キャラ固有特徴

原則としてトリガーへ吸収する。

例：

```text
pink hair
pink eyes
purple hair
purple eyes
bob hair
updo
```

ただし、画像ごとに変化する場合はcaptionへ残す。

---

## 衣装

キャラごとの衣装トリガーに紐付ける。

```text
outfit ya01
outfit st01
```

衣装タグは人物側へ分類する。

---

## 共通

人物固有ではないものだけ。

- 背景
- 光
- 構図
- カメラ
- 人数
- シーン

---

## 削除

- 重複
- 誤認しやすい抽象タグ
- 顔文字
- 汎用すぎるタグ
- より具体的なタグに包含されるタグ

---

# 3. 分類カテゴリ

内部的には次のカテゴリを持たせる。

```text
IDENTITY
HAIR
EYES
FACE
CLOTHING
ACCESSORY
FOOTWEAR
LEGWEAR
POSE
ACTION
EXPRESSION
GAZE
OBJECT
BACKGROUND
LIGHTING
COMPOSITION
STYLE
COUNT
QUALITY
UNKNOWN
```

---

# 4. キャラA/Bへ振り分けるタグ

以下は人物属性なので、共通に入れない。

## 髪

```text
pink hair
purple hair
black hair
blonde hair
brown hair
short hair
long hair
bob hair
bob cut
updo
ponytail
twintails
braid
```

### ルール

画像タイプが「Aのみ」ならAへ。

「Bのみ」ならBへ。

「A+B」の場合は自動判定できなければ未分類に残し、人間がA/Bを選ぶ。

---

## 目

```text
pink eyes
purple eyes
blue eyes
red eyes
green eyes
brown eyes
```

A/B画像では必ず人物へ紐付ける。

共通へは入れない。

---

## 衣服

```text
dress
school uniform
jacket
skirt
pleated skirt
shirt
blouse
coat
hoodie
sweater
uniform
```

色付き複合タグも同様。

```text
green jacket
green school uniform
navy blue dress
```

人物へ分類する。

---

## 靴下・タイツ

```text
socks
white socks
high socks
white high socks
pantyhose
striped pantyhose
navy blue and white striped pantyhose
thighhighs
```

人物へ分類する。

---

## 靴

```text
sneakers
black sneakers
light blue sneakers
uwabaki
boots
loafers
```

人物へ分類。

---

## 装飾品

```text
ribbon
red ribbon
neck ribbon
red neck ribbon
hair ribbon
backpack
purple backpack
glasses
earrings
necklace
```

人物へ分類。

---

# 5. 共通へ振り分けるタグ

## 人数

```text
1girl
1boy
2girls
2boys
multiple girls
multiple boys
solo
```

### ルール

`1girl + solo` は単独画像の先頭へ。

`2girls` があるなら `multiple girls` は削除候補。

---

## 背景

```text
simple background
purple background
white background
indoors
outdoors
classroom
street
room
sky
```

共通へ。

---

## 照明

```text
sunset lighting
warm lighting
orange light
evening
backlighting
rim light
dim lighting
```

共通へ。

---

## 構図

```text
full body
upper body
cowboy shot
close-up
portrait
from above
from below
side view
```

共通へ。

---

## 画風

```text
anime style
clean lineart
soft shading
rough lineart
pencil-like outlines
```

共通へ。

ただし、画風をLoRA本体に吸収させたい場合はcaption出力OFF設定を用意する。

---

# 6. 表情・視線・動作の扱い

## 表情

```text
smile
blush
open mouth
closed mouth
serious
angry
sad
crying
surprised
```

### 単独画像

Aのみ → A

Bのみ → B

### 2人画像

自動で共通へ入れない。

A/Bどちらかへ分類。

---

## 視線

```text
looking at viewer
looking away
looking to the side
looking down
looking up
```

原則として可変要素。

ただし今回の運用では、`looking at viewer` は自動captionから除外できる設定を推奨。

設定例：

```text
[ ] 視線タグをcaptionへ含める
```

デフォルトOFFでもよい。

---

## ポーズ

```text
standing
sitting
kneeling
arms up
arm up
hands on hips
crossed arms
```

単独なら人物へ。

2人画像で両者共通と確実に判断できる場合だけ共通。

---

## 動作

```text
holding pen
holding pencil
holding note
holding bag
running
walking
jumping
```

人物へ分類。

---

# 7. 自動重複削除ルール

より具体的なタグがある場合、汎用タグを削除する。

## 靴下

```text
white high socks
```

がある場合、

```text
socks
white socks
high socks
```

を削除候補にする。

---

## タイツ

```text
navy blue and white striped pantyhose
```

がある場合、

```text
pantyhose
striped pantyhose
```

を削除候補にする。

---

## リボン

```text
red neck ribbon
```

がある場合、

```text
ribbon
red ribbon
neck ribbon
```

を削除候補にする。

---

## 髪型

```text
bob hair
```

がある場合、

```text
bob cut
```

と重複警告。

どちらか1つへ統合する。

---

## 人数

```text
2girls
```

がある場合、

```text
multiple girls
```

を削除。

---

# 8. 矛盾検出ルール

同カテゴリで複数の競合値がある場合、黄色警告を出す。

## 目色

```text
pink eyes
red eyes
```

↓

```text
⚠ 目の色が複数あります
```

---

## 髪色

```text
pink hair
purple hair
```

↓

```text
⚠ 同一人物に複数の髪色があります
```

A+B画像では人物未分類なら警告しつつ保留。

---

## 持ち物

```text
pen
pencil
holding pen
holding pencil
```

↓

```text
⚠ pen / pencil が混在しています
```

---

## 衣服

```text
dress
skirt
```

は必ずしも矛盾ではない。

ただし同一衣装に対して、

```text
green dress
green school uniform
pleated dress
pleated skirt
```

が大量にある場合は、

```text
⚠ 衣装タグが重複している可能性があります
```

と表示。

---

# 9. 自動正規化

## ハイフン

```text
dark-blue dress
```

↓

```text
dark blue dress
```

---

## アンダースコア

```text
navy_blue_dress
```

↓

```text
navy blue dress
```

---

## 連続語

```text
green green school uniforms
```

↓

```text
green school uniform
```

---

## 複数形

可能な範囲で単数へ統一。

```text
school uniforms
```

↓

```text
school uniform
```

---

# 10. 削除推奨タグ

原則として自動削除候補。

```text
:d
:)
:3
^_^
```

顔文字系。

---

## 抽象すぎるタグ

より具体的タグがある場合は削除。

```text
clothes
footwear
socks
dress
ribbon
```

ただし具体タグがない場合は残してよい。

---

# 11. Character Triggerの扱い

キャラクタートリガーは通常タグとして扱わない。

```text
yasumin
stndrgn
```

はcaption先頭へ自動挿入。

---

## 単独

```text
yasumin, 1girl, solo.
```

---

## 2人

```text
yasumin and stndrgn, 2girls.
```

---

# 12. Outfit Triggerの扱い

衣装トリガーも通常タグとは別管理する。

例：

```text
yasumin
outfit ya01
```

```text
stndrgn
outfit st01
```

生成caption：

```text
yasumin wears outfit ya01, a green school uniform, a green jacket, a red neck ribbon, white high socks, and sneakers.
```

---

# 13. A+B画像の自動生成

## 最小モード

推奨デフォルト。

```text
yasumin and stndrgn, 2girls.
yasumin wears outfit ya01.
stndrgn wears outfit st01.
Composition: full body.
```

---

## 詳細モード

必要に応じて追加。

```text
yasumin and stndrgn, 2girls.
yasumin wears outfit ya01, a green school uniform, a green jacket, a red neck ribbon, white high socks, and sneakers.
stndrgn wears outfit st01, a navy blue dress, navy blue and white striped pantyhose, uwabaki, and a purple backpack.
Composition: full body.
```

---

# 14. 固定特徴欄の扱い

固定特徴欄は、

```text
pink hair
pink eyes
updo
```

のような情報を保存できる。

ただし今回の推奨運用では、

```text
[ ] 固定特徴をcaptionへ自動挿入
```

をデフォルトOFFにする。

理由：

キャラ固有特徴をCharacter Triggerへ吸収させるため。

---

# 15. Styleタグの扱い

UIに、

```text
[ ] Styleタグをcaptionへ含める
```

を設ける。

### OFF

画風をLoRAへ吸収。

### ON

画風を可変属性として分離。

---

# 16. Gazeタグの扱い

UIに、

```text
[ ] 視線タグをcaptionへ含める
```

を設ける。

今回の用途ではOFF推奨。

---

# 17. 自動分類優先順位

タグ検出後は次の順で処理する。

```text
1. 正規化
2. 完全重複削除
3. 具体タグによる汎用タグ削除
4. 矛盾検出
5. Character Trigger除外
6. Outfit Trigger除外
7. 人物属性分類
8. 共通タグ分類
9. 削除候補分類
10. caption生成
```

---

# 18. Aのみ自動振り分け

画像タイプ：

```text
Aのみ
```

の場合、

髪・目・服・装飾・動作・表情 → A

背景・構図・照明・画風 → 共通

---

# 19. Bのみ自動振り分け

同様に、

髪・目・服・装飾・動作・表情 → B

背景・構図・照明・画風 → 共通

---

# 20. A+B自動振り分け

人物属性は自動で共通へ入れない。

髪・目・服・装飾・表情・動作は、

```text
未分類
```

へ残す。

ユーザーがA/Bへ振り分ける。

背景・構図・照明・画風のみ共通へ自動分類。

---

# 21. 推奨UI

タグ一覧にカテゴリ色を付ける。

例：

```text
髪・目        紫
衣装          青
表情・動作    黄
背景          緑
構図          灰
警告          赤
```

---

# 22. Caption生成モード

UIに3段階用意すると便利。

## Minimal

```text
yasumin, 1girl, solo.
yasumin wears outfit ya01.
Composition: full body.
```

---

## Standard

```text
yasumin, 1girl, solo.
yasumin wears outfit ya01, a green school uniform, a green jacket, a red neck ribbon, white high socks, and sneakers.
Composition: full body.
```

---

## Detailed

表情・動作・背景・照明も含める。

---

# 23. 推奨デフォルト設定

```text
固定特徴をcaptionへ挿入：OFF
視線タグ：OFF
Styleタグ：OFF
背景タグ：ON
構図タグ：ON
動作タグ：ON
表情タグ：ON
衣装詳細：ON
重複自動整理：ON
矛盾警告：ON
```

---

# 24. yasumin用例

元タグ：

```text
pink hair
pink eyes
updo
green jacket
green school uniform
red ribbon
neck ribbon
white socks
high socks
sneakers
smile
open mouth
full body
simple background
```

処理後：

```text
Character Trigger:
yasumin

Outfit:
green school uniform
green jacket
red neck ribbon
white high socks
sneakers

可変:
smile
open mouth

共通:
full body
simple background
```

生成：

```text
yasumin, 1girl, solo.
yasumin wears outfit ya01, a green school uniform, a green jacket, a red neck ribbon, white high socks, and sneakers.
yasumin is smiling with an open mouth.
Composition: full body.
Scene: simple background.
```

---

# 25. stndrgn用例

元タグ：

```text
purple hair
purple eyes
bob hair
navy blue dress
pantyhose
striped pantyhose
navy blue and white striped pantyhose
uwabaki
purple backpack
full body
```

処理後：

```text
Character Trigger:
stndrgn

Outfit:
navy blue dress
navy blue and white striped pantyhose
uwabaki
purple backpack

共通:
full body
```

生成：

```text
stndrgn, 1girl, solo.
stndrgn wears outfit st01, a navy blue dress, navy blue and white striped pantyhose, uwabaki, and a purple backpack.
Composition: full body.
```

---

# 26. 最終目標

Taggerは、

「大量のタグを正確に出す」

ことを目的にしない。

目的は、

```text
キャラクターID
衣装ID
可変要素
共通シーン
```

をきれいに分離し、LoRA学習時の概念混線を最小化すること。

そのため、

**少なく正確なcaption > 多くて冗長なcaption**

を基本方針とする。