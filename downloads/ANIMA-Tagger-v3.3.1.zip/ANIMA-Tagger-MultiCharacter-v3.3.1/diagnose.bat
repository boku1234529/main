@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
call tools\run_windows.bat --diagnose %*
set "ANIMA_EXIT=%ERRORLEVEL%"
pause
exit /b %ANIMA_EXIT%
