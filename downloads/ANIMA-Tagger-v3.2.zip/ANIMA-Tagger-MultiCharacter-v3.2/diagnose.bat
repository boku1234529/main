@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHON_EXE="
call :try_python py -3.12
if not defined PYTHON_EXE call :try_python py -3.11
if not defined PYTHON_EXE call :try_python py -3.10
if not defined PYTHON_EXE call :try_python python
if not defined PYTHON_EXE call :try_python python3
if not defined PYTHON_EXE (
    echo [ERROR] An installed 64-bit Python 3.10-3.12 is required.
    echo Install Python 3.11 or 3.12 from python.org, then try again.
    pause
    exit /b 1
)
"%PYTHON_EXE%" tools\launcher.py --diagnose
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" pause
exit /b %APP_EXIT%

:try_python
for /f "usebackq delims=" %%P in (`%* -c "import sys,struct,os; p=sys.executable; print(p if (3,10) ^<= sys.version_info[:2] ^<= (3,12) and struct.calcsize('P')==8 and os.path.isfile(p) else '')" 2^>nul`) do if exist "%%P" set "PYTHON_EXE=%%P"
exit /b
