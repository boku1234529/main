"""Real Chromium + real HTTP API; temporary datasets only."""
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest
import httpx
from PIL import Image
from playwright.sync_api import sync_playwright, expect
import uvicorn
from backend.main import app
from backend.caption_store import save_image
from backend.runtime_support import bind_app_socket


class BrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ['ANIMA_NO_BROWSER'] = '1'
        cls.socket = bind_app_socket(18760)
        cls.url = f'http://127.0.0.1:{cls.socket.getsockname()[1]}'
        cls.server = uvicorn.Server(uvicorn.Config(app, log_level='error'))
        cls.thread = threading.Thread(target=cls.server.run, kwargs={'sockets': [cls.socket]}, daemon=True)
        cls.thread.start()
        deadline = time.monotonic() + 10
        while not cls.server.started:
            if time.monotonic() > deadline: raise RuntimeError('Test HTTP server failed to start')
            time.sleep(.02)
        cls.playwright = sync_playwright().start()
        executable = os.environ.get('ANIMA_TEST_CHROMIUM') or shutil.which('chromium') or shutil.which('google-chrome')
        cls.browser = cls.playwright.chromium.launch(executable_path=executable, headless=True, args=['--no-sandbox'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close(); cls.playwright.stop()
        cls.server.should_exit = True; cls.thread.join(10); cls.socket.close()
        if cls.thread.is_alive(): raise RuntimeError('Test server failed to stop')

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.folder = Path(self.tmp.name)
        self.expected = 'yasumin wears outfit ya01 green school uniform'
        for i in range(4):
            path = self.folder / f'{i}.png'; Image.new('RGB', (32, 32), (i * 50, 80, 90)).save(path)
            save_image(str(path), {'mode': 'a', 'raw_tags': ['green school uniform'], 'a_tags': ['green school uniform'],
                'b_tags': [], 'common_tags': [], 'caption': 'yasumin wears green school uniform', 'phrase_replacements': []})
        (self.folder / '.anima_tagger_project.json').write_text(json.dumps({'char_a': 'yasumin', 'char_b': 'second', 'fixed_a': [], 'fixed_b': []}))
        self.context = self.browser.new_context(viewport={'width': 1500, 'height': 1100})
        self.page = self.context.new_page(); self.errors = []; self.dialogs = []; self.requests = []
        self.page.on('pageerror', lambda error: self.errors.append(str(error)))
        self.page.on('dialog', self.dialog)
        self.page.on('request', lambda request: self.requests.append(request.url))
        self.page.goto(self.url)
        self.page.locator('#folder-path').fill(str(self.folder)); self.click('#btn-load')
        expect(self.page.locator('#counter')).to_have_text('1 / 4')
        expect(self.page.locator('#caption')).to_have_value('yasumin wears green school uniform')

    def tearDown(self):
        self.context.close(); self.tmp.cleanup()
        self.assertEqual(self.errors, [])

    def dialog(self, dialog):
        self.dialogs.append(dialog.message); dialog.accept()

    def click(self, selector):
        self.page.locator(selector).click()
        expect(self.page.locator(selector)).to_be_enabled()

    def replace(self):
        self.page.locator('#batch-find').fill('yasumin wears')
        self.page.locator('#batch-replace').fill('yasumin wears outfit ya01')
        self.click('#batch-replace-btn')

    def assert_disk(self, index, text):
        self.assertEqual((self.folder / f'{index}.txt').read_bytes(), text.encode('utf-8'))
        self.assertEqual(json.loads((self.folder / f'{index}.anima.json').read_text())['caption'], text)

    def test_batch_generate_then_save_selected_only(self):
        for i in (0, 2): self.page.locator('.thumb-check').nth(i).click()
        self.page.locator('#include-identity').check()
        self.page.locator('#batch-tags').fill('pink hair')
        self.page.locator('#batch-dest').select_option('a'); self.click('#batch-add')
        self.click('#batch-generate')
        generated = self.page.locator('#caption').input_value()
        self.assertIn('pink hair', generated)
        expect(self.page.locator('#batch-result')).to_contain_text('未保存')
        for i in range(4): self.assert_disk(i, 'yasumin wears green school uniform')
        self.page.locator('.thumb').nth(2).click()
        expect(self.page.locator('#caption')).to_have_value(generated)
        self.click('#batch-save')
        self.assert_disk(0, generated); self.assert_disk(2, generated)
        self.assert_disk(1, 'yasumin wears green school uniform'); self.assert_disk(3, 'yasumin wears green school uniform')
        self.click('#btn-load'); expect(self.page.locator('#caption')).to_have_value(generated)

    def test_batch_save_preserves_different_manual_drafts(self):
        text = '  manual 日本語\n\n '
        self.page.locator('#caption').fill(text); self.click('#next')
        self.page.locator('#caption').fill('')
        for i in (0, 1): self.page.locator('.thumb-check').nth(i).click()
        self.click('#batch-save')
        self.assert_disk(0, text); self.assert_disk(1, '')
        self.assertFalse(any('preview-caption' in url for url in self.requests))
        self.click('#prev'); expect(self.page.locator('#caption')).to_have_value(text)

    def test_batch_caption_no_selection_and_generate_failure_keep_drafts(self):
        for button in ('#batch-generate', '#batch-save'):
            self.click(button); self.assertIn('未選択では実行しません', self.dialogs[-1])
        self.assertFalse(any('batch-preview-caption' in url or 'batch-save-caption' in url for url in self.requests))
        self.page.locator('.thumb-check').nth(0).click()
        self.page.locator('#caption').fill('unsaved draft')
        self.page.route('**/api/dataset/batch-preview-caption', lambda route: route.fulfill(status=500,
                        content_type='application/json', body='{"detail":"generation failed"}'))
        self.click('#batch-generate')
        expect(self.page.locator('#caption')).to_have_value('unsaved draft')
        expect(self.page.locator('#batch-result')).to_contain_text('編集内容は保持')
        self.assert_disk(0, 'yasumin wears green school uniform')

    def test_batch_partial_save_keeps_failed_draft_for_retry(self):
        self.page.locator('#caption').fill('first draft'); self.click('#next')
        self.page.locator('#caption').fill('second draft')
        for i in (0, 1): self.page.locator('.thumb-check').nth(i).click()
        def partial(route):
            item = route.request.post_data_json['items'][0]
            route.fulfill(content_type='application/json', body=json.dumps({
                'status': 'partial', 'updated': 1, 'failed': 1, 'items': [item],
                'failures': [{'path': str(self.folder / '1.png'), 'detail': 'disk failure'}]}))
        self.page.route('**/api/dataset/batch-save-caption', partial)
        self.click('#batch-save')
        expect(self.page.locator('#batch-result')).to_contain_text('1枚保存、1枚失敗')
        expect(self.page.locator('#caption')).to_have_value('second draft')
        self.page.unroute('**/api/dataset/batch-save-caption', partial)
        self.click('#batch-save'); self.assert_disk(0, 'first draft'); self.assert_disk(1, 'second draft')

    def test_rules_ui_defaults_modes_outfit_and_manual_save(self):
        for key in ('include-fixed','include-identity','include-gaze','include-style'):
            expect(self.page.locator('#'+key)).not_to_be_checked()
        self.page.locator('#outfit-a').fill('outfit ya01')
        self.page.locator('#caption').fill('manual unchanged')
        self.click('#btn-save-project')
        expect(self.page.locator('#caption')).to_have_value('manual unchanged')
        self.click('#btn-generate')
        self.assertIn('yasumin wears outfit ya01, a green school uniform.',self.page.locator('#caption').input_value())
        self.page.locator('#caption-mode').select_option('minimal');self.click('#btn-generate')
        self.assertIn('yasumin wears outfit ya01.',self.page.locator('#caption').input_value())
        self.assertNotIn('green school uniform',self.page.locator('#caption').input_value())
        self.click('#btn-save'); saved=self.page.locator('#caption').input_value();self.assert_disk(0,saved)
        self.click('#btn-load');expect(self.page.locator('#outfit-a')).to_have_value('outfit ya01')

    def test_both_classification_holds_person_and_shows_candidate_colors(self):
        path=self.folder/'0.anima.json';data=json.loads(path.read_text())
        data.update(mode='both',a_tags=[],b_tags=[],common_tags=['pink hair','purple hair','smile','full body',':d'],
                    raw_tags=['pink hair','purple hair','smile','full body',':d'])
        path.write_text(json.dumps(data));self.click('#btn-load')
        self.click('#btn-auto-distribute')
        expect(self.page.locator('#caption')).to_have_value('yasumin wears green school uniform')
        expect(self.page.locator('#a-tags')).to_have_text('');expect(self.page.locator('#b-tags')).to_have_text('')
        expect(self.page.locator('#common-tags')).to_have_text('full body')
        expect(self.page.locator('#pool')).to_contain_text('pink hair')
        expect(self.page.locator('#deleted-tags')).to_contain_text(':d')
        expect(self.page.locator('#caption-warnings')).to_contain_text('未分類')
        self.assertEqual(self.page.locator('#pool .category-identity').count(),2)
        self.page.locator('#outfit-a').fill('outfit ya01');self.page.locator('#outfit-b').fill('outfit st01')
        self.click('#btn-generate')
        self.assertEqual(self.page.locator('#caption').input_value(),'yasumin and second, 2girls. yasumin wears outfit ya01. second wears outfit st01. Composition: full body.')
        self.assert_disk(0,'yasumin wears green school uniform')

    def test_classify_normalizes_merges_then_saves_without_automatic_generation(self):
        path=self.folder/'0.anima.json';data=json.loads(path.read_text())
        data.update(a_tags=[],raw_tags=['green green school uniforms','red ribbon','neck ribbon','white socks','high socks','smile','looking at viewer','anime style','warm lighting'])
        path.write_text(json.dumps(data));self.click('#btn-load')
        self.click('#btn-auto-distribute')
        expect(self.page.locator('#a-tags')).to_contain_text('red neck ribbon')
        expect(self.page.locator('#a-tags')).to_contain_text('white high socks')
        self.assertFalse(any('preview-caption' in url for url in self.requests))
        self.click('#btn-generate');default=self.page.locator('#caption').input_value()
        self.assertIn('smiling',default);self.assertIn('Lighting: warm lighting.',default)
        self.assertNotIn('looking at viewer',default);self.assertNotIn('Style:',default)
        self.page.locator('#include-gaze').check();self.page.locator('#include-style').check();self.click('#btn-generate')
        generated=self.page.locator('#caption').input_value()
        self.assertIn('looking at viewer',generated);self.assertIn('Style: anime style.',generated)
        self.click('#btn-save');self.assert_disk(0,generated)
        self.click('#btn-load');expect(self.page.locator('#deleted-tags')).to_contain_text('red ribbon')

    def test_batch_classification_is_selected_only_and_unsaved(self):
        for i in (0,2):self.page.locator('.thumb-check').nth(i).click()
        self.page.locator('#caption').fill('local draft')
        self.click('#batch-classify')
        expect(self.page.locator('#batch-result')).to_contain_text('2枚を分類しました（未保存）')
        expect(self.page.locator('#caption')).to_have_value('local draft')
        for i in range(4):self.assert_disk(i,'yasumin wears green school uniform')
        self.click('#batch-save');self.assert_disk(0,'local draft')
        self.assert_disk(1,'yasumin wears green school uniform')

    def test_batch_classification_failure_preserves_draft_and_selection(self):
        self.click('#batch-classify');self.assertIn('未選択では実行しません',self.dialogs[-1])
        self.page.locator('.thumb-check').nth(0).click();self.page.locator('#caption').fill('local draft')
        self.page.route('**/api/dataset/batch-classify-tags',lambda route:route.fulfill(status=500,content_type='application/json',body='{"detail":"classification failed"}'))
        self.click('#batch-classify')
        expect(self.page.locator('#caption')).to_have_value('local draft')
        expect(self.page.locator('#batch-count')).to_have_text('1枚選択')
        self.assert_disk(0,'yasumin wears green school uniform')

    def test_confirmed_shared_pose_switch_requires_common_assignment(self):
        path=self.folder/'0.anima.json';data=json.loads(path.read_text())
        data.update(mode='both',a_tags=[],common_tags=['standing'],raw_tags=['standing','sitting'])
        path.write_text(json.dumps(data));self.click('#btn-load')
        self.page.locator('#caption-mode').select_option('detailed')
        self.page.locator('#include-shared-pose').check()
        self.click('#btn-auto-distribute')
        expect(self.page.locator('#common-tags')).to_have_text('standing')
        expect(self.page.locator('#pool')).to_have_text('sitting')
        self.click('#btn-generate')
        self.assertIn('Shared pose: standing.',self.page.locator('#caption').input_value())
        self.assertNotIn('sitting',self.page.locator('#caption').input_value())

    def test_literal_sentence_insert_saves_selected_drafts_and_survives_reload(self):
        text='stndrgn has light purple hair,bob hair and half-lidded eyes.'
        self.page.locator('#caption').fill('unsaved manual')
        for i in (0,2):self.page.locator('.thumb-check').nth(i).click()
        self.page.locator('#batch-text').fill(text);self.click('#batch-text-insert')
        self.assert_disk(0,'unsaved manual\n'+text)
        self.assert_disk(2,'yasumin wears green school uniform\n'+text)
        self.assert_disk(1,'yasumin wears green school uniform')
        expect(self.page.locator('#caption')).to_have_value('unsaved manual\n'+text)
        self.assertFalse(any('preview-caption' in url or 'classify-tags' in url for url in self.requests))
        self.click('#batch-text-insert');self.assert_disk(0,'unsaved manual\n'+text)
        expect(self.page.locator('#batch-result')).to_contain_text('追加省略: 2枚')
        self.click('#btn-load');expect(self.page.locator('#caption')).to_have_value('unsaved manual\n'+text)

    def test_literal_no_selection_and_missing_anchor_keep_draft(self):
        self.page.locator('#batch-text').fill('literal');self.click('#batch-text-insert')
        self.assertIn('未選択では実行しません',self.dialogs[-1])
        self.page.locator('.thumb-check').nth(0).click();self.page.locator('#caption').fill('local draft')
        self.page.locator('#batch-text-position').select_option('before')
        self.page.locator('#batch-text-anchor').fill('absent');self.click('#batch-text-insert')
        expect(self.page.locator('#caption')).to_have_value('local draft')
        self.assert_disk(0,'yasumin wears green school uniform')

    def test_literal_prepend_preserves_multiline_input(self):
        text='  Line One,Two.\n日本語  '
        self.page.locator('.thumb-check').nth(0).click()
        self.page.locator('#batch-text').fill(text);self.page.locator('#batch-text-position').select_option('prepend')
        self.click('#batch-text-insert')
        self.assert_disk(0,text+'\nyasumin wears green school uniform')
        expect(self.page.locator('#caption')).to_have_value(text+'\nyasumin wears green school uniform')

    def test_literal_partial_failure_preserves_inserted_draft_for_save_retry(self):
        for i in (0,1):self.page.locator('.thumb-check').nth(i).click()
        self.click('#next');self.page.locator('#batch-text').fill('LITERAL')
        def partial(route):
            items=route.request.post_data_json['items']
            planned=[{**item,'caption':item['caption']+'\nLITERAL'} for item in items]
            route.fulfill(content_type='application/json',body=json.dumps({'updated':1,'failed':1,'items':[planned[0]],
                'failures':[{'path':planned[1]['path'],'detail':'disk failure','item':planned[1]}]}))
        self.page.route('**/api/dataset/batch-insert-text',partial)
        self.click('#batch-text-insert')
        expect(self.page.locator('#caption')).to_have_value('yasumin wears green school uniform\nLITERAL')
        expect(self.page.locator('#batch-result')).to_contain_text('1枚保存、1枚失敗')
        self.click('#batch-save')
        for i in (0,1):self.assert_disk(i,'yasumin wears green school uniform\nLITERAL')

    def test_literal_delete_replace_buttons_save_current_selected_draft(self):
        self.page.locator('#caption').fill('KEEP [x] [x] X')
        self.page.locator('.thumb-check').nth(0).click()
        self.page.locator('#batch-text').fill('[x]')
        self.page.locator('#batch-text-replacement').fill('日本語\n$1')
        self.click('#batch-text-replace')
        expected='KEEP 日本語\n$1 日本語\n$1 X'
        expect(self.page.locator('#caption')).to_have_value(expected);self.assert_disk(0,expected)
        self.assert_disk(1,'yasumin wears green school uniform')
        self.page.locator('#batch-text').fill('日本語\n$1');self.click('#batch-text-delete')
        self.assert_disk(0,'KEEP   X')
        self.click('#btn-load');expect(self.page.locator('#caption')).to_have_value('KEEP   X')
        self.assertFalse(any('preview-caption' in url or 'classify-tags' in url for url in self.requests))

    def test_literal_delete_replace_no_selection_or_empty_search_no_write(self):
        self.page.locator('#batch-text').fill('TEXT')
        for button in ('#batch-text-delete','#batch-text-replace'):
            self.click(button);self.assertIn('未選択では実行しません',self.dialogs[-1])
        self.page.locator('.thumb-check').nth(0).click();self.page.locator('#batch-text').fill('')
        self.click('#batch-text-delete');self.assert_disk(0,'yasumin wears green school uniform')

    def test_protected_text_survives_single_and_batch_regeneration_and_undo(self):
        text='stndrgn has light purple hair,bob hair and half-lidded eyes.'
        for i in (0,2):self.page.locator('.thumb-check').nth(i).click()
        self.page.locator('#batch-text').fill(text);self.click('#batch-text-insert')
        self.click('#btn-generate');self.assertIn(text,self.page.locator('#caption').input_value())
        self.click('#batch-generate');self.click('#batch-save')
        expect(self.page.locator('#protected-summary')).to_contain_text(text)
        self.click('#btn-load');self.click('#btn-generate')
        self.assertEqual(self.page.locator('#caption').input_value().count(text),1)
        self.click('#batch-undo')
        # Undo the batch save, then undo the insertion; generation itself is not a save.
        self.click('#batch-undo')
        expect(self.page.locator('#caption')).to_have_value('yasumin wears green school uniform')
        self.assert_disk(0,'yasumin wears green school uniform');self.assert_disk(2,'yasumin wears green school uniform')
        expect(self.page.locator('#protected-summary')).not_to_contain_text(text)

    def test_delete_protected_sentence_and_undo_restores_it(self):
        self.page.locator('.thumb-check').nth(0).click();self.page.locator('#batch-text').fill('KEEP THIS')
        self.click('#batch-text-insert');self.click('#batch-text-delete')
        self.click('#btn-generate');self.assertNotIn('KEEP THIS',self.page.locator('#caption').input_value())
        self.click('#batch-undo');self.click('#btn-generate')
        self.assertIn('KEEP THIS',self.page.locator('#caption').input_value())

    def test_exact_acceptance_scenario(self):
        self.page.locator('.thumb-check').nth(0).click(); self.replace()
        expect(self.page.locator('#caption')).to_have_value(self.expected); self.assert_disk(0, self.expected)
        self.click('#btn-save'); self.click('#next'); self.click('#prev')
        expect(self.page.locator('#caption')).to_have_value(self.expected); self.assert_disk(0, self.expected)
        self.click('#btn-load'); expect(self.page.locator('#caption')).to_have_value(self.expected)
        self.click('#btn-save-project'); expect(self.page.locator('#caption')).to_have_value(self.expected)
        self.assert_disk(0, self.expected)
        self.assertFalse(any('preview-caption' in url for url in self.requests))
        for _ in range(2):
            self.click('#btn-generate')
            self.assertEqual(self.page.locator('#caption').input_value().count('outfit ya01'), 1)
            self.click('#btn-save')

    def test_manual_edit_save_next_navigate_and_restart(self):
        text = '  manual 日本語\n\nexact caption \n '
        self.page.locator('#caption').fill(text); self.click('#btn-save-next')
        expect(self.page.locator('#counter')).to_have_text('2 / 4'); self.assert_disk(0, text)
        self.click('#prev'); expect(self.page.locator('#caption')).to_have_value(text)
        self.page.reload(); self.page.locator('#folder-path').fill(str(self.folder)); self.click('#btn-load')
        expect(self.page.locator('#caption')).to_have_value(text)
        self.assertFalse(any('preview-caption' in url for url in self.requests))

    def test_empty_caption_save_and_unsaved_navigation(self):
        self.page.locator('#caption').fill(''); self.click('#next'); self.click('#prev')
        expect(self.page.locator('#caption')).to_have_value('')
        self.click('#btn-save'); self.assert_disk(0, '')
        self.click('#btn-load'); expect(self.page.locator('#caption')).to_have_value('')

    def test_replace_uses_unsaved_current_text_and_subset(self):
        self.page.locator('#caption').fill('manual prefix: yasumin wears green school uniform')
        self.page.locator('.thumb').nth(0).click(modifiers=['Control'])
        self.page.locator('.thumb').nth(2).click(modifiers=['Control'])
        expect(self.page.locator('#batch-count')).to_have_text('2枚選択')
        self.replace()
        expect(self.page.locator('#caption')).to_have_value('manual prefix: ' + self.expected)
        self.assert_disk(0, 'manual prefix: ' + self.expected); self.assert_disk(2, self.expected)
        self.assert_disk(1, 'yasumin wears green school uniform'); self.assert_disk(3, 'yasumin wears green school uniform')

    def test_ctrl_shift_selection_mode_and_batch_tags(self):
        self.page.locator('.thumb').nth(1).click(modifiers=['Control'])
        self.page.locator('.thumb').nth(3).click(modifiers=['Shift'])
        expect(self.page.locator('#batch-count')).to_have_text('3枚選択')
        self.assertEqual(self.page.locator('.thumb.batch-selected').count(), 3)
        self.page.locator('#batch-tags').fill('blue eyes'); self.page.locator('#batch-dest').select_option('b')
        self.click('#batch-add')
        for i in range(1, 4):
            data = json.loads((self.folder / f'{i}.anima.json').read_text()); self.assertIn('blue eyes', data['b_tags'])
            self.assert_disk(i, 'yasumin wears green school uniform')
        self.assertNotIn('blue eyes', json.loads((self.folder / '0.anima.json').read_text())['b_tags'])
        self.click('#batch-remove')
        self.assertNotIn('blue eyes', json.loads((self.folder / '1.anima.json').read_text())['b_tags'])
        self.click('#batch-clear'); self.click('#batch-select-mode'); self.page.locator('.thumb').nth(0).click()
        expect(self.page.locator('#batch-count')).to_have_text('1枚選択')
        self.page.locator('.thumb').nth(0).click(); expect(self.page.locator('#batch-count')).to_have_text('0枚選択')

    def test_no_selection_is_visible_error_and_no_write(self):
        before = (self.folder / '0.txt').read_bytes(); self.replace()
        self.assertIn('未選択では実行しません', self.dialogs[-1])
        self.assertFalse(any('batch-replace' in url for url in self.requests))
        self.assertEqual((self.folder / '0.txt').read_bytes(), before)
        self.page.locator('#batch-tags').fill('blue eyes'); self.click('#batch-add')
        self.assertFalse(any('batch-tags' in url for url in self.requests))

    def test_settings_changes_never_regenerate_trigger_rename(self):
        text = 'custom caption unchanged'
        self.page.locator('#caption').fill(text); self.page.locator('#char-a').fill('new-trigger')
        self.page.locator('#include-style').uncheck(); self.click('#btn-save-project')
        expect(self.page.locator('#caption')).to_have_value(text)
        self.assertFalse(any('preview-caption' in url for url in self.requests))
        self.click('#btn-save'); self.assert_disk(0, text)
        self.click('#btn-generate'); self.assertIn('new-trigger wears', self.page.locator('#caption').input_value())
        self.assertEqual(self.page.locator('#a-tags').inner_text(), 'green school uniform')

    def test_save_failure_blocks_next_and_preserves_draft(self):
        self.page.route('**/api/dataset/update-multicaption', lambda route: route.fulfill(status=500, content_type='application/json', body='{"detail":"simulated disk failure"}'))
        self.page.locator('#caption').fill('unsaved text'); self.click('#btn-save-next')
        expect(self.page.locator('#counter')).to_have_text('1 / 4')
        expect(self.page.locator('#caption')).to_have_value('unsaved text')
        self.assertIn('simulated disk failure', self.dialogs)
        self.assert_disk(0, 'yasumin wears green school uniform')

    def test_rule_clear_keeps_current_caption_and_changes_next_generation(self):
        self.page.locator('.thumb-check').nth(0).click(); self.replace(); self.click('#clear-rules')
        expect(self.page.locator('#caption')).to_have_value(self.expected); self.assert_disk(0, self.expected)
        self.click('#btn-generate'); self.assertNotIn('outfit ya01', self.page.locator('#caption').input_value())

    def test_filename_is_text_not_html(self):
        # Windows also permits apostrophes and ampersands; HTML is constructed with textContent.
        path = self.folder / "x' & name.png"; Image.new('RGB', (16, 16)).save(path)
        self.click('#btn-load')
        expect(self.page.locator('.thumb').last.locator('div')).to_have_text("x' & name.png")
        self.assertEqual(self.page.locator('.thumb').last.locator('img').count(), 1)


if __name__ == '__main__': unittest.main()
