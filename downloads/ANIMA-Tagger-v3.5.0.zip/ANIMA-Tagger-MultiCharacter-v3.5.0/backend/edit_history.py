"""Bounded, process-local undo of saved caption files with conflict detection."""
import os
import tempfile
from functools import wraps
from pathlib import Path
from fastapi import HTTPException
try:
    from .caption_store import paths, store_lock
    from .security import safe_file, read_text_bytes
except ImportError:
    from caption_store import paths, store_lock
    from security import safe_file, read_text_bytes

history = []
MAX_BYTES = 32 * 1024 * 1024


def snapshot(image):
    return {str(safe_file(path)): read_text_bytes(path) if Path(path).exists() else None for path in paths(image)}


def undoable(fn):
    @wraps(fn)
    async def wrapped(*args, **kwargs):
        req = args[0] if args else next(iter(kwargs.values()))
        items = getattr(req, 'items', [req])
        with store_lock:
            before, size = {}, 0
            for item in items:
                files = snapshot(item.path)
                size += sum(len(data or b'') for data in files.values())
                if size > MAX_BYTES:
                    raise HTTPException(413, '取り消し履歴の上限32MiBを超えています。対象画像を分けてください。')
                before[item.path] = files
            response = None
            try:
                response = await fn(*args, **kwargs)
                return response
            finally:
                changes = {}
                record_size = size
                oversized = False
                for image, old in before.items():
                    after = snapshot(image)
                    record_size += sum(len(data or b'') for data in after.values())
                    if record_size > MAX_BYTES:
                        oversized = True; break
                    if old != after: changes[image] = {'before':old, 'after':after}
                if oversized:
                    history.clear()
                    if isinstance(response,dict): response["undo_warning"] = "保存は完了しましたが、履歴容量32MiBを超えたため取り消せません。履歴をクリアしました。"
                elif changes:
                    history.append(changes)
                    while len(history)>20 or sum(len(v or b'') for record in history for entry in record.values() for files in entry.values() for v in files.values()) > MAX_BYTES:
                        history.pop(0)
    import inspect
    wrapped.__signature__ = inspect.signature(fn, eval_str=True)
    return wrapped


def restore_file(path, data):
    path = safe_file(path)
    if data is None:
        path.unlink(missing_ok=True); return
    fd, name = tempfile.mkstemp(prefix='.'+path.name+'.undo-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def undo_last(folder):
    with store_lock:
        if not history: raise HTTPException(400,'取り消せる保存履歴がありません。')
        record=history[-1]
        root=Path(folder).resolve()
        if any(Path(image).resolve().parent != root for image in record):
            raise HTTPException(409,'最後の保存操作は別のフォルダです。そのフォルダを開いて取り消してください。')
        for image,entry in record.items():
            if snapshot(image) != entry['after']:
                raise HTTPException(409,'保存後にファイルが変更されています。上書きを避けるため取り消しません。')
        try:
            for image,entry in record.items():
                for path,data in entry['before'].items():restore_file(path,data)
        except (OSError,ValueError):
            for image,entry in record.items(): entry['after']=snapshot(image)
            raise
        count=len(record);history.pop()
        return count
