from __future__ import annotations
import sys
import os
import asyncio
import glob
import gc
import json
import re
import struct
import threading
import zlib
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from pathlib import Path
from typing import Literal
try:
    from .caption_store import read_json as _read_json, write_json as _write_json, load_sidecar, save_image, synchronized
except ImportError:
    from caption_store import read_json as _read_json, write_json as _write_json, load_sidecar, save_image, synchronized
from PIL import Image

import io
from contextlib import asynccontextmanager, suppress

class WebSocketStderrRedirector(io.IOBase):
    def __init__(self, original_stderr):
        self.original_stderr = original_stderr

    def write(self, s):
        self.original_stderr.write(s)
        self.original_stderr.flush()
        if s.strip():
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(broadcast_log(s))
            except Exception:
                pass
        return len(s)

    def flush(self):
        self.original_stderr.flush()

@asynccontextmanager
async def lifespan(app):
    task = None
    if os.environ.get("ANIMA_NO_BROWSER") != "1":
        async def open_browser():
            await asyncio.sleep(1.5)
            webbrowser.open(f"http://localhost:{get_app_port()}")
        task = asyncio.create_task(open_browser())
    try:
        yield
    finally:
        if task is not None:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task


app = FastAPI(lifespan=lifespan)


@app.exception_handler(OSError)
@app.exception_handler(ValueError)
async def storage_error(request, exc):
    return JSONResponse(status_code=500, content={"detail": f"読み込み・保存エラー: {exc}。一括保存は画像単位です。再読み込みして保存状態を確認してください。"})


import webbrowser

def get_app_port():
    return int(os.environ.get("APP_PORT", "8010"))

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
QWEN_MODEL_NAME = "Qwen/Qwen2-VL-2B-Instruct"
WD14_MODEL_NAME = "SmilingWolf/wd-swinv2-tagger-v3"
WD14_GENERAL_THRESHOLD = 0.35
WD14_CHARACTER_THRESHOLD = 0.85
ANIMA_STYLE_TAGS = {
    "anime style",
    "clean lineart",
    "soft shading",
    "cel shading",
    "detailed shading",
    "flat color",
    "pastel colors",
    "vivid colors",
    "muted colors",
    "high contrast",
    "low contrast",
    "rim lighting",
    "backlighting",
    "soft lighting",
    "dramatic lighting",
    "simple background",
    "white background",
    "transparent background",
    "full body",
    "upper body",
    "portrait",
    "cowboy shot",
    "dynamic pose",
    "symmetrical composition",
}
EXCLUDED_TAGS = {
    "masterpiece",
    "best quality",
    "high quality",
    "normal quality",
    "low quality",
    "worst quality",
    "highres",
    "absurdres",
    "official art",
    "artist name",
}
WORKFLOW_MARKERS = (
    '"inputs"',
    '"class_type"',
    '"_meta"',
    '"widgets_values"',
    '"nodes"',
    '"links"',
    "class_type",
    "_meta",
    "widgets_values",
)
PROMPT_METADATA_KEYS = {
    "anima_prompt",
    "anima prompt",
    "parameters",
    "prompt",
    "positive",
    "positive_prompt",
    "positive prompt",
    "caption",
    "description",
    "image_description",
    "image description",
    "imagedescription",
    "usercomment",
    "user_comment",
    "user comment",
    "270",
    "37510",
}

# Global logs and connection registry
tagger_logs = ""
tagger_running = False
active_connections: list[WebSocket] = []

def parse_png_text_chunks(image_path: str) -> dict[str, str]:
    chunks = {}
    try:
        with open(image_path, "rb") as f:
            data = f.read()

        if len(data) < 8 or data[:8] != b"\x89PNG\r\n\x1a\n":
            return chunks

        offset = 8
        while offset + 12 <= len(data):
            length = struct.unpack(">I", data[offset:offset + 4])[0]
            chunk_type = data[offset + 4:offset + 8].decode("latin-1", errors="ignore")
            chunk_data = data[offset + 8:offset + 8 + length]

            if chunk_type == "tEXt":
                null_index = chunk_data.find(b"\x00")
                if null_index != -1:
                    key = chunk_data[:null_index].decode("latin-1", errors="ignore")
                    value = chunk_data[null_index + 1:].decode("latin-1", errors="ignore")
                    try:
                        value = value.encode("latin-1").decode("utf-8")
                    except UnicodeDecodeError:
                        pass
                    chunks[key] = value

            elif chunk_type == "zTXt":
                null_index = chunk_data.find(b"\x00")
                if null_index != -1 and len(chunk_data) > null_index + 2:
                    key = chunk_data[:null_index].decode("latin-1", errors="ignore")
                    compressed = chunk_data[null_index + 2:]
                    try:
                        chunks[key] = zlib.decompress(compressed).decode("utf-8", errors="ignore")
                    except zlib.error:
                        pass

            elif chunk_type == "iTXt":
                ptr = chunk_data.find(b"\x00")
                if ptr != -1 and len(chunk_data) > ptr + 2:
                    key = chunk_data[:ptr].decode("utf-8", errors="ignore")
                    comp_flag = chunk_data[ptr + 1]
                    ptr += 3

                    lang_end = chunk_data.find(b"\x00", ptr)
                    if lang_end == -1:
                        offset += length + 12
                        continue

                    translated_end = chunk_data.find(b"\x00", lang_end + 1)
                    if translated_end == -1:
                        offset += length + 12
                        continue

                    text_data = chunk_data[translated_end + 1:]
                    if comp_flag == 1:
                        try:
                            text_data = zlib.decompress(text_data)
                        except zlib.error:
                            offset += length + 12
                            continue
                    chunks[key] = text_data.decode("utf-8", errors="ignore")

            if chunk_type == "IEND":
                break
            offset += length + 12
    except Exception:
        return {}

    return chunks

def recursive_find_comfy_text(flow: dict, input_value, visited: set[str] | None = None) -> str:
    if not input_value:
        return ""

    if visited is None:
        visited = set()

    node_id = str(input_value[0] if isinstance(input_value, list) else input_value)
    if node_id in visited:
        return ""
    visited.add(node_id)

    node = flow.get(node_id)
    if not isinstance(node, dict):
        return ""

    inputs = node.get("inputs")
    if not isinstance(inputs, dict):
        return ""

    class_type = str(node.get("class_type", ""))
    if class_type == "ANIMALinePromptList":
        fixed_prompt = inputs.get("fixed_prompt")
        line_prompts = inputs.get("line_prompts")
        parts = []
        if isinstance(fixed_prompt, str) and fixed_prompt.strip():
            parts.append(fixed_prompt.strip())
        if isinstance(line_prompts, str):
            for line in line_prompts.splitlines():
                line = line.strip()
                if line:
                    parts.append(line)
                    break
        return "\n".join(parts).strip()

    value = inputs.get("value")
    if isinstance(value, str):
        return value

    for key in ("text", "prompt"):
        value = inputs.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, list):
            found = recursive_find_comfy_text(flow, value, visited)
            if found:
                return found

    if node.get("class_type") == "StringConcatenate":
        delimiter = inputs.get("delimiter")
        if not isinstance(delimiter, str):
            delimiter = ""
        parts = []
        for key in ("string_a", "string_b", "string_c", "string_d"):
            found = recursive_find_comfy_text(flow, inputs.get(key), visited)
            if found:
                parts.append(found)
        return delimiter.join(parts)

    for key in (
        "conditioning",
        "conditioning_1",
        "conditioning_2",
        "base_conditioning",
        "positive",
    ):
        if key in inputs:
            found = recursive_find_comfy_text(flow, inputs[key], visited)
            if found:
                return found

    return ""

def safe_find_comfy_prompt_text(flow: dict, input_value) -> str:
    if not input_value:
        return ""

    node_id = str(input_value[0] if isinstance(input_value, list) else input_value)
    node = flow.get(node_id)
    if not isinstance(node, dict):
        return ""

    inputs = node.get("inputs")
    if not isinstance(inputs, dict):
        return ""

    class_type = str(node.get("class_type", ""))
    allowed_direct_types = {
        "CLIPTextEncode",
        "CLIPTextEncodeSDXL",
        "CLIPTextEncodeSDXLRefiner",
        "Power Prompt (rgthree)",
    }
    if class_type not in allowed_direct_types:
        return ""

    for key in ("text", "prompt"):
        value = inputs.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
        if isinstance(value, list):
            found = recursive_find_comfy_text(flow, value)
            if found:
                return found.strip()

    parts = [
        inputs.get(key).strip()
        for key in ("text_g", "text_l")
        if isinstance(inputs.get(key), str) and inputs.get(key).strip()
    ]
    return "\n".join(parts).strip()

def extract_positive_prompt_from_metadata(data: dict[str, str]) -> str:
    parameters = data.get("parameters")
    if isinstance(parameters, str) and parameters.strip():
        raw = parameters
        if any(marker in raw for marker in WORKFLOW_MARKERS):
            raw = re.split(r',\s*"\d+"\s*:\s*\{', raw, maxsplit=1)[0]
        neg_index = raw.rfind("\nNegative prompt: ")
        step_index = raw.rfind("\nSteps: ")

        if neg_index != -1:
            return raw[:neg_index].strip()
        if step_index != -1:
            return raw[:step_index].strip()
        return raw.strip()

    comfy_prompt = data.get("prompt")
    if isinstance(comfy_prompt, str) and comfy_prompt.strip():
        try:
            flow = json.loads(comfy_prompt)
            if isinstance(flow, dict):
                samplers = [
                    node for node in flow.values()
                    if isinstance(node, dict) and node.get("class_type") in {"KSampler", "KSamplerAdvanced"}
                ]
                if samplers:
                    positive = safe_find_comfy_prompt_text(flow, samplers[0].get("inputs", {}).get("positive"))
                    if positive:
                        return positive.strip()
        except json.JSONDecodeError:
            pass
        if looks_like_workflow_text(comfy_prompt):
            return ""

    if data.get("Software") == "NovelAI" or "NovelAI" in str(data.get("Source", "")) or data.get("Comment"):
        description = data.get("Description")
        if isinstance(description, str) and description.strip():
            return description.strip()
        comment = data.get("Comment")
        if isinstance(comment, str) and comment.strip():
            try:
                parsed = json.loads(comment)
                prompt = parsed.get("prompt")
                if isinstance(prompt, str):
                    return prompt.strip()
            except json.JSONDecodeError:
                return comment.strip()

    for key in PROMPT_METADATA_KEYS:
        value = get_metadata_value(data, key)
        if key == "prompt" and isinstance(value, str) and looks_like_workflow_text(value):
            continue
        if isinstance(value, str) and value.strip():
            return value.strip()

    return ""

def looks_like_workflow_text(text: str) -> bool:
    if not isinstance(text, str):
        return False
    stripped = text.lstrip()
    if stripped.startswith("{") and any(marker in stripped for marker in WORKFLOW_MARKERS):
        return True
    return any(marker in stripped for marker in ('"class_type"', '"widgets_values"', '"nodes"', '"links"'))

def get_metadata_value(data: dict[str, str], key: str) -> str:
    variants = {
        key,
        key.capitalize(),
        key.title(),
        key.replace("_", " "),
        key.replace(" ", "_"),
    }
    lower_map = {str(existing_key).lower(): existing_key for existing_key in data.keys()}

    for variant in variants:
        if variant in data:
            return data[variant]
        actual_key = lower_map.get(variant.lower())
        if actual_key is not None:
            return data[actual_key]

    return ""

def extract_prompt_text_from_image(image_path: str) -> str:
    metadata = parse_png_text_chunks(image_path)

    try:
        with Image.open(image_path) as img:
            for key, value in img.info.items():
                if isinstance(value, bytes):
                    value = value.decode("utf-8", errors="ignore")
                if isinstance(value, str) and value.strip():
                    metadata.setdefault(str(key), value.strip())

            exif = img.getexif()
            for tag_id in (270, 37510):
                value = exif.get(tag_id)
                if isinstance(value, bytes):
                    value = value.decode("utf-8", errors="ignore")
                if isinstance(value, str) and value.strip():
                    metadata.setdefault(str(tag_id), value.strip())
    except Exception:
        pass

    return extract_positive_prompt_from_metadata(metadata)

def prompt_text_to_tags(prompt_text: str) -> list[str]:
    if not prompt_text:
        return []

    if looks_like_workflow_text(prompt_text):
        return []

    prompt_text = re.split(r',\s*"\d+"\s*:\s*\{', prompt_text, maxsplit=1)[0]
    prompt_text = re.split(r"\bNegative prompt:\b|\bSteps:\b|\bSampler:\b", prompt_text, maxsplit=1, flags=re.IGNORECASE)[0]
    prompt_text = re.sub(r"<[^>]+>", "", prompt_text)
    prompt_text = re.sub(r"\([^)]*:[0-9.]+[^)]*\)", "", prompt_text)
    prompt_text = re.sub(r"\[[^\]]*:[0-9.]+[^\]]*\]", "", prompt_text)
    prompt_text = prompt_text.replace("\n", ",")

    tags = []
    for raw_tag in prompt_text.split(","):
        tag = raw_tag.strip().lower()
        tag = re.sub(r"^[({\[]+|[)}\]]+$", "", tag).strip()
        tag = re.sub(r"\s+", " ", tag)
        if not tag or len(tag) > 80:
            continue
        if looks_like_workflow_text(tag):
            continue
        if any(marker.strip('"') in tag for marker in WORKFLOW_MARKERS):
            continue
        if any(char in tag for char in ('"', "{", "}", "[", "]")):
            continue
        if re.search(r"\b(inputs|class_type|widgets_values|last_node_id|last_link_id|filename_prefix)\b", tag):
            continue
        if tag.count(":") > 1 or re.search(r'"\s*:', tag):
            continue
        if re.fullmatch(r"[\W_]+", tag):
            continue
        tags.append(tag)
    return tags

def dedupe_tags(tags: list[str]) -> list[str]:
    seen = set()
    deduped = []
    for tag in tags:
        normalized = tag.strip()
        key = normalized.lower()
        if key.isdigit():
            continue
        if key in EXCLUDED_TAGS:
            continue
        if normalized and key not in seen:
            seen.add(key)
            deduped.append(normalized)
    return deduped

def normalize_tag_text(tag: str) -> str:
    tag = tag.strip().lower()
    tag = tag.replace("_", " ")
    tag = re.sub(r"\s+", " ", tag)
    return tag

def load_wd14_tagger():
    import onnxruntime as ort
    import pandas as pd
    from huggingface_hub import hf_hub_download
    model_path = hf_hub_download(WD14_MODEL_NAME, "model.onnx")
    tags_path = hf_hub_download(WD14_MODEL_NAME, "selected_tags.csv")
    providers = ["CPUExecutionProvider"]
    session = ort.InferenceSession(model_path, providers=providers)
    tags_df = pd.read_csv(tags_path)
    return session, tags_df

def prepare_wd14_image(image_path: str, target_size: int):
    import numpy as np
    with Image.open(image_path) as img:
        img = img.convert("RGB")
        width, height = img.size
        side = max(width, height)
        canvas = Image.new("RGB", (side, side), (255, 255, 255))
        canvas.paste(img, ((side - width) // 2, (side - height) // 2))
        resampling = getattr(Image, "Resampling", Image).LANCZOS
        canvas = canvas.resize((target_size, target_size), resampling)

    image = np.asarray(canvas, dtype=np.float32)
    image = image[:, :, ::-1]
    return np.expand_dims(image, axis=0)

def run_wd14_tagger(session, tags_df: pd.DataFrame, image_path: str) -> list[str]:
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    input_shape = session.get_inputs()[0].shape
    target_size = int(input_shape[1] or 448)

    image = prepare_wd14_image(image_path, target_size)
    probs = session.run([output_name], {input_name: image})[0][0]

    tags = []
    for idx, probability in enumerate(probs[:len(tags_df)]):
        row = tags_df.iloc[idx]
        category = int(row.get("category", 0))
        if category == 9:
            continue
        if category == 4 and probability < WD14_CHARACTER_THRESHOLD:
            continue
        if category != 4 and probability < WD14_GENERAL_THRESHOLD:
            continue

        name = str(row["name"])
        tag = normalize_tag_text(name)
        if tag:
            tags.append(tag)

    return tags

def split_qwen_tags(output_text: str) -> list[str]:
    tags = []
    for raw_tag in output_text.split(","):
        tag = normalize_tag_text(raw_tag)
        if not tag or len(tag) > 80:
            continue
        if tag.isdigit():
            continue
        if any(marker.strip('"') in tag for marker in WORKFLOW_MARKERS):
            continue
        if any(char in tag for char in ('"', "{", "}", "[", "]")):
            continue
        if re.fullmatch(r"[\W_]+", tag):
            continue
        if tag:
            tags.append(tag)
    return tags


# --- Multi-character caption helpers (v2.4) ---
PROJECT_FILE = ".anima_tagger_project.json"

CLOTHING_WORDS = {
    "shirt", "skirt", "dress", "jacket", "coat", "hoodie", "sweater", "uniform",
    "blouse", "pants", "shorts", "jeans", "socks", "stockings", "shoes", "boots",
    "sneakers", "gloves", "hat", "cap", "tie", "ribbon", "bow", "collar", "sleeves",
    "kimono", "swimsuit", "underwear", "bra", "panties", "clothes", "clothing", "wearing"
}
ACTION_WORDS = {
    "smile", "smiling", "angry", "crying", "sad", "happy", "blush", "blushing",
    "standing", "sitting", "lying", "kneeling", "walking", "running", "waving",
    "looking", "holding", "arms", "hands", "open mouth", "closed mouth", "serious",
    "surprised", "laughing", "sleeping", "leaning", "jumping", "crouching", "arm up",
    "arms up", "hand up", "hands up", "pointing", "thumbs up"
}
STYLE_WORDS = {
    "lineart", "outline", "shading", "style", "sketch", "watercolor", "painting",
    "flat color", "cel shading", "soft shading", "detailed shading", "anime style", "clean lineart",
    "rough lineart", "soft lineart", "pastel colors", "vivid colors", "muted colors", "high contrast",
    "low contrast", "lighting", "rim lighting", "backlighting", "soft lighting", "dramatic lighting"
}
BACKGROUND_WORDS = {
    "background", "indoors", "outdoors", "sky", "room", "street", "window", "school", "classroom",
    "bedroom", "office", "park", "city", "forest", "beach", "simple background", "white background",
    "transparent background", "purple background", "blue background", "green background", "pink background"
}
COMPOSITION_WORDS = {
    "full body", "upper body", "portrait", "cowboy shot", "from above", "from below", "dynamic pose",
    "symmetrical composition", "close-up", "close up", "profile", "side view", "front view", "back view",
    "looking at viewer", "2girls", "2boys", "multiple girls", "multiple boys"
}

COLOR_WORDS = {
    "black", "white", "red", "blue", "green", "yellow", "pink", "purple", "orange", "brown", "gray", "grey",
    "blonde", "gold", "silver", "aqua", "teal", "cyan", "magenta", "violet"
}

# Generic tags that should disappear when a more specific tag is present.
GENERIC_SPECIFIC_RULES = {
    "socks": ("socks",),
    "shoes": ("shoes", "sneakers", "boots", "loafers"),
    "ribbon": ("ribbon", "neck ribbon", "hair ribbon"),
    "dress": ("dress",),
    "jacket": ("jacket",),
    "skirt": ("skirt",),
    "shirt": ("shirt",),
    "holding": ("holding ",),
    "pen": ("holding pen",),
}


def _project_path(folder_path: str) -> str:
    return os.path.join(folder_path, PROJECT_FILE)


def classify_caption_tag(tag: str) -> str:
    t = tag.lower().strip()
    if any(w in t for w in CLOTHING_WORDS):
        return "wears"
    if any(w in t for w in STYLE_WORDS):
        return "style"
    if any(w in t for w in BACKGROUND_WORDS):
        return "background"
    if any(w in t for w in ACTION_WORDS):
        return "action"
    if any(w in t for w in COMPOSITION_WORDS):
        return "composition"
    return "has"


def _is_specific_for(generic: str, tag: str) -> bool:
    t = tag.lower().strip()
    if t == generic:
        return False
    if generic == "holding":
        return t.startswith("holding ")
    if generic == "pen":
        return t == "holding pen"
    # "white socks" is more specific than "socks", etc.
    return t.endswith(" " + generic) or t in GENERIC_SPECIFIC_RULES.get(generic, ())


def cleanup_tags(tags: list[str], protected: set[str] | None = None) -> list[str]:
    """Deduplicate and remove obvious generic duplicates without guessing between conflicts."""
    protected = {x.lower().strip() for x in (protected or set()) if x}
    cleaned = dedupe_tags([normalize_tag_text(t) for t in tags if t and t.strip()])
    lowers = [t.lower().strip() for t in cleaned]
    keep = []
    for tag, low in zip(cleaned, lowers):
        if low in protected:
            keep.append(tag)
            continue
        drop = False
        if low in GENERIC_SPECIFIC_RULES:
            for other in lowers:
                if _is_specific_for(low, other):
                    drop = True
                    break
        if not drop:
            keep.append(tag)
    return dedupe_tags(keep)


def _color_tags(tags: list[str], suffix: str) -> list[str]:
    out = []
    for tag in tags:
        t = tag.lower().strip()
        if t.endswith(" " + suffix):
            first = t.split()[0]
            if first in COLOR_WORDS:
                out.append(t)
    return sorted(set(out))


def find_caption_warnings(a_tags: list[str], b_tags: list[str], common_tags: list[str], char_a: str, char_b: str) -> list[str]:
    warnings = []
    for label, tags in ((char_a or "A", a_tags), (char_b or "B", b_tags)):
        eye_colors = _color_tags(tags, "eyes")
        hair_colors = _color_tags(tags, "hair")
        if len(eye_colors) > 1:
            warnings.append(f"{label}: 目の色が複数あります → {', '.join(eye_colors)}")
        if len(hair_colors) > 1:
            warnings.append(f"{label}: 髪色が複数あります → {', '.join(hair_colors)}")
        lows = {t.lower().strip() for t in tags}
        has_dress = any(t == "dress" or t.endswith(" dress") for t in lows)
        has_skirt = any(t == "skirt" or t.endswith(" skirt") for t in lows)
        if has_dress and has_skirt:
            warnings.append(f"{label}: dress系 と skirt系 の両方があります。画像に本当に両方あるか確認してください。")
        has_pen = any(t == "pen" or t.endswith(" pen") for t in lows)
        has_pencil = any(t == "pencil" or t.endswith(" pencil") for t in lows)
        if has_pen and has_pencil:
            warnings.append(f"{label}: pen と pencil の両方があります。どちらか誤検出なら削除してください。")
    # Trigger words should never be scene tags.
    common_lows = {t.lower().strip() for t in common_tags}
    for label, trigger in (("A", char_a), ("B", char_b)):
        if trigger and trigger.lower().strip() in common_lows:
            warnings.append(f"Character {label} trigger '{trigger}' が共通/シーンに入っています。自動的にcaptionから除外します。")
    return warnings


def _join_tags(tags: list[str]) -> str:
    tags = cleanup_tags(tags)
    if not tags:
        return ""
    if len(tags) == 1:
        return tags[0]
    return ", ".join(tags[:-1]) + " and " + tags[-1]


def _action_phrase(tag: str) -> str:
    t = tag.lower().strip()
    exact = {
        "smile": "smiling", "blush": "blushing", "open mouth": "with an open mouth",
        "closed mouth": "with a closed mouth", "looking at viewer": "looking at viewer",
        "arm up": "with one arm raised", "arms up": "with both arms raised",
        "hand up": "with one hand raised", "hands up": "with both hands raised",
        "holding pen": "holding a pen", "holding pencil": "holding a pencil",
        "thumbs up": "giving a thumbs up",
    }
    if t in exact:
        return exact[t]
    if t.startswith("holding "):
        obj = t[len("holding "):].strip()
        article = "an" if obj[:1] in "aeiou" else "a"
        return f"holding {article} {obj}"
    return t


def _character_sentences(name: str, tags: list[str]) -> list[str]:
    buckets = {"has": [], "wears": [], "action": [], "style": [], "background": [], "composition": []}
    for tag in cleanup_tags(tags, protected={name}):
        if tag.lower().strip() == name.lower().strip():
            continue
        kind = classify_caption_tag(tag)
        buckets[kind].append(tag)
    lines = []
    if buckets["has"]:
        lines.append(f"{name} has {_join_tags(buckets['has'])}.")
    if buckets["wears"]:
        lines.append(f"{name} wears {_join_tags(buckets['wears'])}.")
    if buckets["action"]:
        actions = [_action_phrase(t) for t in buckets["action"]]
        lines.append(f"{name} is {_join_tags(actions)}.")
    return lines


def _split_common(common_tags: list[str], trigger_words: set[str]) -> dict[str, list[str]]:
    buckets = {"scene": [], "style": [], "composition": []}
    for tag in cleanup_tags(common_tags, protected=trigger_words):
        t = tag.lower().strip()
        if t in trigger_words or t in {"1girl", "solo", "2girls", "1boy", "2boys"}:
            continue
        kind = classify_caption_tag(tag)
        if kind == "style":
            buckets["style"].append(tag)
        elif kind in {"background"}:
            buckets["scene"].append(tag)
        elif kind == "composition":
            buckets["composition"].append(tag)
        else:
            # Common pose/action/object tags belong to the shared scene sentence.
            buckets["scene"].append(tag)
    return buckets


def build_multichar_caption(
    mode: str, char_a: str, char_b: str, a_tags: list[str], b_tags: list[str], common_tags: list[str],
    include_style: bool = True, include_scene: bool = True, trigger_aliases: list[str] | None = None
) -> tuple[str, list[str]]:
    char_a = (char_a or "chara a").strip()
    char_b = (char_b or "chara b").strip()
    trigger_words = {char_a.lower(), char_b.lower(), *(t.strip().lower() for t in (trigger_aliases or []))}

    # Warnings inspect the original assignment before generic duplicates are removed.
    warnings = find_caption_warnings(a_tags, b_tags, common_tags, char_a, char_b)
    a_tags = cleanup_tags([t for t in a_tags if t.strip().lower() not in trigger_words])
    b_tags = cleanup_tags([t for t in b_tags if t.strip().lower() not in trigger_words])
    common_tags = cleanup_tags([t for t in common_tags if t.strip().lower() not in trigger_words])

    # Style/background/composition tags are global even if the user placed them in A/B.
    global_extra = []
    for tags in (a_tags, b_tags):
        for tag in tags:
            if classify_caption_tag(tag) in {"style", "background", "composition"}:
                global_extra.append(tag)
    common_tags = cleanup_tags(common_tags + global_extra, protected={char_a, char_b})

    lines = []
    if mode == "a":
        lines.append(f"{char_a}, 1girl, solo.")
        lines += _character_sentences(char_a, a_tags)
    elif mode == "b":
        lines.append(f"{char_b}, 1girl, solo.")
        lines += _character_sentences(char_b, b_tags)
    else:
        lines.append(f"{char_a} and {char_b}, 2girls.")
        lines += _character_sentences(char_a, a_tags)
        lines += _character_sentences(char_b, b_tags)

    common = _split_common(common_tags, trigger_words)
    if include_scene and common["scene"]:
        lines.append(f"Scene: {_join_tags(common['scene'])}.")
    if include_scene and common["composition"]:
        lines.append(f"Composition: {_join_tags(common['composition'])}.")
    if include_style and common["style"]:
        lines.append(f"Style: {_join_tags(common['style'])}.")

    return " ".join(lines), warnings

@app.websocket("/ws/logs")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    try:
        await websocket.send_text("--- Connection Established ---")
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in active_connections:
            active_connections.remove(websocket)

async def broadcast_log(line: str):
    global tagger_logs
    tagger_logs += line
    # Keep logs size reasonable
    if len(tagger_logs) > 20000:
        tagger_logs = tagger_logs[-20000:]

    if threading.current_thread() is not threading.main_thread():
        return
        
    for connection in list(active_connections):
        try:
            await connection.send_text(line)
        except Exception:
            if connection in active_connections:
                active_connections.remove(connection)

class TaggerConfig(BaseModel):
    folder_path: str
    trigger_word: str

@app.get("/api/browse-folder")
async def browse_folder():
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        try:
            folder_path = filedialog.askdirectory(parent=root, title="Select Dataset Folder")
        finally:
            root.destroy()
        if folder_path:
            return {"path": folder_path}
        return {"path": ""}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/dataset/images")
async def list_images(path: str):
    if not os.path.isdir(path):
        raise HTTPException(status_code=404, detail="Dataset folder not found")
    project = _read_json(_project_path(path), {
        "char_a": "chara a", "char_b": "chara b", "fixed_a": [], "fixed_b": [], "tag_map": {},
        "include_style": True, "include_scene": True
    })
    project.setdefault("include_style", True)
    project.setdefault("include_scene", True)
    names = sorted(f for f in os.listdir(path) if Path(f).suffix.lower() in IMAGE_EXTENSIONS and os.path.isfile(os.path.join(path, f)))
    stems = [os.path.normcase(os.path.splitext(f)[0]) for f in names]
    if len(stems) != len(set(stems)):
        raise HTTPException(status_code=409, detail="同名の画像（拡張子のみ異なる）が同じTXT/sidecarを共有します。画像名を変更してください")
    files = []
    for f in names:
        ext = os.path.splitext(f)[1].lower()
        if ext not in IMAGE_EXTENSIONS or not os.path.isfile(os.path.join(path, f)):
            continue
        base = os.path.splitext(f)[0]
        image_path = os.path.join(path, f)
        txt_path = os.path.join(path, base + ".txt")
        sidecar = load_sidecar(image_path)
        if sidecar:
            tags = dedupe_tags(sidecar.get("raw_tags", []))
            caption = sidecar.get("caption")
            if caption is None:
                caption = Path(txt_path).read_bytes().decode("utf-8") if Path(txt_path).exists() else ""
            editor = {
                "mode": sidecar.get("mode", "both"),
                "a_tags": sidecar.get("a_tags", []),
                "b_tags": sidecar.get("b_tags", []),
                "common_tags": sidecar.get("common_tags", []),
                "phrase_replacements": sidecar.get("phrase_replacements", []),
            }
        else:
            tags = []
            if os.path.exists(txt_path):
                with open(txt_path, "r", encoding="utf-8", newline="") as tf:
                    text = tf.read()
                # Old v1 captions are comma-separated. Natural-language txt is kept as caption only.
                if "." not in text:
                    tags = dedupe_tags([t.strip() for t in text.split(",") if t.strip()])
                caption = text
            else:
                tags = dedupe_tags(prompt_text_to_tags(extract_prompt_text_from_image(image_path)))
                caption = ""
            editor = {"mode": "both", "a_tags": [], "b_tags": [], "common_tags": list(tags), "phrase_replacements": []}
        files.append({"name": f, "path": image_path, "tags": tags, "caption": caption, "editor": editor})
    return {"files": files, "project": project}

def _trigger_aliases(values):
    # Trigger configuration must not pass through visual-tag quality filters.
    return list({value.strip().lower(): value.strip() for value in values if value.strip()}.values())


class ProjectConfig(BaseModel):
    folder_path: str
    char_a: str = "chara a"
    char_b: str = "chara b"
    fixed_a: list[str] = []
    fixed_b: list[str] = []
    tag_map: dict[str, str] = {}
    include_style: bool = True
    include_scene: bool = True
    phrase_replacements: list[dict] = []
    trigger_aliases: list[str] = []

@app.post("/api/project/config")
async def save_project_config(config: ProjectConfig):
    if not os.path.isdir(config.folder_path):
        raise HTTPException(status_code=404, detail="Folder not found")
    existing = _read_json(_project_path(config.folder_path), {})
    data = {**config.model_dump(exclude={"folder_path"}), **existing,
            **config.model_dump(exclude={"folder_path"}, exclude_unset=True)}
    aliases = _trigger_aliases(existing.get("trigger_aliases", []) + data.get("trigger_aliases", []))
    for key, default in (("char_a", "chara a"), ("char_b", "chara b")):
        previous = existing.get(key, default)
        if previous.strip().lower() != data[key].strip().lower():
            aliases = _trigger_aliases(aliases + [previous])
    data["trigger_aliases"] = aliases
    _write_json(_project_path(config.folder_path), data)
    return {"status": "success", "project": data}


class AutoDistributeRequest(BaseModel):
    mode: str = "a"
    char_a: str = "chara a"
    char_b: str = "chara b"
    tags: list[str] = []

@app.post("/api/dataset/auto-distribute")
async def auto_distribute(req: AutoDistributeRequest):
    char_a = (req.char_a or "chara a").strip()
    char_b = (req.char_b or "chara b").strip()
    triggers = {char_a.lower(), char_b.lower()}
    character_tags, common_tags = [], []
    for tag in cleanup_tags(req.tags, protected={char_a, char_b}):
        if tag.lower().strip() in triggers or tag.lower().strip() in {"1girl", "solo", "2girls", "1boy", "2boys"}:
            continue
        kind = classify_caption_tag(tag)
        if kind in {"style", "background", "composition"}:
            common_tags.append(tag)
        else:
            character_tags.append(tag)
    result = {"a_tags": [], "b_tags": [], "common_tags": cleanup_tags(common_tags)}
    if req.mode == "a":
        result["a_tags"] = cleanup_tags(character_tags)
    elif req.mode == "b":
        result["b_tags"] = cleanup_tags(character_tags)
    else:
        result["common_tags"] = cleanup_tags(character_tags + common_tags)
    return result

class MultiCaptionUpdate(BaseModel):
    path: str
    mode: Literal["a", "b", "both"] = "both"
    char_a: str = "chara a"
    char_b: str = "chara b"
    raw_tags: list[str] = []
    a_tags: list[str] = []
    b_tags: list[str] = []
    common_tags: list[str] = []
    caption: str | None = None
    fixed_a: list[str] = Field(default_factory=list)
    fixed_b: list[str] = Field(default_factory=list)
    trigger_aliases: list[str] = Field(default_factory=list)
    include_style: bool = True
    include_scene: bool = True
    phrase_replacements: list[dict] = []

def _image_state(item, **changes):
    data = item.model_dump(include={"mode", "raw_tags", "a_tags", "b_tags", "common_tags", "caption", "phrase_replacements"})
    for key in ("raw_tags", "a_tags", "b_tags", "common_tags"):
        data[key] = dedupe_tags(data[key])
    return {**data, **changes}


def _validate_items(items):
    if not items:
        raise HTTPException(status_code=400, detail="対象画像を選択してください")
    seen = set()
    for item in items:
        identity = os.path.normcase(os.path.splitext(os.path.realpath(item.path))[0])
        if identity in seen:
            raise HTTPException(status_code=400, detail="Duplicate image or caption target in batch")
        seen.add(identity)
        if not os.path.isfile(item.path) or Path(item.path).suffix.lower() not in IMAGE_EXTENSIONS:
            raise HTTPException(status_code=404, detail=f"Image not found: {item.path}")
        # Preflight validation must have no TXT-recovery writes.
        load_sidecar(item.path, repair=False)


@app.post("/api/dataset/update-multicaption")
async def update_multicaption(update: MultiCaptionUpdate):
    _validate_items([update])
    if update.caption is None:
        raise HTTPException(status_code=400, detail="Save requires current caption text; use preview-caption to regenerate")
    data = save_image(update.path, _image_state(update, include_style=update.include_style, include_scene=update.include_scene))
    warnings = find_caption_warnings(update.a_tags, update.b_tags, update.common_tags, update.char_a, update.char_b)
    return {"status": "success", "caption": data["caption"], "warnings": warnings}


@app.post("/api/dataset/preview-caption")
async def preview_multicaption(update: MultiCaptionUpdate):
    project = _read_json(_project_path(str(Path(update.path).parent)), {})
    aliases = _trigger_aliases(project.get("trigger_aliases", []) + update.trigger_aliases)
    caption, warnings = build_multichar_caption(
        update.mode, update.char_a, update.char_b,
        dedupe_tags(update.fixed_a + update.a_tags), dedupe_tags(update.fixed_b + update.b_tags),
        update.common_tags, update.include_style, update.include_scene, aliases)
    return {"caption": _apply_phrase_replacements(caption, update.phrase_replacements), "warnings": warnings}


class BatchTagItem(BaseModel):
    path: str
    mode: Literal["a", "b", "both"] = "both"
    raw_tags: list[str] = []
    a_tags: list[str] = []
    b_tags: list[str] = []
    common_tags: list[str] = []
    caption: str = ""
    phrase_replacements: list[dict] = []

class BatchTagRequest(BaseModel):
    operation: str
    dest: str = "common"
    tags: list[str] = []
    items: list[BatchTagItem] = []
    char_a: str = "chara a"
    char_b: str = "chara b"
    fixed_a: list[str] = []
    fixed_b: list[str] = []
    include_style: bool = True
    include_scene: bool = True

def _remove_tags_ci(values: list[str], removals: set[str]) -> list[str]:
    return [v for v in values if v.strip().lower() not in removals]

@app.post("/api/dataset/batch-tags")
async def batch_tags(req: BatchTagRequest):
    operation = (req.operation or "").lower()
    if operation not in {"add", "remove"}:
        raise HTTPException(status_code=400, detail="operation must be add or remove")
    if req.dest not in {"a", "b", "common"}:
        raise HTTPException(status_code=400, detail="dest must be a, b, or common")
    _validate_items(req.items)
    # Deletion must match exactly what was requested, even a generic tag next to a specific tag.
    tags = dedupe_tags(req.tags)
    if not tags:
        raise HTTPException(status_code=400, detail="No valid tags supplied")
    trigger_keys = {req.char_a.strip().lower(), req.char_b.strip().lower()}
    if operation == "add" and any(t.lower() in trigger_keys for t in tags):
        raise HTTPException(status_code=400, detail="トリガー名はタグではありません。キャラクター設定で変更してください")
    removal_keys = {t.strip().lower() for t in tags}
    prepared = []
    for item in req.items:
        data = _image_state(item)
        if operation == "add":
            data["raw_tags"] = dedupe_tags(data["raw_tags"] + tags)
            key = {"a": "a_tags", "b": "b_tags", "common": "common_tags"}[req.dest]
            data[key] = dedupe_tags(data[key] + tags)
        else:
            for key in ("raw_tags", "a_tags", "b_tags", "common_tags"):
                data[key] = _remove_tags_ci(data[key], removal_keys)
        # Tag edits change generation inputs, never the current caption.
        prepared.append((item.path, data))
    results = []
    for path, data in prepared:
        saved = save_image(path, data)
        results.append({"path": path, **saved, "warnings": []})
    return {"status": "success", "updated": len(results), "items": results}


class BatchReplaceRequest(BaseModel):
    folder_path: str
    find_text: str
    replace_text: str = ""
    items: list[BatchTagItem] = []
    char_a: str = "chara a"
    char_b: str = "chara b"
    fixed_a: list[str] = []
    fixed_b: list[str] = []
    include_style: bool = True
    include_scene: bool = True
    update_trigger_settings: bool = False
    persistent: bool = True
    replace_caption_text: bool = True

def _replace_literal_ci(text: str, find_text: str, replace_text: str) -> str:
    if not isinstance(text, str) or not find_text:
        return text
    return re.sub(re.escape(find_text), lambda m: replace_text, text, flags=re.IGNORECASE)

def _replace_list_literal(values: list[str], find_text: str, replace_text: str) -> list[str]:
    out = []
    for value in values:
        new_value = _replace_literal_ci(value, find_text, replace_text).strip()
        if new_value:
            out.append(new_value)
    return dedupe_tags(out)

def _apply_phrase_replacements(text: str, rules: list[dict]) -> str:
    # Always used on a FRESH generation. Never replay all rules on saved/current text.
    out = text
    applied = set()
    for rule in rules or []:
        find_text = str(rule.get("find", ""))
        if find_text and find_text.lower() not in applied:
            out = _replace_literal_ci(out, find_text, str(rule.get("replace", "")))
            applied.add(find_text.lower())
    return out


def _merge_phrase_rule(rules: list[dict], find_text: str, replace_text: str) -> list[dict]:
    cleaned = []
    replaced = False
    for rule in rules or []:
        f = str(rule.get("find", ""))
        r = str(rule.get("replace", ""))
        if not f:
            continue
        if f.lower() == find_text.lower():
            if not replaced:
                cleaned.append({"find": find_text, "replace": replace_text})
                replaced = True
        else:
            cleaned.append({"find": f, "replace": r})
    if not replaced:
        cleaned.append({"find": find_text, "replace": replace_text})
    return cleaned

@app.post("/api/dataset/batch-replace")
async def batch_replace(req: BatchReplaceRequest):
    if not req.find_text:
        raise HTTPException(status_code=400, detail="検索文字列を入力してください")
    if req.update_trigger_settings:
        raise HTTPException(status_code=400, detail="トリガーの変更は設定保存を使用してください（captionは再生成するまで変更されません）")
    _validate_items(req.items)
    prepared = []
    for item in req.items:
        data = _image_state(item)
        if req.replace_caption_text:
            # Literal one-shot transformation of exactly the current text. No stripping or fallback.
            data["caption"] = _replace_literal_ci(item.caption, req.find_text, req.replace_text)
            if req.persistent:
                data["phrase_replacements"] = _merge_phrase_rule(item.phrase_replacements, req.find_text, req.replace_text)
        else:
            # Explicit tag-string replacement mode; does not change triggers/fixed features/caption.
            for key in ("raw_tags", "a_tags", "b_tags", "common_tags"):
                data[key] = _replace_list_literal(data[key], req.find_text, req.replace_text)
            triggers = {req.char_a.strip().lower(), req.char_b.strip().lower()}
            if any(t.lower() in triggers for key in ("raw_tags", "a_tags", "b_tags", "common_tags") for t in data[key]):
                raise HTTPException(status_code=400, detail="トリガー名を属性タグに追加できません")
        prepared.append((item.path, data))
    results = []
    for path, data in prepared:
        saved = save_image(path, data)
        results.append({"path": path, **saved, "warnings": []})
    return {"status": "success", "updated": len(results), "items": results}


@app.get("/api/image")
async def get_image(path: str):
    if not os.path.exists(path):
        raise HTTPException(status_code=404)
    return FileResponse(path)

@app.post("/api/run-tagger")
async def run_tagger(config: TaggerConfig):
    global tagger_running, tagger_logs
    if not os.path.isdir(config.folder_path):
        raise HTTPException(status_code=404, detail="Dataset folder not found")
    if tagger_running:
        return {"status": "error", "message": "Tagger is already running"}
    
    try:
        tagger_running = True
        tagger_logs = ""
        await broadcast_log("Starting tagger worker...\n")
        worker = threading.Thread(
            target=lambda: asyncio.run(tagger_task(config)),
            daemon=True
        )
        worker.start()
        return {"status": "started"}
    except Exception as e:
        tagger_running = False
        return {"status": "error", "message": str(e)}

@app.get("/api/tagger-status")
async def get_tagger_status():
    return {"running": tagger_running}

@app.get("/api/tagger-logs")
async def get_tagger_logs():
    return {"logs": tagger_logs, "running": tagger_running}

async def tagger_task(config: TaggerConfig):
    global tagger_running, tagger_logs
    await broadcast_log("Initializing Qwen-VL Tagger...\n")
    
    image_paths = []
    for ext in IMAGE_EXTENSIONS:
        image_paths.extend(glob.glob(os.path.join(config.folder_path, f"*{ext}")))
        image_paths.extend(glob.glob(os.path.join(config.folder_path, f"*{ext.upper()}")))
    image_paths = sorted(set(os.path.normcase(os.path.abspath(path)) for path in image_paths))
        
    if not image_paths:
        await broadcast_log("Error: No images found in the specified folder.\n")
        tagger_running = False
        return
        
    total_images = len(image_paths)
    await broadcast_log(f"Found {total_images} images. Loading WD14 + Qwen models...\n")
    
    try:
        import torch
        from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
        from qwen_vl_utils import process_vision_info
        device = "cuda" if torch.cuda.is_available() else "cpu"
        wd_session = None
        wd_tags_df = None

        try:
            await broadcast_log(f"Loading WD14 tagger: {WD14_MODEL_NAME}...\n")
            wd_session, wd_tags_df = load_wd14_tagger()
            await broadcast_log("WD14 tagger loaded successfully.\n")
        except Exception as e:
            await broadcast_log(f"Warning: WD14 tagger could not be loaded, continuing with Qwen only: {str(e)}\n")
        
        original_stderr = sys.stderr
        sys.stderr = WebSocketStderrRedirector(original_stderr)
        try:
            model = Qwen2VLForConditionalGeneration.from_pretrained(
                QWEN_MODEL_NAME,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                device_map="auto" if device == "cuda" else None
            )
            processor = AutoProcessor.from_pretrained(QWEN_MODEL_NAME)
        finally:
            sys.stderr = original_stderr
            
        await broadcast_log("Model loaded successfully! Generating tags...\n")
        
    except Exception as e:
        await broadcast_log(f"Error loading model: {str(e)}\n")
        tagger_running = False
        return

    try:
        for idx, img_path in enumerate(image_paths):
            await broadcast_log(f"\nProcessing [{idx + 1}/{total_images}]: {os.path.basename(img_path)}...\n")
            wd_tags = []
            if wd_session is not None and wd_tags_df is not None:
                try:
                    wd_tags = run_wd14_tagger(wd_session, wd_tags_df, img_path)
                    await broadcast_log(f"WD14 tags: {', '.join(wd_tags) if wd_tags else '(none)'}\n")
                except Exception as e:
                    await broadcast_log(f"Warning: WD14 failed for this image: {str(e)}\n")
            wd_context = ", ".join(wd_tags[:60]) if wd_tags else "(none)"
            
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": img_path},
                        {"type": "text", "text": (
                            "WD14 already detected these Danbooru-style base tags: "
                            f"{wd_context}. "
                            "Add only useful supplemental tags for ANIMA LoRA training that WD14 often misses. "
                            "Focus on art style, rendering style, line quality, shading, color palette, lighting, composition, framing, camera angle, background simplicity, and visible pose nuance. "
                            "Also add a few obvious missing visual tags only if they are not already in the WD14 tags. "
                            "Prefer concise ANIMA/Danbooru-understandable tags such as anime style, clean lineart, soft shading, cel shading, detailed shading, flat color, pastel colors, vivid colors, muted colors, soft lighting, rim lighting, backlighting, simple background, white background, full body, upper body, portrait, cowboy shot, looking at viewer, standing, sitting. "
                            "Do not repeat WD14 tags. Do not invent hidden details, names, copyrighted character names, artist names, ratings, or quality tags. "
                            "Output 6 to 18 lowercase comma-separated tags. "
                            "Rules: use ONLY commas as separators, no sentences, no dashes, no bullet points, no newlines, no numbering, no explanations. "
                            "Example output: anime style, clean lineart, soft shading, simple background, full body, looking at viewer"
                        )}
                    ]
                }
            ]
            
            text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            image_inputs, video_inputs = process_vision_info(messages)
            
            inputs = processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt"
            )
            inputs = inputs.to(device)
            
            with torch.no_grad():
                generated_ids = model.generate(**inputs, max_new_tokens=256)
                generated_ids_trimmed = [
                    out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
                ]
                output_text = processor.batch_decode(
                    generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
                )[0]
            
            # Clean and parse tags
            qwen_tags = split_qwen_tags(output_text)
            metadata_tags = prompt_text_to_tags(extract_prompt_text_from_image(img_path))
            if metadata_tags:
                await broadcast_log(f"Metadata prompt tags found: {len(metadata_tags)}\n")
            if qwen_tags:
                await broadcast_log(f"Qwen supplemental tags: {', '.join(qwen_tags)}\n")

            tags_list = dedupe_tags(metadata_tags + wd_tags + qwen_tags)
            
            # MultiCharacter v2.4: character triggers are managed by Character A/B settings,
            # not injected into raw visual tags. This prevents triggers from being mislabeled as Scene tags.
            final_tags_str = ", ".join(tags_list)
            
            persist_detected_tags(img_path, tags_list)
                
            await broadcast_log(f"Tags: {final_tags_str}\n")
            await broadcast_log(f"✅ {idx + 1}/{total_images} complete...\n")
            
        await broadcast_log("\n--- Tagging Completed Successfully ---\n")
        
    except Exception as e:
        await broadcast_log(f"Error during tagging: {str(e)}\n")
        
    finally:
        # Strict memory cleanup to avoid GPU lock
        del model
        del processor
        if device == "cuda":
            torch.cuda.empty_cache()
        gc.collect()
        tagger_running = False

# Mount Frontend static files
app.mount("/", StaticFiles(directory=str(Path(__file__).resolve().parent.parent / "frontend"), html=True), name="frontend")

@synchronized
def persist_detected_tags(image_path, tags):
    """Auto-tagging updates raw input only; never overwrites a finished/manual caption."""
    state = load_sidecar(image_path)
    if state is None:
        txt = Path(os.path.splitext(image_path)[0] + ".txt")
        state = {"mode": "both", "a_tags": [], "b_tags": [], "common_tags": dedupe_tags(tags),
                 "caption": txt.read_bytes().decode("utf-8") if txt.exists() else "",
                 "phrase_replacements": []}
    state["raw_tags"] = dedupe_tags(tags)
    save_image(image_path, state)


if __name__ == "__main__":
    import uvicorn
    try:
        from .runtime_support import bind_app_socket
    except ImportError:
        from runtime_support import bind_app_socket
    requested = int(os.environ.get("APP_PORT", "8010"))
    with bind_app_socket(requested) as sock:
        selected = sock.getsockname()[1]
        os.environ["APP_PORT"] = str(selected)
        print(f"[START] http://localhost:{selected}", flush=True)
        config = uvicorn.Config(app, host="127.0.0.1", port=selected)
        try:
            uvicorn.Server(config).run(sockets=[sock])
        except KeyboardInterrupt:
            pass
