import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from PIL import Image
from backend.main import app, persist_detected_tags
from backend import caption_store


class CaptionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)
        self.client = TestClient(app)
        self.items = []
        for i in range(3):
            path = self.folder / f'{i}.png'
            Image.new('RGB', (16, 16), (30 + i, 80, 90)).save(path)
            item = {'path': str(path), 'mode': 'a', 'raw_tags': ['green school uniform'],
                    'a_tags': ['green school uniform'], 'b_tags': [], 'common_tags': [],
                    'caption': 'yasumin wears green school uniform', 'phrase_replacements': []}
            self.items.append(item)
            self.post('/api/dataset/update-multicaption', item)

    def tearDown(self):
        self.tmp.cleanup()

    def post(self, url, payload):
        response = self.client.post(url, json=payload)
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def loaded(self):
        response = self.client.get('/api/dataset/images', params={'path': str(self.folder)})
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()['files']

    def replace(self, items=None, **changes):
        return self.post('/api/dataset/batch-replace', {
            'folder_path': str(self.folder), 'find_text': 'yasumin wears', 'replace_text': 'yasumin wears outfit ya01',
            'char_a': 'yasumin', 'items': items or [self.items[0]], **changes})['items']

    def assert_disk(self, index, text):
        self.assertEqual((self.folder / f'{index}.txt').read_bytes(), text.encode('utf-8'))
        data = json.loads((self.folder / f'{index}.anima.json').read_text(encoding='utf-8'))
        self.assertEqual(data['caption'], text)

    def test_batch_generate_subset_is_preview_and_uses_rules_and_settings(self):
        before = {p.name: p.read_bytes() for p in self.folder.iterdir()}
        rule = {'find': 'yasumin wears', 'replace': 'yasumin wears outfit ya01'}
        items = [{**self.items[i], 'char_a': 'yasumin', 'fixed_a': ['pink hair'], 'include_fixed': True,
                  'phrase_replacements': [rule]} for i in (0, 2)]
        for _ in range(2):
            result = self.post('/api/dataset/batch-preview-caption', {'items': items})
            self.assertEqual(result['updated'], 2)
            for item in result['items']:
                self.assertIn('pink hair', item['caption'])
                self.assertEqual(item['caption'].count('outfit ya01'), 1)
            items = [{**old, 'caption': new['caption']} for old, new in zip(items, result['items'])]
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.folder.iterdir()})

    def test_batch_save_exact_drafts_without_generation(self):
        items = [{**self.items[0], 'caption': '  manual 日本語\n\n '}, {**self.items[2], 'caption': ''}]
        with patch('backend.main.build_multichar_caption', side_effect=AssertionError('must not generate')):
            result = self.post('/api/dataset/batch-save-caption', {'items': items})
        self.assertEqual(result['updated'], 2)
        self.assertEqual(result['failed'], 0)
        self.assert_disk(0, items[0]['caption']); self.assert_disk(2, '')
        self.assert_disk(1, self.items[1]['caption'])

    def test_batch_caption_preflight_rejects_without_writing(self):
        missing = {k: v for k, v in self.items[2].items() if k != 'caption'}
        for endpoint in ('batch-save-caption', 'batch-preview-caption'):
            cases = [[], [self.items[0], self.items[0]],
                     [self.items[0], {**self.items[2], 'path': str(self.folder / 'absent.png')}]]
            if endpoint == 'batch-save-caption': cases.append([self.items[0], missing])
            for items in cases:
                with self.subTest(endpoint=endpoint, items=items):
                    response = self.client.post('/api/dataset/' + endpoint, json={'items': items})
                    self.assertIn(response.status_code, (400, 404))
                    for i in range(3): self.assert_disk(i, self.items[i]['caption'])

    def test_batch_save_partial_failure_reports_and_continues(self):
        from backend.main import save_image
        def failing(path, state):
            if path == self.items[1]['path']: raise OSError('disk failure')
            return save_image(path, state)
        items = [{**item, 'caption': f'draft {i}'} for i, item in enumerate(self.items)]
        with patch('backend.main.save_image', side_effect=failing):
            result = self.post('/api/dataset/batch-save-caption', {'items': items})
        self.assertEqual((result['status'], result['updated'], result['failed']), ('partial', 2, 1))
        self.assertEqual(result['failures'][0]['path'], self.items[1]['path'])
        self.assert_disk(0, 'draft 0'); self.assert_disk(2, 'draft 2')
        self.assert_disk(1, self.items[1]['caption'])

    def test_classify_preserves_manual_caption_and_never_writes(self):
        before = {p.name: p.read_bytes() for p in self.folder.iterdir()}
        body = {**self.items[0], 'mode': 'both', 'a_tags': [], 'common_tags': ['pink hair','smile','full body'],
                'raw_tags': ['pink hair','smile','full body',':d'], 'caption': 'manual unsaved'}
        result = self.post('/api/dataset/classify-tags', body)
        self.assertEqual(result['caption'], 'manual unsaved')
        self.assertEqual(result['a_tags'], []); self.assertEqual(result['common_tags'], ['full body'])
        self.assertIn('pink hair', result['classification']['unclassified_tags'])
        self.assertTrue(any(':d' in tag for tag in result['classification']['deleted_tags']))
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.folder.iterdir()})

    def test_classify_scopes_specificity_to_person_and_persists_candidates(self):
        body = {**self.items[0], 'mode': 'both', 'a_tags': ['socks'], 'b_tags': ['white high socks'],
                'raw_tags': ['socks','white high socks',':d']}
        result = self.post('/api/dataset/classify-tags', body)
        self.assertEqual(result['a_tags'], ['socks']); self.assertEqual(result['b_tags'], ['white high socks'])
        self.post('/api/dataset/update-multicaption', result)
        loaded = self.loaded()[0]
        self.assertIn(':d', loaded['tags'])
        self.assertTrue(any(':d' in tag for tag in loaded['classification']['deleted_tags']))
        self.assertFalse(any(tag.startswith('socks（') for tag in loaded['classification']['deleted_tags']))

    def test_batch_classify_selected_subset_and_rejects_invalid_preflight(self):
        items = [{**self.items[i], 'a_tags': [], 'raw_tags': ['blue eyes','full body']} for i in (0, 2)]
        result = self.post('/api/dataset/batch-classify-tags', {'items': items})
        self.assertEqual(result['updated'], 2)
        self.assertEqual(result['items'][0]['a_tags'], ['blue eyes'])
        self.assertEqual(result['items'][0]['common_tags'], ['full body'])
        response = self.client.post('/api/dataset/batch-classify-tags', json={'items': [items[0], {**items[1], 'path': str(self.folder/'absent.png')}]})
        self.assertEqual(response.status_code, 404)
        for i in range(3): self.assert_disk(i, self.items[i]['caption'])

    def test_rule_settings_saved_and_generation_does_not_change_existing_text(self):
        self.post('/api/project/config', {'folder_path': str(self.folder), 'char_a':'yasumin',
            'outfit_a':'outfit ya01', 'caption_mode':'detailed', 'include_identity':True,
            'include_fixed':False, 'include_gaze':True, 'include_style':False, 'include_composition':False})
        config=self.client.get('/api/dataset/images', params={'path':str(self.folder)}).json()['project']
        self.assertEqual(config['outfit_a'], 'outfit ya01'); self.assertTrue(config['include_gaze'])
        self.assertFalse(config['include_composition'])
        self.assert_disk(0, self.items[0]['caption'])

    def test_fixed_features_off_default_and_explicit_on(self):
        body = {**self.items[0], 'a_tags': ['pink hair','green dress'], 'fixed_a': ['pink hair']}
        self.assertNotIn('pink hair', self.post('/api/dataset/preview-caption', {**body,'include_identity':True})['caption'])
        self.assertIn('pink hair', self.post('/api/dataset/preview-caption', {**body,'include_fixed':True})['caption'])
        self.assert_disk(0, self.items[0]['caption'])

    def test_outfit_setting_and_legacy_rule_do_not_duplicate_outfit(self):
        body = {**self.items[0], 'char_a':'yasumin', 'outfit_a':'outfit ya01',
                'phrase_replacements':[{'find':'yasumin wears','replace':'yasumin wears outfit ya01'}]}
        caption=self.post('/api/dataset/preview-caption', body)['caption']
        self.assertEqual(caption.count('outfit ya01'),1)
        response=self.client.post('/api/dataset/batch-tags',json={'items':[self.items[0]],'operation':'add','tags':['outfit ya01'],'dest':'a'})
        self.assertEqual(response.status_code,400)

    def test_new_auto_tag_two_people_preserves_manual_text_and_holds_person_tags(self):
        (self.folder/'0.anima.json').unlink()
        persist_detected_tags(self.items[0]['path'], ['pink hair','purple hair','holding pen','full body',':d'])
        image=self.loaded()[0]
        self.assertEqual(image['editor']['a_tags'],[]);self.assertEqual(image['editor']['b_tags'],[])
        self.assertEqual(image['editor']['common_tags'],['full body'])
        self.assertIn('holding pen',image['classification']['unclassified_tags'])
        self.assert_disk(0,self.items[0]['caption'])

    def test_explicit_shared_pose_keeps_only_manual_common_pose(self):
        body={**self.items[0],'mode':'both','a_tags':[],'common_tags':['standing'],
              'raw_tags':['standing','sitting'],'include_shared_pose':True}
        result=self.post('/api/dataset/classify-tags',body)
        self.assertEqual(result['common_tags'],['standing'])
        self.assertIn('sitting',result['classification']['unclassified_tags'])
        caption=self.post('/api/dataset/preview-caption',{**body,'caption_mode':'detailed'})['caption']
        self.assertIn('Shared pose: standing.',caption);self.assertNotIn('sitting',caption)

    def test_generate_replace_save_reload(self):
        item = {**self.items[0], 'char_a': 'yasumin'}
        item['caption'] = self.post('/api/dataset/preview-caption', item)['caption']
        replaced = self.replace([item])[0]
        self.assertIn('yasumin wears outfit ya01 green school uniform', replaced['caption'])
        self.post('/api/dataset/update-multicaption', replaced)
        self.assertEqual(self.loaded()[0]['caption'], replaced['caption'])
        self.assert_disk(0, replaced['caption'])

    def test_acceptance_exact_text_and_settings(self):
        text = 'yasumin wears outfit ya01 green school uniform'
        replaced = self.replace()[0]
        self.assertEqual(replaced['caption'], text)
        self.assert_disk(0, text)
        self.post('/api/dataset/update-multicaption', replaced)
        self.post('/api/project/config', {'folder_path': str(self.folder), 'char_a': 'yasumin'})
        self.assertEqual(self.loaded()[0]['caption'], text)
        self.assert_disk(0, text)
        generated = self.post('/api/dataset/preview-caption', {**replaced, 'char_a': 'yasumin'})['caption']
        self.assertEqual(generated.count('outfit ya01'), 1)
        self.assert_disk(0, text)  # Preview alone must never write a caption.

    def test_settings_save_preserves_manual_caption_and_rules(self):
        replaced = self.replace()[0]
        self.post('/api/project/config', {'folder_path': str(self.folder), 'include_style': False})
        self.assert_disk(0, replaced['caption'])
        self.assertEqual(self.loaded()[0]['editor']['phrase_replacements'], replaced['phrase_replacements'])

    def test_manual_text_empty_whitespace_newlines_survive_fresh_client(self):
        for text in ['', '   ', '  Japanese 日本語\nmanual\n\n ', '\r\nexact\r\n']:
            with self.subTest(text=repr(text)):
                self.post('/api/dataset/update-multicaption', {**self.items[0], 'caption': text})
                self.client = TestClient(app)
                self.assertEqual(self.loaded()[0]['caption'], text)
                self.assert_disk(0, text)

    def test_missing_caption_is_rejected_without_regeneration(self):
        body = {k: v for k, v in self.items[0].items() if k != 'caption'}
        response = self.client.post('/api/dataset/update-multicaption', json=body)
        self.assertEqual(response.status_code, 400)
        self.assert_disk(0, self.items[0]['caption'])

    def test_persistent_rule_repeated_regeneration_applies_once(self):
        item = self.replace()[0]
        for _ in range(3):
            item['caption'] = self.post('/api/dataset/preview-caption', {**item, 'char_a': 'yasumin'})['caption']
            self.assertEqual(item['caption'].count('outfit ya01'), 1)
            self.post('/api/dataset/update-multicaption', item)
        self.assert_disk(0, item['caption'])

    def test_duplicate_legacy_rules_are_applied_once(self):
        rule = {'find': 'yasumin wears', 'replace': 'yasumin wears outfit ya01'}
        item = {**self.items[0], 'char_a': 'yasumin', 'phrase_replacements': [rule, rule]}
        text = self.post('/api/dataset/preview-caption', item)['caption']
        self.assertEqual(text.count('outfit ya01'), 1)

    def test_old_rules_not_replayed_on_current_caption(self):
        first = self.replace()[0]
        second = self.replace([first], find_text='green school uniform', replace_text='blue uniform')[0]
        self.assertEqual(second['caption'], 'yasumin wears outfit ya01 blue uniform')
        self.assertEqual(second['caption'].count('outfit ya01'), 1)

    def test_one_shot_rule_not_persisted(self):
        item = self.replace(persistent=False)[0]
        self.assertEqual(item['phrase_replacements'], [])
        generated = self.post('/api/dataset/preview-caption', {**item, 'char_a': 'yasumin'})['caption']
        self.assertNotIn('outfit ya01', generated)

    def test_literal_spaces_and_regex_symbols(self):
        text = '  A[1] wears  green\n '
        item = {**self.items[0], 'caption': text}
        changed = self.replace([item], find_text='A[1] wears ', replace_text='A[1] wears $x\\ ') [0]
        self.assertEqual(changed['caption'], '  A[1] wears $x\\  green\n ')
        self.assert_disk(0, changed['caption'])

    def test_replace_selected_subset_only(self):
        before = (self.folder / '1.anima.json').read_bytes()
        self.replace([self.items[0], self.items[2]])
        self.assertEqual((self.folder / '1.anima.json').read_bytes(), before)
        self.assert_disk(1, self.items[1]['caption'])
        self.assertIn('outfit ya01', self.loaded()[2]['caption'])

    def test_batch_add_delete_subset_and_targets_preserve_caption(self):
        for dest in ['a', 'b', 'common']:
            with self.subTest(dest=dest):
                result = self.post('/api/dataset/batch-tags', {'operation': 'add', 'dest': dest,
                    'tags': ['blue eyes'], 'items': [self.items[0], self.items[2]]})
                self.assertEqual(result['updated'], 2)
                self.assertIn('blue eyes', result['items'][0][dest + '_tags'])
                self.assertNotIn('blue eyes', self.loaded()[1]['tags'])
                removed = self.post('/api/dataset/batch-tags', {'operation': 'remove', 'dest': dest,
                    'tags': ['blue eyes'], 'items': result['items']})
                self.assertNotIn('blue eyes', removed['items'][0]['raw_tags'])
                self.assert_disk(0, self.items[0]['caption'])

    def test_delete_generic_and_specific_requested_tags(self):
        item = {**self.items[0], 'raw_tags': ['socks', 'white socks'], 'a_tags': ['socks', 'white socks']}
        removed = self.post('/api/dataset/batch-tags', {'operation': 'remove', 'tags': ['socks', 'white socks'], 'items': [item]})
        self.assertEqual(removed['items'][0]['a_tags'], [])
        self.assertEqual(removed['items'][0]['raw_tags'], [])

    def test_trigger_rename_settings_only_not_attribute(self):
        before = (self.folder / '0.anima.json').read_bytes()
        self.post('/api/project/config', {'folder_path': str(self.folder), 'char_a': 'yasumin-new'})
        self.assertEqual((self.folder / '0.anima.json').read_bytes(), before)
        generated = self.post('/api/dataset/preview-caption', {**self.items[0], 'char_a': 'yasumin-new'})['caption']
        self.assertIn('yasumin-new wears', generated)
        self.assertNotIn('yasumin-new has yasumin-new', generated)
        response = self.client.post('/api/dataset/batch-tags', json={'operation': 'add', 'char_a': 'yasumin-new', 'tags': ['yasumin-new'], 'items': [self.items[0]]})
        self.assertEqual(response.status_code, 400)

    def test_replace_cannot_mutate_global_trigger(self):
        response = self.client.post('/api/dataset/batch-replace', json={'folder_path': str(self.folder),
            'find_text': 'chara a', 'replace_text': 'new name', 'update_trigger_settings': True, 'items': [self.items[0]]})
        self.assertEqual(response.status_code, 400)
        self.assertFalse((self.folder / '.anima_tagger_project.json').exists())

    def test_fixed_features_not_persisted_in_buckets(self):
        body = {**self.items[0], 'fixed_a': ['pink hair'], 'char_a': 'yasumin', 'include_fixed': True}
        self.assertIn('pink hair', self.post('/api/dataset/preview-caption', body)['caption'])
        self.post('/api/dataset/update-multicaption', body)
        self.assertNotIn('pink hair', self.loaded()[0]['editor']['a_tags'])

    def test_legacy_v31_sidecar_and_unknown_metadata_preserved(self):
        legacy = {k: v for k, v in self.items[0].items() if k != 'path'}
        legacy.update(caption=' legacy text\n ', custom_metadata={'keep': True})
        (self.folder / '0.anima.json').write_text(json.dumps(legacy), encoding='utf-8')
        self.assertEqual(self.loaded()[0]['caption'], legacy['caption'])
        self.post('/api/dataset/update-multicaption', {**self.items[0], 'caption': legacy['caption']})
        data = json.loads((self.folder / '0.anima.json').read_text())
        self.assertEqual(data['schema_version'], 2)
        self.assertEqual(data['custom_metadata'], {'keep': True})

    def test_txt_only_exact_import(self):
        (self.folder / '0.anima.json').unlink()
        text = '  imported caption.\r\n日本語\n '
        (self.folder / '0.txt').write_bytes(text.encode('utf-8'))
        self.assertEqual(self.loaded()[0]['caption'], text)
        self.assertEqual(self.loaded()[0]['tags'], [])

    def test_zero_selection_missing_duplicate_paths_rejected(self):
        for items, code in [([], 400), ([self.items[0], self.items[0]], 400),
                             ([self.items[0], {**self.items[1], 'path': str(self.folder / 'missing.png')}], 404)]:
            with self.subTest(code=code):
                response = self.client.post('/api/dataset/batch-tags', json={'operation': 'add', 'tags': ['blue eyes'], 'items': items})
                self.assertEqual(response.status_code, code)
                self.assertNotIn('blue eyes', self.loaded()[0]['tags'])

    def test_corrupt_sidecar_not_silently_overwritten(self):
        path = self.folder / '0.anima.json'; path.write_text('{corrupt')
        with self.assertRaises(json.JSONDecodeError):
            caption_store.save_image(str(self.folder / '0.png'), self.items[0])
        self.assertEqual(path.read_text(), '{corrupt')

    def test_interrupted_txt_projection_recovers_from_canonical_sidecar(self):
        original = caption_store.atomic_text
        def fail_txt(path, text):
            if str(path).endswith('.txt'): raise OSError('simulated disk write failure')
            return original(path, text)
        with patch('backend.caption_store.atomic_text', side_effect=fail_txt):
            with self.assertRaises(OSError):
                caption_store.save_image(self.items[0]['path'], {**self.items[0], 'caption': 'committed'})
        self.assertEqual(self.loaded()[0]['caption'], 'committed')
        self.assert_disk(0, 'committed')
        backups = list(self.folder.glob('0.txt.conflict-*.bak'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_text(), self.items[0]['caption'])

    def test_external_txt_change_preserved_in_backup_before_repair(self):
        (self.folder / '0.txt').write_bytes(b'external edit')
        self.loaded()
        self.assert_disk(0, self.items[0]['caption'])
        self.assertEqual(next(self.folder.glob('0.txt.conflict-*.bak')).read_bytes(), b'external edit')

    def test_autotag_preserves_caption_and_assignments(self):
        persist_detected_tags(self.items[0]['path'], ['blue eyes', 'pink hair'])
        self.assert_disk(0, self.items[0]['caption'])
        self.assertEqual(self.loaded()[0]['editor']['a_tags'], ['green school uniform', 'blue eyes', 'pink hair'])
        self.assertEqual(self.loaded()[0]['tags'], ['blue eyes', 'pink hair'])

    def test_autotag_txt_only_preserves_existing_manual_text(self):
        (self.folder / '0.anima.json').unlink()
        persist_detected_tags(self.items[0]['path'], ['blue eyes'])
        self.assert_disk(0, self.items[0]['caption'])

    def test_renamed_legacy_trigger_is_never_an_attribute(self):
        self.post('/api/project/config', {'folder_path': str(self.folder), 'char_a': 'chara a'})
        self.post('/api/project/config', {'folder_path': str(self.folder), 'char_a': 'yasumin'})
        item = {**self.items[0], 'a_tags': ['chara a', 'chara b', 'green school uniform'], 'char_a': 'yasumin'}
        caption = self.post('/api/dataset/preview-caption', item)['caption']
        self.assertIn('yasumin wears green school uniform', caption)
        self.assertNotIn('has chara', caption)

    def test_duplicate_stems_rejected_before_overlapping_caption_write(self):
        Image.new('RGB', (16, 16)).save(self.folder / '0.jpg')
        response = self.client.get('/api/dataset/images', params={'path': str(self.folder)})
        self.assertEqual(response.status_code, 409)
        response = self.client.post('/api/dataset/batch-tags', json={'operation': 'add', 'tags': ['blue eyes'],
            'items': [self.items[0], {**self.items[0], 'path': str(self.folder / '0.jpg')}]})
        self.assertEqual(response.status_code, 400)
        self.assert_disk(0, self.items[0]['caption'])

    def test_invalid_second_tag_replacement_does_not_partially_save_first(self):
        first = {**self.items[0], 'a_tags': ['old outfit'], 'raw_tags': ['old outfit']}
        second = {**self.items[1], 'a_tags': ['chara a', 'old outfit']}
        before = (self.folder / '0.anima.json').read_bytes()
        response = self.client.post('/api/dataset/batch-replace', json={'folder_path': str(self.folder),
            'find_text': 'old outfit', 'replace_text': 'new outfit', 'replace_caption_text': False, 'items': [first, second]})
        self.assertEqual(response.status_code, 400)
        self.assertEqual((self.folder / '0.anima.json').read_bytes(), before)

    def test_unknown_project_fields_and_aliases_survive_settings_save(self):
        project = {'char_a': 'old-trigger', 'custom': {'keep': True}, 'trigger_aliases': ['older-trigger']}
        (self.folder / '.anima_tagger_project.json').write_text(json.dumps(project))
        result = self.post('/api/project/config', {'folder_path': str(self.folder), 'char_a': 'new-trigger'})['project']
        self.assertEqual(result['custom'], {'keep': True})
        self.assertIn('older-trigger', result['trigger_aliases'])
        self.assertIn('old-trigger', result['trigger_aliases'])

    def test_worker_raw_update_cannot_overwrite_concurrent_manual_save(self):
        from backend import main
        entered, release, saved = threading.Event(), threading.Event(), threading.Event()
        errors = []
        original = main.load_sidecar
        def blocked_load(path):
            data = original(path)
            entered.set()
            if not release.wait(2): raise RuntimeError('test barrier timed out')
            return data
        def worker():
            try: main.persist_detected_tags(self.items[0]['path'], ['blue eyes'])
            except Exception as exc: errors.append(exc)
        def manual():
            try: caption_store.save_image(self.items[0]['path'], {**self.items[0], 'caption': 'new manual text'})
            except Exception as exc: errors.append(exc)
            finally: saved.set()
        with patch('backend.main.load_sidecar', side_effect=blocked_load):
            w = threading.Thread(target=worker); w.start()
            self.assertTrue(entered.wait(2))
            m = threading.Thread(target=manual); m.start()
            completed_before_release = saved.wait(.1)
            release.set(); w.join(2); m.join(2)
        self.assertFalse(completed_before_release)
        self.assertFalse(w.is_alive() or m.is_alive())
        self.assertEqual(errors, [])
        self.assert_disk(0, 'new manual text')


if __name__ == '__main__':
    unittest.main()
