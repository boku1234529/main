'use strict';
let images = [], idx = 0, project = {}, selected = new Set();
let batchSelected = new Set(), lastThumbSelected = null, batchSelectMode = false;
let busy = false;
const optionKeys = ['include_fixed','include_identity','include_gaze','include_style','include_scene','include_composition','include_lighting','include_action','include_expression','include_clothing','include_shared_pose','auto_cleanup','show_warnings'];
const defaultOff = new Set(['include_fixed','include_identity','include_gaze','include_style','include_shared_pose']);
const optionId = key => key.replaceAll('_', '-');
const $ = id => document.getElementById(id);
const parse = s => s.split(',').map(x => x.trim()).filter(Boolean);
const uniq = a => [...new Set(a.map(x => x.trim()).filter(Boolean))];
const cur = () => images[idx];
const state = () => cur()?.editor;

async function api(url, body) {
  const response = await fetch(url, body === undefined ? {headers: {'X-Anima-Request': '1'}} : {
    method: 'POST', headers: {'Content-Type': 'application/json', 'X-Anima-Request': '1'}, body: JSON.stringify(body)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail));
  return data;
}
function action(fn) {
  return async (...args) => {
    if (busy) return;
    busy = true;
    const controls = [...document.querySelectorAll('button, input, select, textarea')];
    const disabled = controls.map(e => e.disabled);
    controls.forEach(e => e.disabled = true);
    try { return await fn(...args); }
    catch (error) { alert(error.message || String(error)); }
    finally { controls.forEach((e, i) => e.disabled = disabled[i]); busy = false; }
  };
}
function settings() {
  return {...project, char_a: $('char-a').value.trim() || 'chara a', char_b: $('char-b').value.trim() || 'chara b',
    fixed_a: parse($('fixed-a').value), fixed_b: parse($('fixed-b').value), tag_map: project.tag_map || {},
    outfit_a: $('outfit-a').value.trim(), outfit_b: $('outfit-b').value.trim(), caption_mode: $('caption-mode').value,
    ...Object.fromEntries(optionKeys.map(key => [key, $(optionId(key)).checked]))};
}
function showSettings() {
  $('char-a').value = project.char_a || 'chara a'; $('char-b').value = project.char_b || 'chara b';
  $('fixed-a').value = (project.fixed_a || []).join(', '); $('fixed-b').value = (project.fixed_b || []).join(', ');
  $('outfit-a').value = project.outfit_a || ''; $('outfit-b').value = project.outfit_b || '';
  $('caption-mode').value = project.caption_mode || 'auto';
  for (const key of optionKeys) $(optionId(key)).checked = project[key] ?? !defaultOff.has(key);
}
async function browse() {
  const data = await api('/api/browse-folder');
  if (data.path) { $('folder-path').value = data.path; await load(); }
}
async function load() {
  const path = $('folder-path').value;
  if (!path) return;
  if (images.some(im => im.dirty) && !confirm('未保存の編集を破棄して再読み込みしますか？')) return;
  const data = await api('/api/dataset/images?path=' + encodeURIComponent(path));
  images = data.files || []; project = data.project || {}; showSettings();
  batchSelected.clear(); lastThumbSelected = null; $('batch-result').textContent = '';
  idx = Math.min(idx, Math.max(0, images.length - 1)); renderThumbs(); render();
}
async function saveProject() {
  const value = settings();
  const data = await api('/api/project/config', {folder_path: $('folder-path').value, ...value});
  project = data.project;
  $('caption-status').textContent = '設定を保存しました。captionは変更していません。反映には再生成してください。';
}
function renderWarnings(list = []) {
  $('caption-warnings').hidden = !list.length;
  $('caption-warnings').textContent = list.length ? '⚠ ' + list.join('\n⚠ ') : '';
}
function markDirty(im = cur()) { if (im) im.dirty = true; }
function allAssigned() { const s = state(); return new Set([...s.a_tags, ...s.b_tags, ...s.common_tags].map(t => t.toLowerCase())); }
function reviewKey(tag) { return tag.toLowerCase().replaceAll('_',' ').replaceAll('-',' ').replace(/\s+/g,' ').trim(); }
function poolTags() {
  if (!cur()) return [];
  const assigned = allAssigned(), review = cur().classification || {};
  const excluded = new Set([...(review.identity_tags || []).map(reviewKey), ...(review.deleted_tags || []).map(t => t.split('（')[0])]);
  return cur().tags.filter(t => !assigned.has(t.toLowerCase()) && !excluded.has(reviewKey(t)));
}
function categoryClass(category) {
  if (['HAIR','EYES','FACE','IDENTITY'].includes(category)) return 'identity';
  if (['CLOTHING','ACCESSORY','FOOTWEAR','LEGWEAR'].includes(category)) return 'outfit';
  if (['POSE','ACTION','EXPRESSION','GAZE','OBJECT'].includes(category)) return 'action';
  if (['BACKGROUND','LIGHTING'].includes(category)) return 'scene';
  return 'other';
}
function renderReview(im) {
  for (const [id,key] of [['deleted-tags','deleted_tags'],['identity-tags','identity_tags']]) {
    $(id).replaceChildren();
    for (const tag of im?.classification?.[key] || []) {
      const span = document.createElement('span'); span.className = 'tag'; span.textContent = tag; $(id).appendChild(span);
    }
  }
}
function fill(id, tags, source) {
  $(id).replaceChildren();
  for (const tag of tags) {
    const e = document.createElement('span'); e.className = 'tag'; e.textContent = tag;
    const category = cur()?.classification?.categories?.[tag] || cur()?.classification?.categories?.[reviewKey(tag)];
    e.classList.add('category-' + categoryClass(category)); e.title = category || 'UNKNOWN';
    if ((cur()?.warnings || []).some(w => w.includes(tag))) e.classList.add('tag-warning');
    const key = source + '|' + tag;
    e.onclick = () => { if (busy) return; if (selected.has(key)) selected.delete(key); else selected.add(key); e.classList.toggle('selected', selected.has(key)); };
    $(id).appendChild(e);
  }
}
function render() {
  selected.clear(); const im = cur(); renderWarnings($('show-warnings').checked ? im?.warnings || [] : []); renderReview(im);
  if (!im) {
    $('counter').textContent = '0 / 0'; $('filename').textContent = ''; $('preview-img').removeAttribute('src');
    $('caption').value = ''; $('caption-status').textContent = ''; $('phrase-rules').textContent = ''; return;
  }
  const s = state();
  $('counter').textContent = `${idx + 1} / ${images.length}`; $('filename').textContent = im.name;
  $('preview-img').src = '/api/image?path=' + encodeURIComponent(im.path);
  document.querySelectorAll('input[name=mode]').forEach(r => r.checked = r.value === s.mode);
  fill('pool', poolTags(), 'pool'); fill('a-tags', s.a_tags, 'a'); fill('b-tags', s.b_tags, 'b'); fill('common-tags', s.common_tags, 'common');
  // The textarea is a projection of im.caption, never a separate caption cache.
  $('caption').value = im.caption;
  $('caption-status').textContent = im.dirty ? '未保存の編集があります。本文を保存するには「保存」を押してください。' : '本文はこの欄で直接編集できます。編集後は「保存」を押してください。';
  $('phrase-rules').textContent = '再生成時の置換ルール: ' + (s.phrase_replacements.length ? s.phrase_replacements.map(r => `${r.find} → ${r.replace}`).join(' / ') : 'なし');
  refreshThumbSelection();
}
function changeTags(dest) {
  const s = state(), im = cur(); if (!s) return;
  for (const key of selected) {
    const [source, ...rest] = key.split('|'), tag = rest.join('|');
    for (const bucket of ['a', 'b', 'common']) if (source === bucket || dest === 'delete') s[bucket + '_tags'] = s[bucket + '_tags'].filter(t => t !== tag);
    if (['a', 'b', 'common'].includes(dest)) s[dest + '_tags'] = uniq([...s[dest + '_tags'], tag]);
    if (dest === 'delete') im.tags = im.tags.filter(t => t !== tag);
    project.tag_map ||= {}; project.tag_map[tag.toLowerCase()] = dest === 'delete' ? '' : dest;
  }
  markDirty(); render();
}
function applyKnown(im) {
  const s = im.editor, assigned = new Set([...s.a_tags, ...s.b_tags, ...s.common_tags].map(t => t.toLowerCase()));
  for (const t of im.tags) {
    const dest = project.tag_map?.[t.toLowerCase()];
    if (!assigned.has(t.toLowerCase()) && ['a', 'b', 'common'].includes(dest)) s[dest + '_tags'] = uniq([...s[dest + '_tags'], t]);
  }
}
async function autoDistributeSingle() {
  const im = cur(); if (!im) return;
  const data = await api('/api/dataset/classify-tags', payloadFor(im));
  acceptBatch({items: [data]}, false);
  $('caption-status').textContent = '自動分類しました（未保存）。本文へ反映するには再生成し、その後保存してください。';
}
async function batchClassify() {
  const items = targets().map(item => payloadFor(images.find(im => im.path === item.path)));
  $('batch-result').textContent = `${items.length}枚を分類中…`;
  try {
    const data = await api('/api/dataset/batch-classify-tags', {items});
    acceptBatch(data, false);
    $('batch-result').textContent = `${data.updated}枚を分類しました（未保存）。本文は維持しています。必要なら一括再生成して一括保存してください。`;
  } catch (error) {
    $('batch-result').textContent = '分類に失敗しました。編集内容は保持しています。'; throw error;
  }
}
function batchItem(im) {
  const s = im.editor;
  return {path: im.path, mode: s.mode, raw_tags: im.tags, a_tags: s.a_tags, b_tags: s.b_tags, common_tags: s.common_tags,
    caption: im.caption, phrase_replacements: s.phrase_replacements};
}
function payloadFor(im) { return {...settings(), ...batchItem(im)}; }
function generationPayload(im) {
  // Plan tag-map assignment on a copy; a failed request must leave drafts intact.
  const editor = {...im.editor, a_tags: [...im.editor.a_tags], b_tags: [...im.editor.b_tags], common_tags: [...im.editor.common_tags]};
  const planned = {...im, editor}; applyKnown(planned);
  return payloadFor(planned);
}
async function generate() {
  const im = cur(); if (!im) return;
  const payload = generationPayload(im);
  const data = await api('/api/dataset/preview-caption', payload);
  im.editor.a_tags = payload.a_tags; im.editor.b_tags = payload.b_tags; im.editor.common_tags = payload.common_tags;
  im.caption = data.caption; im.warnings = data.warnings; im.classification = data.classification || im.classification; markDirty(im);
  if (cur() === im) render();
}
async function save() {
  const im = cur(); if (!im) return false;
  const data = await api('/api/dataset/update-multicaption', payloadFor(im));
  im.caption = data.caption; im.warnings = data.warnings; im.classification = data.classification || im.classification; im.dirty = false;
  if (cur() === im) { render(); $('caption-status').textContent = 'captionを保存しました。学習用TXTに反映されています。'; }
  return true;
}
function navigate(index) { idx = Math.max(0, Math.min(images.length - 1, index)); render(); }
function updateBatchCount() { $('batch-count').textContent = `${batchSelected.size}枚選択`; }
function refreshThumbSelection() {
  document.querySelectorAll('.thumb').forEach((e, i) => {
    e.classList.toggle('active', i === idx); e.classList.toggle('batch-selected', batchSelected.has(i));
    const check = e.querySelector('.thumb-check'); check.textContent = batchSelected.has(i) ? '✓' : '○'; check.setAttribute('aria-pressed', String(batchSelected.has(i)));
  }); updateBatchCount();
}
function toggleBatchIndex(i) { if (batchSelected.has(i)) batchSelected.delete(i); else batchSelected.add(i); lastThumbSelected = i; refreshThumbSelection(); }
function renderThumbs() {
  $('thumbs').replaceChildren();
  images.forEach((im, i) => {
    const e = document.createElement('div'); e.className = 'thumb';
    const check = document.createElement('button'); check.className = 'thumb-check'; check.type = 'button';
    check.title = '一括編集対象に選択'; check.setAttribute('aria-label', '一括編集対象に選択');
    check.onclick = ev => { ev.stopPropagation(); if (!busy) toggleBatchIndex(i); };
    const image = document.createElement('img'); image.src = '/api/image?path=' + encodeURIComponent(im.path);
    const label = document.createElement('div'); label.textContent = im.name;
    e.append(check, image, label);
    e.onclick = ev => {
      if (busy) return;
      if (ev.shiftKey && lastThumbSelected !== null) {
        for (let n = Math.min(lastThumbSelected, i); n <= Math.max(lastThumbSelected, i); n++) batchSelected.add(n);
        lastThumbSelected = i; refreshThumbSelection();
      } else if (batchSelectMode || ev.ctrlKey || ev.metaKey) toggleBatchIndex(i);
      else { lastThumbSelected = i; navigate(i); }
    };
    $('thumbs').appendChild(e);
  }); refreshThumbSelection();
}
function targets() {
  if (!batchSelected.size) throw new Error('下の画像一覧から対象画像を選択してください。未選択では実行しません。');
  return [...batchSelected].sort((a, b) => a - b).map(i => batchItem(images[i]));
}
function acceptBatch(data, saved = true) {
  for (const value of data.items) {
    const im = images.find(x => x.path === value.path); if (!im) continue;
    im.classification = value.classification || im.classification;
    im.tags = value.raw_tags; im.caption = value.caption; im.warnings = value.warnings || []; im.dirty = !saved;
    im.editor = {mode: value.mode, a_tags: value.a_tags, b_tags: value.b_tags, common_tags: value.common_tags, phrase_replacements: value.phrase_replacements || []};
  }
  renderThumbs(); render();
}
async function runBatchCaptions(operation) {
  const selectedItems = targets();
  const items = selectedItems.map(item => {
    const im = images.find(image => image.path === item.path);
    return operation === 'generate' ? generationPayload(im) : payloadFor(im);
  });
  const label = operation === 'generate' ? '再生成' : '保存';
  $('batch-result').textContent = `${items.length}枚を一括${label}中…`;
  let data;
  try {
    const route = operation === 'generate' ? 'batch-preview-caption' : 'batch-save-caption';
    data = await api('/api/dataset/' + route, {items});
  } catch (error) {
    $('batch-result').textContent = `一括${label}に失敗しました。編集内容は保持しています。`;
    throw error;
  }
  acceptBatch(data, operation === 'save');
  if (data.failed) {
    $('batch-result').textContent = `${data.updated}枚保存、${data.failed}枚失敗。失敗画像の編集内容は保持しています。`;
    const details = data.failures.map(f => `${images.find(im => im.path === f.path)?.name || f.path}: ${f.detail}`).join('\n');
    alert('一部の画像を保存できませんでした。保存済みの画像もあります。\n' + details);
  } else {
    $('batch-result').textContent = operation === 'generate'
      ? `${data.updated}枚を再生成しました（未保存）。「選択画像を一括保存」で学習用TXTへ保存してください。`
      : `${data.updated}枚の現在のcaptionをTXTとsidecarに保存しました。`;
  }
}
async function insertBatchText(operation = 'insert') {
  const label = {insert: '挿入', delete: '削除', replace: '置換'}[operation];
  const items = targets().map(item => payloadFor(images.find(im => im.path === item.path)));
  const text = $('batch-text').value;
  if (!text) throw new Error('処理する文字列を入力してください。');
  $('batch-result').textContent = `${items.length}枚の本文を${label}して保存中…`;
  let data;
  try {
    data = await api(operation === 'insert' ? '/api/dataset/batch-insert-text' : '/api/dataset/batch-edit-text', {items, text, operation, replacement: $('batch-text-replacement').value, position: $('batch-text-position').value,
      separator: $('batch-text-separator').value, anchor: $('batch-text-anchor').value, skip_existing: $('batch-text-skip').checked});
  } catch (error) {
    $('batch-result').textContent = `本文${label}に失敗しました。編集内容は保持しています。`; throw error;
  }
  acceptBatch(data);
  if (data.failed) {
    acceptBatch({items: data.failures.map(f => f.item)}, false);
    $('batch-result').textContent = `${data.updated}枚保存、${data.failed}枚失敗。失敗画像の編集済み本文は未保存で保持しています。「一括保存」で再試行できます。`;
    alert(data.failures.map(f => `${images.find(im => im.path === f.path)?.name || f.path}: ${f.detail}`).join('\n'));
  } else {
    $('batch-result').textContent = operation === 'insert' ? `${data.updated}枚の本文を保存しました（既存文字列による追加省略: ${data.skipped}枚）。再生成は不要です。` : `${data.updated}枚の本文を${label}して保存しました（検索文字列の一致なし: ${data.skipped}枚）。再生成は不要です。`;
  }
}
async function runBatch(operation) {
  const items = targets(), tags = parse($('batch-tags').value);
  if (!tags.length) throw new Error('一括編集するタグを入力してください。');
  const data = await api('/api/dataset/batch-tags', {...settings(), operation, dest: $('batch-dest').value, tags, items});
  acceptBatch(data); alert(`${data.updated}枚のタグを更新しました。captionは維持しました。反映には再生成してください。`);
}
async function runBatchReplace() {
  const items = targets(), find_text = $('batch-find').value;
  if (!find_text) throw new Error('検索文字列を入力してください。');
  const data = await api('/api/dataset/batch-replace', {...settings(), folder_path: $('folder-path').value, items,
    find_text, replace_text: $('batch-replace').value, replace_caption_text: $('replace-caption-text').checked,
    persistent: $('replace-persistent').checked, update_trigger_settings: false});
  acceptBatch(data); alert(`${data.updated}枚を置換・保存しました。`);
}
async function clearRules() {
  const im = cur(); if (!im) return;
  const data = await api('/api/dataset/update-multicaption', {...payloadFor(im), phrase_replacements: []});
  im.editor.phrase_replacements = []; im.caption = data.caption; im.dirty = false; render();
}
async function runTagger() {
  const path = $('folder-path').value; if (!path) throw new Error('フォルダを選択してください。');
  if (images.some(im => im.dirty)) throw new Error('未保存の編集を保存してから自動タグ付けを開始してください。');
  const started = await api('/api/run-tagger', {folder_path: path, trigger_word: ''});
  if (started.status !== 'started') throw new Error(started.message || '起動できませんでした');
  $('console').textContent = '';
  const timer = setInterval(async () => {
    try {
      const data = await api('/api/tagger-logs'); $('console').textContent = data.logs; $('console').scrollTop = $('console').scrollHeight;
      if (!data.running) { clearInterval(timer); $('caption-status').textContent = '自動タグ付けが終了しました。「再読み込み」でタグを読み込んでください。captionは維持されます。'; }
    } catch (error) { clearInterval(timer); alert(error.message); }
  }, 1000);
}
$('caption').oninput = () => { if (cur()) { cur().caption = $('caption').value; markDirty(); $('caption-status').textContent = '未保存のcaption編集があります。「保存」で学習用TXTに反映できます（再生成は不要）。'; } };
$('btn-browse').onclick = action(browse); $('btn-load').onclick = action(load);
$('btn-save-project').onclick = action(saveProject); $('btn-run').onclick = action(runTagger);
$('btn-generate').onclick = action(generate); $('btn-save').onclick = action(save);
$('btn-save-next').onclick = action(async () => { if (await save()) navigate(idx + 1); });
$('prev').onclick = action(() => navigate(idx - 1)); $('next').onclick = action(() => navigate(idx + 1));
$('btn-auto-distribute').onclick = action(autoDistributeSingle);
document.querySelectorAll('[data-dest]').forEach(b => b.onclick = action(() => changeTags(b.dataset.dest)));
document.querySelectorAll('input[name=mode]').forEach(r => r.onchange = () => { if (state()) { state().mode = r.value; markDirty(); render(); } });
$('btn-add').onclick = action(() => {
  const tag = $('add-tag').value.trim(), s = state(); if (!tag || !s) return;
  const value = settings(); if ([value.char_a.toLowerCase(), value.char_b.toLowerCase(), value.outfit_a.toLowerCase(), value.outfit_b.toLowerCase()].includes(tag.toLowerCase()) || tag.toLowerCase().startsWith('outfit ')) throw new Error('トリガー名はキャラクター設定で変更してください。');
  const dest = $('add-dest').value; s[dest + '_tags'] = uniq([...s[dest + '_tags'], tag]); cur().tags = uniq([...cur().tags, tag]);
  $('add-tag').value = ''; markDirty(); render();
});
$('batch-select-all').onclick = () => { if (!busy) { batchSelected = new Set(images.map((_, i) => i)); refreshThumbSelection(); } };
$('batch-clear').onclick = () => { if (!busy) { batchSelected.clear(); lastThumbSelected = null; refreshThumbSelection(); } };
$('batch-select-mode').onclick = () => { batchSelectMode = !batchSelectMode; $('batch-select-mode').textContent = '選択モード: ' + (batchSelectMode ? 'ON' : 'OFF'); $('batch-select-mode').classList.toggle('primary', batchSelectMode); };
$('batch-text-insert').onclick = action(() => insertBatchText('insert'));
$('batch-text-delete').onclick = action(() => insertBatchText('delete'));
$('batch-text-replace').onclick = action(() => insertBatchText('replace'));
$('batch-classify').onclick = action(batchClassify);
$('batch-generate').onclick = action(() => runBatchCaptions('generate'));
$('batch-save').onclick = action(() => runBatchCaptions('save'));
$('batch-add').onclick = action(() => runBatch('add')); $('batch-remove').onclick = action(() => runBatch('remove'));
$('batch-replace-btn').onclick = action(runBatchReplace); $('clear-rules').onclick = action(clearRules);
window.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); $('btn-save').click(); return; }
  if (busy || e.target.matches('input, textarea, select')) return;
  if (e.key === 'ArrowLeft') $('prev').click(); if (e.key === 'ArrowRight') $('next').click();
  if (['1', '2', '3'].includes(e.key)) document.querySelector(`input[name=mode][value=${{1:'a', 2:'b', 3:'both'}[e.key]}]`).click();
  const dest = {a:'a', b:'b', c:'common', Delete:'delete'}[e.key]; if (dest) action(() => changeTags(dest))();
});

window.addEventListener('beforeunload', e => {
  if (images.some(im => im.dirty)) { e.preventDefault(); e.returnValue = ''; }
});
