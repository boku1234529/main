"""Canonical saved caption = sidecar caption; TXT is its exact UTF-8 projection."""
import json
import os
import tempfile
import threading
from functools import wraps
from pathlib import Path

try:
    from .security import safe_file, read_text_bytes, MAX_TEXT_BYTES
except ImportError:
    from security import safe_file, read_text_bytes, MAX_TEXT_BYTES

SCHEMA_VERSION = 2
store_lock = threading.RLock()


def synchronized(fn):
    @wraps(fn)
    def call(*args, **kwargs):
        with store_lock:
            return fn(*args, **kwargs)
    return call


def read_json(path, default=None):
    try:
        return json.loads(read_text_bytes(path).decode('utf-8'))
    except FileNotFoundError:
        return default
    # Corruption is not an empty dataset: let the caller report it without overwriting.


def atomic_text(path, text):
    path = safe_file(path)
    if len(text.encode("utf-8")) > MAX_TEXT_BYTES:
        raise ValueError(f"保存内容が上限16MiBを超えています: {path.name}")
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def write_json(path, data):
    atomic_text(path, json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def paths(image_path):
    base = os.path.splitext(image_path)[0]
    return base + '.anima.json', base + '.txt'


@synchronized
def load_sidecar(image_path, repair=True):
    sidecar_path, txt_path = paths(image_path)
    safe_file(sidecar_path); safe_file(txt_path)
    data = read_json(sidecar_path)
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError(f'Invalid sidecar: {sidecar_path}')
    version = data.get('schema_version', 1)
    if version not in (1, SCHEMA_VERSION):
        raise ValueError(f'Unsupported sidecar schema {version}: {sidecar_path}')
    caption = data.get('caption')
    if caption is not None and not isinstance(caption, str):
        raise ValueError(f'Invalid caption: {sidecar_path}')
    for key in ('raw_tags', 'a_tags', 'b_tags', 'common_tags'):
        values = data.get(key, [])
        if not isinstance(values, list) or not all(isinstance(value, str) for value in values):
            raise ValueError(f'Invalid {key}: {sidecar_path}')
    rules = data.get('phrase_replacements', [])
    if not isinstance(rules, list) or not all(isinstance(rule, dict) for rule in rules):
        raise ValueError(f'Invalid phrase_replacements: {sidecar_path}')
    if repair and version == SCHEMA_VERSION and caption is not None:
        # Recover an interrupted projection. Preserve an externally edited TXT before repair.
        existing = read_text_bytes(txt_path) if Path(txt_path).exists() else None
        if existing != caption.encode('utf-8'):
            if existing is not None:
                fd, backup = tempfile.mkstemp(prefix=Path(txt_path).name + '.conflict-', suffix='.bak', dir=Path(txt_path).parent)
                with os.fdopen(fd, 'wb') as f:
                    f.write(existing)
            atomic_text(txt_path, caption)
    return data


@synchronized
def save_image(image_path, state):
    """Commit canonical JSON first; load_sidecar can recover a failed TXT projection."""
    sidecar_path, txt_path = paths(image_path)
    existing = load_sidecar(image_path) or {}
    data = {**existing, **state, 'schema_version': SCHEMA_VERSION}
    if not isinstance(data.get('caption'), str):
        raise ValueError('An explicit caption string is required, including an empty string')
    write_json(sidecar_path, data)
    atomic_text(txt_path, data['caption'])
    return data
