"""Browser access protections for a loopback-only desktop app (not multiuser auth)."""
import ipaddress
import json
import os
import stat
from urllib.parse import urlsplit
from pathlib import Path

MAX_REQUEST_BYTES = 16 * 1024 * 1024
MAX_TEXT_BYTES = 16 * 1024 * 1024
SECURITY_HEADERS = [(b'x-content-type-options', b'nosniff'), (b'x-frame-options', b'DENY'),
    (b'referrer-policy', b'no-referrer'), (b'cache-control', b'no-store'),
    (b'content-security-policy', b"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")]


def safe_local_host(host):
    try:
        url = urlsplit('http://' + host)
        return (url.hostname in {'localhost', '127.0.0.1', '::1'} and not url.username and not url.password
                and not url.path and not url.query and not url.fragment and (url.port is None or 1 <= url.port <= 65535))
    except ValueError:
        return False


def safe_file(path):
    """Do not follow attacker-provided links in dataset metadata (including junctions)."""
    path = Path(os.path.abspath(path))
    if path.is_symlink() or path.resolve() != path:
        raise ValueError(f'リンク経由のファイルは扱えません: {path.name}')
    if path.exists() and not path.is_file():
        raise ValueError(f'通常ファイルではありません: {path.name}')
    return path


def read_text_bytes(path):
    path = safe_file(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(fd, 'rb') as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):
            raise ValueError(f'通常ファイルではありません: {path.name}')
        data = f.read(MAX_TEXT_BYTES + 1)
    if len(data) > MAX_TEXT_BYTES:
        raise ValueError(f'テキストファイルが上限16MiBを超えています: {path.name}')
    return data


class LocalAccessMiddleware:
    def __init__(self, app): self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] not in {'http', 'websocket'}:
            return await self.app(scope, receive, send)
        headers = {}
        duplicate = False
        for key, value in scope.get('headers', []):
            if key in {b'host', b'origin', b'x-anima-request'} and key in headers: duplicate = True
            headers[key] = value.decode('latin-1')
        host = headers.get(b'host', '')
        origin = headers.get(b'origin')
        client = scope.get('client')
        try: local = bool(client and ipaddress.ip_address(client[0]).is_loopback)
        except ValueError: local = False
        origin_ok = origin is None or origin == 'http://' + host or origin == 'https://' + host
        reason = None
        if duplicate or not local or not safe_local_host(host): reason = 'ローカル接続・Hostの検証に失敗しました'
        elif not origin_ok or headers.get(b'sec-fetch-site') == 'cross-site': reason = '外部サイトからのアクセスは許可されません'
        elif scope['type'] == 'websocket' and origin is None: reason = 'WebSocket Originが必要です'
        elif scope['path'].startswith('/api/') and scope['path'] != '/api/image' and headers.get(b'x-anima-request') != '1':
            reason = 'アプリ専用リクエストヘッダーが必要です。画面を再読み込みしてください'
        if reason:
            if scope['type'] == 'websocket': return await send({'type':'websocket.close', 'code':1008})
            return await self.reject(send, 403, reason)
        if scope['type'] == 'http':
            chunks, total = [], 0
            while True:
                message = await receive()
                if message['type'] == 'http.disconnect': return
                body = message.get('body', b''); total += len(body)
                if total > MAX_REQUEST_BYTES: return await self.reject(send, 413, 'リクエスト本文が上限16MiBを超えています')
                chunks.append(body)
                if not message.get('more_body', False): break
            delivered = False
            original_receive = receive
            async def bounded_receive():
                nonlocal delivered
                if not delivered:
                    delivered = True
                    return {'type':'http.request', 'body':b''.join(chunks), 'more_body':False}
                return await original_receive()
            async def secured_send(message):
                if message['type'] == 'http.response.start':
                    existing = [(k,v) for k,v in message.get('headers', []) if k not in {h[0] for h in SECURITY_HEADERS}]
                    message = {**message, 'headers':existing + SECURITY_HEADERS}
                await send(message)
            return await self.app(scope, bounded_receive, secured_send)
        return await self.app(scope, receive, send)

    async def reject(self, send, status, detail):
        body = json.dumps({'detail':detail}, ensure_ascii=False).encode()
        await send({'type':'http.response.start', 'status':status, 'headers':[(b'content-type',b'application/json'),*SECURITY_HEADERS]})
        await send({'type':'http.response.body', 'body':body})
