import sys
from huggingface_hub import snapshot_download, hf_hub_download

QWEN_MODEL_NAME = "Qwen/Qwen2-VL-2B-Instruct"
WD14_MODEL_NAME = "SmilingWolf/wd-swinv2-tagger-v3"


def main():
    print("===================================================")
    print(f"[INFO] Checking/downloading: {QWEN_MODEL_NAME}")
    print("[INFO] This downloads files only; it does NOT load the model into RAM.")
    print("===================================================")
    try:
        snapshot_download(QWEN_MODEL_NAME, allow_patterns=['*.json', '*.safetensors', '*.txt', '*.model', '*.tiktoken'])
        print(f"[INFO] Checking/downloading: {WD14_MODEL_NAME}")
        hf_hub_download(WD14_MODEL_NAME, "model.onnx")
        hf_hub_download(WD14_MODEL_NAME, "selected_tags.csv")
        print("[SUCCESS] Required model files are available in the Hugging Face cache.")
    except Exception as exc:
        print(f"[ERROR] Model download failed: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
