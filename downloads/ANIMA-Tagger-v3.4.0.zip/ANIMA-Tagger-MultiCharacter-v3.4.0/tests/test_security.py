import asyncio
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch
import zlib
from fastapi.testclient import TestClient
from PIL import Image
from backend.main import app, parse_png_text_chunks
from backend import caption_store
from backend.security import LocalAccessMiddleware, MAX_REQUEST_BYTES


def client(**kwargs):
    return TestClient(app, base_url='http://127.0.0.1:8010', client=('127.0.0.1',50000), **kwargs)


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.folder=Path(self.tmp.name)
        self.path=self.folder/'image.png';Image.new('RGB',(8,8)).save(self.path)
        self.http=client(headers={'X-Anima-Request':'1'})
    def tearDown(self): self.tmp.cleanup()

    def test_local_app_api_still_works_with_header(self):
        response=self.http.get('/api/dataset/images',params={'path':str(self.folder)},headers={'Origin':'http://127.0.0.1:8010'})
        self.assertEqual(response.status_code,200,response.text)

    def test_dns_rebinding_and_non_loopback_clients_rejected(self):
        for host in ['attacker.example:8010','127.0.0.1.attacker.example','localhost@attacker.example','127.0.0.1:8010.evil']:
            response=self.http.get('/',headers={'Host':host})
            self.assertEqual(response.status_code,403)
        remote=TestClient(app,base_url='http://127.0.0.1:8010',client=('192.0.2.1',50000))
        self.assertEqual(remote.get('/').status_code,403)

    def test_external_null_and_different_port_origin_rejected(self):
        for origin in ['https://evil.example','null','http://127.0.0.1:9999']:
            response=self.http.get('/api/image',params={'path':str(self.path)},headers={'Origin':origin})
            self.assertEqual(response.status_code,403)

    def test_cross_site_image_and_form_write_blocked_without_disk_changes(self):
        self.assertEqual(self.http.get('/api/image',params={'path':str(self.path)},headers={'Sec-Fetch-Site':'cross-site'}).status_code,403)
        response=client().post('/api/dataset/update-multicaption',json={'path':str(self.path),'caption':'ATTACK'})
        self.assertEqual(response.status_code,403)
        self.assertFalse(self.path.with_suffix('.txt').exists())
        self.assertEqual(client().get('/api/dataset/images',params={'path':str(self.folder)}).status_code,403)

    def test_cors_preflight_cannot_get_permission_for_custom_header(self):
        response=client().options('/api/dataset/update-multicaption',headers={'Origin':'https://evil.example',
           'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'x-anima-request,content-type'})
        self.assertEqual(response.status_code,403)
        self.assertNotIn('access-control-allow-origin',response.headers)

    def test_non_image_and_disguised_image_files_not_served(self):
        secret=self.folder/'secret.txt';secret.write_text('PRIVATE')
        self.assertEqual(self.http.get('/api/image',params={'path':str(secret)}).status_code,404)
        fake=self.folder/'fake.png';fake.write_text('<script>alert(1)</script>')
        response=self.http.get('/api/image',params={'path':str(fake)})
        self.assertEqual(response.status_code,400);self.assertNotIn('<script>',response.text)
        good=self.http.get('/api/image',params={'path':str(self.path)})
        self.assertEqual(good.status_code,200);self.assertEqual(good.headers['content-type'],'image/png')

    def test_security_headers_block_frames_and_script_injection(self):
        response=self.http.get('/')
        self.assertEqual(response.headers['x-content-type-options'],'nosniff')
        self.assertEqual(response.headers['x-frame-options'],'DENY')
        self.assertIn("frame-ancestors 'none'",response.headers['content-security-policy'])
        self.assertIn("script-src 'self';",response.headers['content-security-policy'])
        self.assertEqual(response.headers['cache-control'],'no-store')

    def test_sidecar_and_txt_symlinks_cannot_read_or_overwrite_outside_file(self):
        target=self.folder/'private.json';target.write_text('{"caption":"PRIVATE"}')
        sidecar=self.path.with_suffix('.anima.json');sidecar.symlink_to(target)
        with self.assertRaises(ValueError):caption_store.load_sidecar(str(self.path))
        with self.assertRaises(ValueError):caption_store.save_image(str(self.path),{'caption':'ATTACK'})
        self.assertEqual(target.read_text(),'{"caption":"PRIVATE"}')
        sidecar.unlink();txt=self.path.with_suffix('.txt');txt.symlink_to(target)
        with self.assertRaises(ValueError):caption_store.save_image(str(self.path),{'caption':'ATTACK'})
        self.assertEqual(target.read_text(),'{"caption":"PRIVATE"}')

    def test_image_symlink_cannot_escape_to_another_file(self):
        link=self.folder/'linked.png';link.symlink_to(self.path)
        self.assertNotEqual(self.http.get('/api/image',params={'path':str(link)}).status_code,200)

    def test_compressed_png_bomb_is_bounded_and_normal_metadata_still_parsed(self):
        def write(payload):
            data=b'parameters\0\0'+zlib.compress(payload)
            self.path.write_bytes(b'\x89PNG\r\n\x1a\n'+struct.pack('>I',len(data))+b'zTXt'+data+b'\0'*4)
        write(b'green dress, full body')
        self.assertEqual(parse_png_text_chunks(str(self.path))['parameters'],'green dress, full body')
        write(b'A'*(8*1024*1024))
        self.assertEqual(parse_png_text_chunks(str(self.path)),{})

    def test_oversize_request_is_rejected_even_without_content_length(self):
        called=[];sent=[]
        async def inner(scope,receive,send):called.append(True)
        messages=iter([{'type':'http.request','body':b'a'*(MAX_REQUEST_BYTES//2),'more_body':True},
                       {'type':'http.request','body':b'b'*(MAX_REQUEST_BYTES//2+1),'more_body':False}])
        async def receive():return next(messages)
        async def send(message):sent.append(message)
        scope={'type':'http','path':'/api/dataset/images','client':('127.0.0.1',1),
               'headers':[(b'host',b'127.0.0.1:8010'),(b'x-anima-request',b'1')]}
        asyncio.run(LocalAccessMiddleware(inner)(scope,receive,send))
        self.assertEqual(sent[0]['status'],413);self.assertEqual(called,[])

    def test_non_regular_metadata_files_rejected_without_blocking(self):
        import os
        fifo=self.folder/'input.json';os.mkfifo(fifo)
        with self.assertRaises(ValueError):caption_store.read_json(fifo)

    def test_image_dimension_bomb_rejected_before_decoding_pixels(self):
        def chunk(kind,data):
            return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
        header=struct.pack('>IIBBBBB',100000,100000,8,2,0,0,0)
        self.path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',header)+chunk(b'IDAT',zlib.compress(b'\0'))+chunk(b'IEND',b''))
        response=self.http.get('/api/image',params={'path':str(self.path)})
        self.assertEqual(response.status_code,400)

    def test_oversize_text_write_leaves_existing_file_unchanged(self):
        path=self.folder/'caption.txt';path.write_text('ORIGINAL')
        with patch('backend.caption_store.MAX_TEXT_BYTES',8):
            with self.assertRaises(ValueError):caption_store.atomic_text(path,'TOO LARGE CONTENT')
        self.assertEqual(path.read_text(),'ORIGINAL')

    def test_parent_link_cannot_create_new_metadata_in_target_directory(self):
        target=self.folder/'outside';target.mkdir()
        link=self.folder/'alias';link.symlink_to(target,target_is_directory=True)
        with self.assertRaises(ValueError):caption_store.atomic_text(link/'new.json','ATTACK')
        self.assertFalse((target/'new.json').exists())

    def test_websocket_external_origin_rejected_before_logs(self):
        from starlette.websockets import WebSocketDisconnect
        with self.assertRaises(WebSocketDisconnect):
            with self.http.websocket_connect('/ws/logs',headers={'Origin':'https://evil.example'}): pass

if __name__=='__main__':unittest.main()
